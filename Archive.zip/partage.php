<?php
/**
 * NéoPcPro – Accès public à un fichier via lien de partage temporaire
 * URL : partage.php?t=<token>
 */
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';

// ── Blocage en mode maintenance ──────────────────────────────────
if (!empty($maintenanceEnabled)) {
    http_response_code(503);
    header('Retry-After: 3600');
    $_mTitle = htmlspecialchars($siteSettings['site_name'] ?? 'NéoPcPro', ENT_QUOTES);
    echo '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Maintenance – ' . $_mTitle . '</title>'
       . '<style>body{font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#0f172a;color:#e2e8f0;}'
       . 'h1{font-size:1.5rem;margin-bottom:.5rem}p{color:#94a3b8}</style></head><body>'
       . '<div style="text-align:center"><h1>🔧 Site en maintenance</h1>'
       . '<p>' . htmlspecialchars($siteSettings['maintenance']['notice_text'] ?? 'Le site est temporairement inaccessible.', ENT_QUOTES) . '</p>'
       . '</div></body></html>';
    exit;
}

$token = trim($_GET['t'] ?? '');
$error = '';
$file  = null;
$link  = null;
$passwordOk = false;

if ($token === '') {
    $error = 'Lien invalide.';
} else {
    fmCleanExpiredShareLinks($db);
    $link = fmGetShareLinkByToken($db, $token);
    if (!$link) {
        $error = 'Ce lien de partage a expiré ou n\'existe pas.';
    } elseif ($link['expires_at'] < date('Y-m-d H:i:s')) {
        $error = 'Ce lien de partage a expiré.';
    } else {
        $file = fmGetFileById($db, $link['file_id']);
        if (!$file) {
            $error = 'Le fichier n\'est plus disponible.';
        }
    }
}

// ── Vérification du mot de passe avec persistance en session ────
$needsPassword = $link && $link['password_hash'] !== '' && !$error;
$sessionKey    = 'share_unlocked_' . preg_replace('/[^a-zA-Z0-9_]/', '', $token);

if ($needsPassword) {
    // Vérifier si déjà déverrouillé en session (et que l'expiry de session est valide)
    $sessionTs = $_SESSION[$sessionKey] ?? 0;
    if ($sessionTs > 0 && $sessionTs > time()) {
        $passwordOk = true;
    }
    // Soumettre le mot de passe
    if (!$passwordOk && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $pwd = $_POST['share_password'] ?? '';
        if (password_verify($pwd, $link['password_hash'])) {
            $passwordOk = true;
            // Stocker l'état déverrouillé en session (valide 2h ou jusqu'à expiry du lien)
            $linkExpiry  = strtotime($link['expires_at'] ?? '+2 hours');
            $maxExpiry   = min($linkExpiry ?: PHP_INT_MAX, time() + 7200);
            $_SESSION[$sessionKey] = $maxExpiry;
        } else {
            $error = 'Mot de passe incorrect.';
        }
    }
}
$unlocked = !$needsPassword || $passwordOk;

// Servir le fichier directement si ?dl=1
if ($unlocked && $file && isset($_GET['dl'])) {
    $rootDir  = rtrim($rootDir ?? __DIR__, '/');
    $filePath = $rootDir . '/stockage/' . $file['user_id'] . '/' . $file['stored_name'];
    if (!is_file($filePath)) { $error = 'Fichier physique introuvable.'; } else {
        $mime = $file['mime_type'] ?: 'application/octet-stream';
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($filePath));
        header('Content-Disposition: attachment; filename="' . rawurlencode($file['original_name']) . '"');
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        readfile($filePath);
        exit;
    }
}

// Servir le fichier inline pour aperçu (images/PDF)
if ($unlocked && $file && isset($_GET['view'])) {
    $rootDir  = rtrim($rootDir ?? __DIR__, '/');
    $filePath = $rootDir . '/stockage/' . $file['user_id'] . '/' . $file['stored_name'];
    if (is_file($filePath)) {
        $mime = $file['mime_type'] ?: 'application/octet-stream';
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($filePath));
        header('Content-Disposition: inline; filename="' . rawurlencode($file['original_name']) . '"');
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        readfile($filePath);
        exit;
    }
}

$siteTitle = escape($siteSettings['site_name'] ?? 'NéoPcPro');
$favicon   = $siteSettings['favicon'] ?? '';
$bgImage   = $siteSettings['bg_image'] ?? '';

// Determine file metadata for presentation
$hasPreview = false;
$shareMaxWidth = '480px';
if ($file && $unlocked) {
    $mime = ($file['mime_type'] ?? '');
    $ext  = strtolower(pathinfo($file['original_name'], PATHINFO_EXTENSION));
    $isImg   = str_starts_with($mime, 'image/');
    $isPdf   = $mime === 'application/pdf' || $ext === 'pdf';
    $isAudio = str_starts_with($mime, 'audio/');
    $isVideo = str_starts_with($mime, 'video/');
    $isText  = in_array($ext, ['txt','md','csv','json','xml','html','htm'], true);
    $hasPreview = $isImg || $isPdf || $isAudio || $isVideo || $isText;
    if ($hasPreview) $shareMaxWidth = '720px';

    $viewUrl = 'partage.php?t=' . urlencode($token) . '&view=1';
    $dlUrl   = 'partage.php?t=' . urlencode($token) . '&dl=1';
    $fmtSize = function(int $b): string {
        if ($b < 1024) return $b . ' o';
        if ($b < 1048576) return round($b/1024, 1) . ' Ko';
        if ($b < 1073741824) return round($b/1048576, 1) . ' Mo';
        return round($b/1073741824, 1) . ' Go';
    };

    // File type icon SVG
    if ($isImg) {
        $fileIconSvg = '<svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21,15 16,10 5,21"/></svg>';
    } elseif ($isVideo) {
        $fileIconSvg = '<svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>';
    } elseif ($isAudio) {
        $fileIconSvg = '<svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>';
    } elseif ($isPdf) {
        $fileIconSvg = '<svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/><line x1="9" y1="18" x2="12" y2="18"/></svg>';
    } else {
        $fileIconSvg = '<svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Fichier partagé – <?php echo $siteTitle; ?></title>
<?php if ($favicon): ?><link rel="icon" href="<?php echo escapeAttribute($favicon); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<?php if ($bgImage): ?><style>:root{--background-image:url('<?php echo escapeAttribute($bgImage); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
<style>
:root { --share-max: <?php echo escape($shareMaxWidth); ?>; }
.share-page { display:flex; align-items:center; justify-content:center; min-height:100vh; padding:1.5rem; }
.share-card { background:var(--bg-2,#1a1f35); border:1px solid var(--card-border,rgba(255,255,255,.09)); border-radius:18px; padding:2rem; width:100%; max-width:var(--share-max); box-shadow:0 8px 40px rgba(0,0,0,.4); }
.share-header { text-align:center; margin-bottom:1.25rem; }
.share-icon { width:52px; height:52px; margin:0 auto .75rem; color:var(--primary,#38bdf8); opacity:.85; display:block; }
.share-name { font-size:1.1rem; font-weight:600; color:var(--text,#e2e8f0); margin:0 0 .35rem; word-break:break-all; }
.share-meta { font-size:.8rem; color:var(--muted,#64748b); margin:0; display:flex; align-items:center; justify-content:center; gap:.5rem; flex-wrap:wrap; }
.share-type-badge { display:inline-block; padding:.15rem .5rem; border-radius:100px; background:rgba(56,189,248,.12); color:var(--primary,#38bdf8); font-size:.7rem; font-weight:700; letter-spacing:.04em; text-transform:uppercase; border:1px solid rgba(56,189,248,.2); }
.share-error { color:#f87171; font-size:.88rem; margin:1rem 0; text-align:center; }
.share-actions { display:flex; gap:.6rem; justify-content:center; flex-wrap:wrap; margin-top:1.25rem; }
.share-btn { display:inline-flex; align-items:center; gap:.4rem; padding:.55rem 1.2rem; border-radius:8px; border:none; font-size:.85rem; font-weight:500; cursor:pointer; text-decoration:none; transition:all .15s; }
.share-btn-primary { background:var(--primary,#38bdf8); color:#0f172a; }
.share-btn-primary:hover { filter:brightness(1.1); }
.share-btn-ghost { background:var(--ghost,rgba(255,255,255,.06)); color:var(--text,#e2e8f0); border:1px solid var(--card-border,rgba(255,255,255,.09)); }
.share-btn-ghost:hover { background:var(--ghost-hover,rgba(255,255,255,.1)); }
.share-pwd-form { margin:1rem 0; display:flex; gap:.5rem; }
.share-pwd-input { flex:1; padding:.5rem .75rem; background:var(--bg-1,#0f172a); border:1px solid var(--card-border); border-radius:8px; color:var(--text); font-size:.88rem; outline:none; }
.share-pwd-input:focus { border-color:var(--primary); }
.share-preview { margin:1rem 0; border-radius:10px; overflow:hidden; max-height:70vh; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,.2); }
.share-preview img { max-width:100%; max-height:70vh; object-fit:contain; display:block; margin:0 auto; }
.share-preview iframe { width:100%; height:70vh; border:none; background:#fff; border-radius:10px; }
.share-preview audio { width:100%; outline:none; padding:.5rem; }
.share-preview video { max-width:100%; max-height:70vh; outline:none; border-radius:8px; }
.share-preview-text { max-width:100%; width:100%; max-height:70vh; overflow:auto; background:#0a0f1a; color:#e2e8f0; font-size:.82rem; line-height:1.6; padding:1rem 1.25rem; border-radius:8px; white-space:pre-wrap; word-break:break-all; margin:0; font-family:'Courier New',monospace; }
.share-expires { font-size:.72rem; color:var(--muted); margin-top:1rem; text-align:center; }
.share-error-card { text-align:center; }
/* Override global body flex that crushes the page to a narrow column */
body { align-items: stretch !important; padding: 0 !important; }
.share-page { width: 100%; box-sizing: border-box; }
</style>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<div class="share-page">
<div class="share-card">
<?php if ($error && !$file): ?>
    <div class="share-error-card">
        <svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
        <p class="share-error"><?php echo escape($error); ?></p>
        <a class="share-btn share-btn-ghost" href="index.php">Retour à l'accueil</a>
    </div>
<?php elseif ($needsPassword && !$passwordOk): ?>
    <div class="share-header">
        <svg class="share-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        <p class="share-name"><?php echo escape($file['original_name']); ?></p>
        <p class="share-meta">Ce fichier est protégé par un mot de passe.</p>
        <?php if ($error): ?><p class="share-error"><?php echo escape($error); ?></p><?php endif; ?>
    </div>
    <form method="post" class="share-pwd-form">
        <input type="password" name="share_password" class="share-pwd-input" placeholder="Mot de passe" required autofocus>
        <button type="submit" class="share-btn share-btn-primary">Déverrouiller</button>
    </form>
<?php elseif ($file): ?>
    <div class="share-header">
        <?php echo $fileIconSvg; ?>
        <p class="share-name"><?php echo escape($file['original_name']); ?></p>
        <p class="share-meta">
            <span><?php echo $fmtSize((int)$file['size']); ?></span>
            <?php if ($ext): ?><span class="share-type-badge"><?php echo escape(strtoupper($ext)); ?></span><?php endif; ?>
        </p>
    </div>

    <?php if ($isImg): ?>
    <div class="share-preview"><img src="<?php echo escape($viewUrl); ?>" alt="<?php echo escapeAttribute($file['original_name']); ?>"></div>
    <?php elseif ($isPdf): ?>
    <div class="share-preview"><iframe src="<?php echo escape($viewUrl); ?>" title="<?php echo escapeAttribute($file['original_name']); ?>"></iframe></div>
    <?php elseif ($isAudio): ?>
    <div class="share-preview"><audio controls src="<?php echo escape($viewUrl); ?>"></audio></div>
    <?php elseif ($isVideo): ?>
    <div class="share-preview"><video controls src="<?php echo escape($viewUrl); ?>" playsinline></video></div>
    <?php elseif ($isText): ?>
    <div class="share-preview"><pre class="share-preview-text" id="share-text-preview">Chargement…</pre></div>
    <?php endif; ?>

    <div class="share-actions">
        <a class="share-btn share-btn-primary" href="<?php echo escape($dlUrl); ?>">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="8 17 12 21 16 17"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/></svg>
            Télécharger
        </a>
    </div>
    <p class="share-expires">Ce lien expire le <?php echo date('d/m/Y à H:i', strtotime($link['expires_at'])); ?></p>

    <?php if ($isText): ?>
    <script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
    (function() {
        var pre = document.getElementById('share-text-preview');
        if (!pre) return;
        fetch(<?php echo json_encode($viewUrl); ?>)
            .then(function(r) { return r.text(); })
            .then(function(t) { pre.textContent = t; })
            .catch(function() { pre.textContent = 'Impossible de charger l\'aperçu.'; });
    }());
    </script>
    <?php endif; ?>
<?php endif; ?>
</div>
</div>
</body>
</html>
