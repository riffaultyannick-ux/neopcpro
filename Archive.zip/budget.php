<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

if (!$isUserAuthenticated && !$isAdminAuthenticated) {
    header('Location: /index.php?show_login=1'); exit;
}
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php'); exit;
}

$flash = getFlash();

// Initialisation des données Budget
$budgetSettings = dbGetBudgetSettings($db, $meId);
$budgetCategories = dbGetBudgetCategories($db, $meId);
$budgetTransactions = dbGetBudgetTransactions($db, $meId, 50);
$budgetSummary      = dbGetBudgetSummary($db, $meId);
$budgetChartData    = dbGetBudgetChartData($db, $meId);
$budgetCategoryData = dbGetBudgetCategoryData($db, $meId);

$currentBalance = (float)$budgetSettings['initial_balance'] + $budgetSummary['total_income'] - $budgetSummary['total_expense'];
$currency = $budgetSettings['currency'];

// Récupération de toutes les sous-catégories pour le JS
$allSubcategories = [];
if (function_exists('dbGetBudgetSubcategories')) {
    foreach ($budgetCategories as $cat) {
        $allSubcategories = array_merge($allSubcategories, dbGetBudgetSubcategories($db, (int)$cat['id']));
    }
}

$currentPage = 'budget.php';
$pageTitle = 'Gestion de Budget - ' . htmlspecialchars($siteTitle);
$bodyClass = 'budget-page';

// Gestion des onglets
$budgetTabs = [
    'home'         => 'Accueil',
    'transactions' => 'Transactions',
    'analyze'      => 'Analyse',
    'categories'   => 'Catégories'
];
$activeBudgetTab = (string)($_GET['tab'] ?? 'home');
if (!isset($budgetTabs[$activeBudgetTab])) {
    $activeBudgetTab = 'home';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Mon Budget Personnel - <?php echo htmlspecialchars($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
    <script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
    <meta name="description" content="Gestion de votre budget personnel.">
    <!-- Polices -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
    
    <!-- CSS global -->
    <!-- CSS global -->
    <link rel="stylesheet" href="assets/css/style.css?v=43">
    <link rel="stylesheet" href="assets/css/pages.css?v=35">
    <link rel="stylesheet" href="assets/css/chat.css?v=39">
    <link rel="stylesheet" href="assets/css/dashboard.css?v=1">
    <link rel="stylesheet" href="assets/css/weather.css?v=1">
    <link rel="stylesheet" href="assets/css/radio.css?v=3">
    <link rel="stylesheet" href="assets/css/tv.css?v=9">
    <!-- CSS spécifique budget -->
    <link rel="stylesheet" href="assets/css/budget.css?v=<?php echo time(); ?>">

    <?php if (!empty($siteSettings['bg_image'])): ?>
    <style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style>
    <?php endif; ?>
    <?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
    <div class="background-layer" aria-hidden="true"></div>

    <?php require __DIR__ . '/includes/nav.php'; ?>
    <?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

    <div id="spa-page">
        <main class="page budget-page is-dashboard"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="<?php echo $shouldAutoOpenAdminModal ? '1' : '0'; ?>">
            <section class="hero is-centered-v">
                <div class="hero-content is-dashboard">
                    <div class="budget-container">
                <?php if (!empty($flash)): ?>
                <div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
                    <?php echo escape($flash['message'] ?? ''); ?>
                </div>
                <?php endif; ?>

                <!-- Barre d'onglets harmonisée -->
                <div class="msg-tabs-row">
                    <nav class="msg-tabs" id="budget-tabs" role="tablist">
                        <?php foreach ($budgetTabs as $key => $label): ?>
                        <a class="msg-tab-btn<?php echo $activeBudgetTab === $key ? ' is-active' : ''; ?>"
                           href="budget.php?tab=<?php echo $key; ?>" role="tab" aria-selected="<?php echo $activeBudgetTab === $key ? 'true' : 'false'; ?>">
                            <?php echo escape($label); ?>
                        </a>
                        <?php endforeach; ?>
                    </nav>

                    <div class="budget-tabs-sep"></div>

                    <!-- Actions à droite -->
                    <div class="budget-tabs-actions">
                        <button class="msg-tab-btn budget-tab--settings" id="budget-tabs-admin-btn" type="button" title="Paramètres du Budget">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
                            <span>Paramètres</span>
                        </button>
                        <button class="msg-tab-btn budget-tab--new" id="budget-tabs-new-btn" type="button" title="Nouvelle Transaction">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            <span>Nouvelle Transaction</span>
                        </button>
                    </div>
                </div>
                </div>

                <!-- Onglet : Accueil -->
                <div class="budget-tab-content"<?php echo $activeBudgetTab !== 'home' ? ' hidden' : ''; ?>>

                <div class="budget-dashboard">
                    <!-- Résumé / KPIs -->
                    <div class="budget-cards">
                        <div class="budget-card">
                            <h3>Solde Actuel</h3>
                            <div class="budget-val highlight"><?php echo number_format($currentBalance, 2, ',', ' '); ?> <?php echo escape($currency); ?></div>
                            <div class="budget-trend">Situation au <?php echo date('d/m/Y'); ?></div>
                        </div>
                        <div class="budget-card">
                            <h3>Revenus (Mois)</h3>
                            <div class="budget-val income"><?php echo number_format($budgetSummary['month_income'], 2, ',', ' '); ?> <?php echo escape($currency); ?></div>
                        </div>
                        <div class="budget-card">
                            <h3>Dépenses (Mois)</h3>
                            <div class="budget-val expense"><?php echo number_format($budgetSummary['month_expense'], 2, ',', ' '); ?> <?php echo escape($currency); ?></div>
                        </div>
                    </div>
                    
                    <?php 
                        $goal = (float)$budgetSettings['monthly_goal'];
                        $spent = (float)$budgetSummary['month_expense'];
                        $percent = $goal > 0 ? min(100, ($spent / $goal) * 100) : 0;
                        $remaining = $goal - $spent;
                    ?>
                    <div class="budget-chart-container" style="margin-bottom: 2rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                            <h3 style="margin: 0;">Objectif de Dépenses</h3>
                            <span style="font-weight: 700; color: <?php echo $percent >= 100 ? '#ef4444' : 'var(--primary)'; ?>">
                                <?php echo number_format($spent, 2, ',', ' '); ?> / <?php echo number_format($goal, 2, ',', ' '); ?> <?php echo escape($currency); ?>
                            </span>
                        </div>
                        <div style="height: 12px; background: rgba(255,255,255,0.05); border-radius: 6px; overflow: hidden; position: relative;">
                            <div style="height: 100%; width: <?php echo $percent; ?>%; background: <?php echo $percent >= 100 ? 'linear-gradient(90deg, #ef4444, #f87171)' : 'linear-gradient(90deg, #38bdf8, #818cf8)'; ?>; transition: width 1s ease-out;"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.85rem; color: var(--muted); margin-top: 0.75rem;">
                            <span><?php echo round($percent); ?>% consommé</span>
                            <span><?php echo $remaining > 0 ? 'Reste ' . number_format($remaining, 2, ',', ' ') . ' ' . $currency : 'Objectif dépassé !'; ?></span>
                        </div>
                    </div>
 
                    <!-- Graphiques -->
                    <div class="budget-charts">
                        <div class="budget-chart-container">
                            <h3>Évolution des Dépenses vs Revenus</h3>
                            <canvas id="trendChart"></canvas>
                        </div>
                        <div class="budget-chart-container">
                            <h3>Dépenses par Catégorie</h3>
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>
                </div>
                </div>
                <!-- Fin de l'onglet Accueil -->

                <!-- Onglet : Transactions -->
                <div class="budget-tab-content"<?php echo $activeBudgetTab !== 'transactions' ? ' hidden' : ''; ?>>
                    <div class="budget-transactions-section">
                        <div class="budget-section-header">
                            <h2>Transactions Récentes</h2>
                        </div>
                        <div class="budget-table-wrapper">
                            <table class="budget-table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Bénéficiaire</th>
                                        <th>Catégorie</th>
                                        <th>Montant</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($budgetTransactions)): ?>
                                    <tr><td colspan="5" style="text-align: center; padding: 4rem; color: var(--muted);">
                                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" style="opacity: 0.3; margin-bottom: 1rem;"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                        <br>Aucune transaction enregistrée.
                                    </td></tr>
                                    <?php else: ?>
                                        <?php foreach ($budgetTransactions as $t): ?>
                                        <tr>
                                            <td><?php echo date('d/m/Y', strtotime($t['date'])); ?></td>
                                            <td><strong><?php echo escape($t['label']); ?></strong></td>
                                            <td>
                                                <span class="budget-category-tag" style="background: <?php echo escape($t['category_color']); ?>20; color: <?php echo escape($t['category_color']); ?>">
                                                    <?php echo escape($t['category_name']); ?>
                                                </span>
                                            </td>
                                            <td class="<?php echo $t['type'] === 'income' ? 'income' : 'expense'; ?>">
                                                <?php echo $t['type'] === 'income' ? '+' : '-'; ?> <?php echo number_format($t['amount'], 2, ',', ' '); ?> <?php echo escape($currency); ?>
                                            </td>
                                            <td>
                                                <button class="btn-icon" title="Modifier" onclick="editTransaction(<?php echo htmlspecialchars(json_encode($t), ENT_QUOTES); ?>)">
                                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                                </button>
                                                <button class="btn-icon btn-icon--danger" title="Supprimer" onclick="deleteTransaction(<?php echo $t['id']; ?>)">
                                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Fin de l'onglet Transactions -->

                <!-- Onglet : Analyse -->
                <div class="budget-tab-content"<?php echo $activeBudgetTab !== 'analyze' ? ' hidden' : ''; ?>>
                    <div class="budget-dashboard">
                        <div class="budget-charts">
                            <div class="budget-chart-container">
                                <h3>Moyenne Mensuelle</h3>
                                <div style="padding: 2rem; text-align: center;">
                                    <div style="font-size: 2.5rem; font-weight: 800; color: #ef4444; margin-bottom: 0.5rem;">
                                        <?php echo number_format($budgetSummary['month_expense'], 2, ',', ' '); ?> <?php echo escape($currency); ?>
                                    </div>
                                    <p style="color: var(--muted);">Dépenses ce mois-ci</p>
                                </div>
                            </div>
                            <div class="budget-chart-container">
                                <h3>Top Catégories</h3>
                                <div class="budget-table-wrapper" style="max-height: 300px; overflow-y: auto;">
                                    <table class="budget-table">
                                        <thead><tr><th>Catégorie</th><th style="text-align:right;">Total</th></tr></thead>
                                        <tbody>
                                            <?php 
                                            usort($budgetCategoryData, function($a, $b) { return $b['total'] <=> $a['total']; });
                                            foreach (array_slice($budgetCategoryData, 0, 5) as $cat): 
                                            ?>
                                            <tr>
                                                <td><span class="budget-category-tag" style="background: <?php echo escape($cat['color']); ?>20; color: <?php echo escape($cat['color']); ?>"><?php echo escape($cat['name']); ?></span></td>
                                                <td style="text-align:right; font-weight: 600;"><?php echo number_format($cat['total'], 2, ',', ' '); ?> <?php echo escape($currency); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Fin de l'onglet Analyse -->

                <!-- Onglet : Catégories -->
                <div class="budget-tab-content"<?php echo $activeBudgetTab !== 'categories' ? ' hidden' : ''; ?>>
                    <div class="budget-section-header">
                        <h2>Mes Catégories</h2>
                        <button class="btn btn-primary btn-sm" onclick="showCategoryModal()">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            Ajouter
                        </button>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; margin-top: 1.5rem;">
                        <?php foreach ($budgetCategories as $cat): ?>
                            <?php $subcats = dbGetBudgetSubcategories($db, (int)$cat['id']); ?>
                            <div class="budget-chart-container" style="border-top: 4px solid <?php echo escape($cat['color']); ?>;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
                                    <h3 style="margin:0; font-size: 1.1rem;"><?php echo escape($cat['name']); ?></h3>
                                    <div style="display: flex; gap: 0.25rem;">
                                        <button class="btn-icon" onclick="editCategory(<?php echo htmlspecialchars(json_encode($cat), ENT_QUOTES); ?>)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
                                        <button class="btn-icon btn-icon--danger" onclick="deleteCategory(<?php echo $cat['id']; ?>)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>
                                    </div>
                                </div>
                                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.25rem;">
                                    <?php foreach ($subcats as $sc): ?>
                                        <span style="background: rgba(255,255,255,0.06); padding: 0.25rem 0.6rem; border-radius: 6px; font-size: 0.85rem; display: flex; align-items: center; gap: 0.5rem;">
                                            <?php echo escape($sc['name']); ?>
                                            <button onclick="deleteSubcategory(<?php echo $sc['id']; ?>)" style="background: none; border: none; color: #ef4444; cursor: pointer; padding: 0; line-height: 1; font-size: 1.2rem;">&times;</button>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                                <form onsubmit="addSubcategory(event, <?php echo $cat['id']; ?>)" style="display: flex; gap: 0.5rem;">
                                    <input type="text" placeholder="Nouvelle sous-catégorie..." required style="flex: 1; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 0.4rem 0.75rem; color: #fff; font-size: 0.9rem;">
                                    <button type="submit" class="btn btn-primary btn-sm" style="padding: 0 0.75rem;">+</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <!-- Fin de l'onglet Catégories -->
                    </div>
                </div>
            </section>
        </main>

        <!-- Modale : Nouvelle Transaction -->
        <div class="budget-modal-backdrop" id="transaction-modal-bg" style="display:none">
            <div class="budget-modal" role="dialog" aria-modal="true" aria-labelledby="transaction-modal-ttl">
                <div class="budget-modal-header">
                    <h2 class="budget-modal-title" id="transaction-modal-ttl">Nouvelle Transaction</h2>
                    <button type="button" class="budget-modal-close" id="transaction-modal-cancel" aria-label="Fermer">&#215;</button>
                </div>
                <div class="budget-modal-body">
                    <form method="post" id="transaction-form">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="add_budget_transaction" id="t_action">
                        <input type="hidden" name="id" id="t_id">

                        <div class="budget-form-group">
                            <label class="budget-form-label" for="t_label">Libellé / Bénéficiaire</label>
                            <input class="budget-form-input" type="text" name="label" id="t_label" placeholder="Ex: Supermarché, Salaire..." required>
                        </div>

                        <div class="budget-form-row">
                            <div class="budget-form-group">
                                <label class="budget-form-label" for="t_amount">Montant</label>
                                <div class="budget-input-with-symbol">
                                    <input class="budget-form-input" type="number" step="0.01" name="amount" id="t_amount" placeholder="0,00" required>
                                    <span class="budget-input-symbol"><?php echo escape($currency); ?></span>
                                </div>
                            </div>
                            <div class="budget-form-group">
                                <label class="budget-form-label" for="t_type">Type</label>
                                <select class="budget-form-input" name="type" id="t_type">
                                    <option value="expense">Dépense</option>
                                    <option value="income">Revenu</option>
                                </select>
                            </div>
                        </div>

                        <div class="budget-form-row">
                            <div class="budget-form-group">
                                <label class="budget-form-label" for="t_category">Catégorie</label>
                                <select class="budget-form-input" name="category_id" id="t_category" onchange="updateSubcategories(this.value)">
                                    <?php foreach ($budgetCategories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo escape($cat['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="budget-form-group">
                                <label class="budget-form-label" for="t_subcategory">Sous-catégorie</label>
                                <select class="budget-form-input" name="subcategory_id" id="t_subcategory">
                                    <option value="">Aucune</option>
                                </select>
                            </div>
                            <div class="budget-form-group">
                                <label class="budget-form-label" for="t_date">Date</label>
                                <input class="budget-form-input" type="date" name="date" id="t_date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>

                        <div class="budget-modal-footer">
                            <button class="btn btn-secondary" type="button" id="transaction-modal-cancel-2">Annuler</button>
                            <button class="btn btn-primary" type="submit">Ajouter la transaction</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Overlay : Catégories -->
        <div id="category-modal-bg" class="budget-modal-backdrop" style="display:none" role="dialog" aria-modal="true">
            <div class="budget-modal">
                <div class="budget-modal-header">
                    <h2 class="budget-modal-title" id="cat-modal-ttl">Ajouter une Catégorie</h2>
                    <button class="budget-modal-close" type="button" onclick="closeModal(document.getElementById('category-modal-bg'))">&#215;</button>
                </div>
                <div class="budget-modal-body">
                    <form method="post" id="category-form">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="add_budget_category" id="cat_action">
                        <input type="hidden" name="id" id="cat_id">
                        
                        <div class="budget-form-group">
                            <label class="budget-form-label">Nom de la catégorie</label>
                            <input class="budget-form-input" type="text" name="name" id="cat_name" required>
                        </div>
                        <div class="budget-form-row">
                            <div class="budget-form-group">
                                <label class="budget-form-label">Type</label>
                                <select class="budget-form-input" name="type" id="cat_type">
                                    <option value="expense">Dépense</option>
                                    <option value="income">Revenu</option>
                                </select>
                            </div>
                            <div class="budget-form-group">
                                <label class="budget-form-label">Couleur</label>
                                <input class="budget-form-input" type="color" name="color" id="cat_color" value="#38bdf8">
                            </div>
                        </div>
                        <div class="budget-modal-footer">
                            <button class="btn btn-secondary" type="button" onclick="closeModal(document.getElementById('category-modal-bg'))">Annuler</button>
                            <button class="btn btn-primary" type="submit" id="cat_submit_btn">Ajouter la catégorie</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Overlay : Paramètres du Budget -->
        <div id="budget-admin-overlay" class="budget-modal-backdrop" style="display:none" aria-hidden="true" role="dialog" aria-modal="true">
            <div class="budget-modal" id="budget-admin-panel" style="max-width:600px;">
                <div class="budget-modal-header">
                    <h2 class="budget-modal-title">Paramètres du Budget</h2>
                    <button class="budget-modal-close" type="button" id="budget-admin-close" aria-label="Fermer">&#215;</button>
                </div>
                <div class="budget-modal-body">
                    <form method="post" id="budget-settings-form">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="update_budget_settings">
                        
                        <div class="budget-form-group">
                            <label class="budget-form-label" for="initial_balance">Solde initial (compte courant)</label>
                            <div class="budget-input-with-symbol">
                                <input class="budget-form-input" type="number" step="0.01" name="initial_balance" id="initial_balance" value="<?php echo (float)$budgetSettings['initial_balance']; ?>" required>
                                <span class="budget-input-symbol"><?php echo escape($budgetSettings['currency']); ?></span>
                            </div>
                            <p class="budget-form-help">Le montant actuellement présent sur votre compte.</p>
                        </div>

                        <div class="budget-form-group">
                            <label class="budget-form-label" for="monthly_goal">Objectif de dépenses mensuelles</label>
                            <div class="budget-input-with-symbol">
                                <input class="budget-form-input" type="number" step="0.01" name="monthly_goal" id="monthly_goal" value="<?php echo (float)$budgetSettings['monthly_goal']; ?>" required>
                                <span class="budget-input-symbol"><?php echo escape($budgetSettings['currency']); ?></span>
                            </div>
                            <p class="budget-form-help">Le montant maximum que vous souhaitez dépenser par mois.</p>
                        </div>

                        <div class="budget-form-group">
                            <label class="budget-form-label" for="currency">Devise</label>
                            <select class="budget-form-input" name="currency" id="currency">
                                <option value="€"<?php echo $budgetSettings['currency'] === '€' ? ' selected' : ''; ?>>Euro (€)</option>
                                <option value="$"<?php echo $budgetSettings['currency'] === '$' ? ' selected' : ''; ?>>Dollar ($)</option>
                                <option value="CHF"<?php echo $budgetSettings['currency'] === 'CHF' ? ' selected' : ''; ?>>Franc Suisse (CHF)</option>
                            </select>
                        </div>

                        <div class="budget-modal-footer">
                            <button class="btn btn-secondary" type="button" onclick="closeModal(document.getElementById('budget-admin-overlay'))">Annuler</button>
                            <button class="btn btn-primary" type="submit">Enregistrer les paramètres</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

                </div> <!-- /hero-content -->
            </section> <!-- /hero -->
        </main> <!-- /page -->

        <script src="https://cdn.jsdelivr.net/npm/chart.js" nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>"></script>
        <script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
        (function() {
            // Données fraîches pour les graphiques (doivent être mises à jour à chaque injection)
            var budgetChartData    = <?php echo json_encode($budgetChartData); ?>;
            var budgetCategoryData = <?php echo json_encode($budgetCategoryData); ?>;
            var subData = <?php echo json_encode($allSubcategories); ?>;

            // Fonction d'initialisation des graphiques (appelée à chaque changement d'onglet)
            window.initCharts = function() {
                var cT = document.getElementById('trendChart');
                if (cT && typeof Chart !== 'undefined') {
                    var existing = Chart.getChart(cT); if (existing) existing.destroy();
                    new Chart(cT, {
                        type: 'line',
                        data: {
                            labels: budgetChartData.map(function(d){ return d.label; }),
                            datasets: [
                                { label: 'Dépenses', data: budgetChartData.map(function(d){ return d.expense; }), borderColor: '#ef4444', backgroundColor: 'rgba(239, 68, 68, 0.1)', borderWidth: 2, fill: true, tension: 0.4 },
                                { label: 'Revenus',  data: budgetChartData.map(function(d){ return d.income; }), borderColor: '#10b981', backgroundColor: 'transparent', borderWidth: 2, borderDash: [5, 5], fill: false, tension: 0.4 }
                            ]
                        },
                        options: {
                            responsive: true, maintainAspectRatio: false,
                            plugins: { 
                                legend: { position: 'top', labels: { color: 'rgba(255,255,255,0.7)', font: { family: 'Outfit' } } },
                                tooltip: { backgroundColor: 'rgba(15, 23, 42, 0.9)', titleFont: { family: 'Outfit' }, bodyFont: { family: 'Outfit' } }
                            },
                            scales: {
                                x: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: 'rgba(255,255,255,0.5)', font: { family: 'Plus Jakarta Sans' } } },
                                y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: 'rgba(255,255,255,0.5)', font: { family: 'Plus Jakarta Sans' } } }
                            }
                        }
                    });
                }
                var cC = document.getElementById('categoryChart');
                if (cC && typeof Chart !== 'undefined') {
                    var existingC = Chart.getChart(cC); if (existingC) existingC.destroy();
                    new Chart(cC, {
                        type: 'doughnut',
                        data: {
                            labels: budgetCategoryData.map(function(d){ return d.name; }),
                            datasets: [{ data: budgetCategoryData.map(function(d){ return d.total; }), backgroundColor: budgetCategoryData.map(function(d){ return d.color || '#3b82f6'; }), borderWidth: 0, hoverOffset: 4 }]
                        },
                        options: {
                            responsive: true, maintainAspectRatio: false, cutout: '70%',
                            plugins: { legend: { position: 'bottom', labels: { color: 'rgba(255,255,255,0.7)', padding: 20 } } }
                        }
                    });
                }
            };

            window.updateSubcategories = function(catId, selectedId) {
                var s = document.getElementById('t_subcategory'); if(!s) return;
                s.innerHTML = '<option value="">Aucune</option>';
                subData.filter(function(x){ return x.category_id == catId; }).forEach(function(x){
                    var o = document.createElement('option'); o.value=x.id; o.textContent=x.name;
                    if(selectedId && x.id == selectedId) o.selected=true;
                    s.appendChild(o);
                });
            };

            // Toujours rafraîchir l'UI
            initCharts();
            var processFlashes = function() {
                if (window.siteProcessFlashMessages) {
                    window.siteProcessFlashMessages(document.getElementById('spa-page'));
                } else {
                    setTimeout(processFlashes, 100);
                }
            };
            processFlashes();

            // Initialisation UNIQUE du socle SPA et des événements
            if (!window.budgetSpaInitialized) {
                window.showModal = function(bg) {
                    if (!bg) return;
                    bg.style.display = 'flex'; bg.classList.remove('is-closing');
                    void bg.offsetWidth; bg.classList.add('is-open');
                    document.body.classList.add('has-overlay-open');
                };

                window.closeModal = function(bg) {
                    if (!bg) return;
                    bg.classList.add('is-closing'); bg.classList.remove('is-open');
                    setTimeout(function() {
                        bg.style.display = 'none'; bg.classList.remove('is-closing');
                        document.body.classList.remove('has-overlay-open');
                    }, 220);
                };

                window.editTransaction = function(t) {
                    document.getElementById('transaction-modal-ttl').textContent = 'Modifier la Transaction';
                    document.getElementById('t_action').value = 'update_budget_transaction';
                    document.getElementById('t_id').value = t.id;
                    document.getElementById('t_label').value = t.label;
                    document.getElementById('t_amount').value = t.amount;
                    document.getElementById('t_type').value = t.type;
                    document.getElementById('t_category').value = t.category_id;
                    document.getElementById('t_date').value = t.date;
                    updateSubcategories(t.category_id, t.subcategory_id);
                    showModal(document.getElementById('transaction-modal-bg'));
                };

                window.resetTransactionForm = function() {
                    var f = document.getElementById('transaction-form');
                    if(!f) return;
                    f.reset();
                    document.getElementById('transaction-modal-ttl').textContent = 'Nouvelle Transaction';
                    document.getElementById('t_action').value = 'add_budget_transaction';
                    document.getElementById('t_id').value = '';
                    document.getElementById('t_date').value = new Date().toISOString().split('T')[0];
                    updateSubcategories(document.getElementById('t_category').value);
                };

                window.deleteTransaction = function(id) { if(confirm('Supprimer cette transaction ?')) postAction({ admin_action: 'delete_budget_transaction', id: id }); };
                window.showCategoryModal = function() { var f=document.getElementById('category-form'); if(f) f.reset(); document.getElementById('cat-modal-ttl').textContent='Ajouter une Catégorie'; document.getElementById('cat_action').value='add_budget_category'; document.getElementById('cat_submit_btn').textContent='Ajouter'; showModal(document.getElementById('category-modal-bg')); };
                window.editCategory = function(c) { document.getElementById('cat-modal-ttl').textContent='Modifier la Catégorie'; document.getElementById('cat_action').value='update_budget_category'; document.getElementById('cat_id').value=c.id; document.getElementById('cat_name').value=c.name; document.getElementById('cat_type').value=c.type; document.getElementById('cat_color').value=c.color; document.getElementById('cat_submit_btn').textContent='Mettre à jour'; showModal(document.getElementById('category-modal-bg')); };
                window.deleteCategory = function(id) { if(confirm('Supprimer catégorie ?')) postAction({ admin_action: 'delete_budget_category', id: id }); };
                window.deleteSubcategory = function(id) { if(confirm('Supprimer sous-catégorie ?')) postAction({ admin_action: 'delete_budget_subcategory', id: id }); };
                window.addSubcategory = function(e, catId) { e.preventDefault(); var name = e.target.querySelector('input').value.trim(); if(name) postAction({ admin_action: 'add_budget_subcategory', category_id: catId, name: name }); };

                window.postAction = function(data) {
                    var fd = new FormData();
                    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
                    for(var k in data) fd.append(k, data[k]);
                    fetch(window.location.href, {method:'POST', body:fd}).then(function(r){return r.text();}).then(function(h){ 
                        window.targetedUpdate(new DOMParser().parseFromString(h,'text/html')); 
                    });
                };

                window.targetedUpdate = function(doc) {
                    var n = doc.getElementById('spa-page');
                    var o = document.getElementById('spa-page');
                    if(n && o) {
                        o.innerHTML = n.innerHTML;
                        var scripts = o.querySelectorAll('script');
                        scripts.forEach(function(s) {
                            var ns = document.createElement('script'); ns.nonce = s.nonce; ns.textContent = s.textContent;
                            s.parentNode.replaceChild(ns, s);
                        });
                        // Traiter les flash messages après la fermeture de la modale (220ms) + marge
                        setTimeout(function() {
                            if (window.siteProcessFlashMessages) window.siteProcessFlashMessages();
                        }, 300);
                    }
                };

                document.addEventListener('click', function(e) {
                    // Onglets SPA
                    var tab = e.target.closest('.budget-tab[href]');
                    if (tab && !tab.hasAttribute('onclick') && !tab.closest('.budget-tabs-actions')) {
                        e.preventDefault();
                        var url = tab.href;
                        fetch(url).then(function(r){return r.text();}).then(function(h){
                            window.targetedUpdate(new DOMParser().parseFromString(h,'text/html'));
                            window.history.pushState({}, '', url);
                        });
                        return;
                    }

                    // Modales & Actions
                    if(e.target.closest('#budget-tabs-admin-btn')) { showModal(document.getElementById('budget-admin-overlay')); return; }
                    if(e.target.closest('#budget-tabs-new-btn')) { resetTransactionForm(); showModal(document.getElementById('transaction-modal-bg')); return; }
                    if(e.target.closest('.budget-modal-close') || e.target.closest('#transaction-modal-cancel') || e.target.closest('#transaction-modal-cancel-2')) {
                        var m = e.target.closest('.budget-modal-backdrop'); if(m) closeModal(m); return;
                    }
                });

                document.addEventListener('submit', function(e) {
                    var f = e.target;
                    if (f.id === 'transaction-form' || f.id === 'budget-settings-form' || f.id === 'category-form') {
                        e.preventDefault();
                        var fd = new FormData(f);
                        var m = f.closest('.budget-modal-backdrop');
                        fetch(window.location.href, {method:'POST', body:fd}).then(function(r){return r.text();}).then(function(h){
                            if(m) closeModal(m);
                            window.targetedUpdate(new DOMParser().parseFromString(h,'text/html'));
                        });
                    }
                });

                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape') {
                        var o = document.querySelector('.budget-modal-backdrop.is-open');
                        if(o) closeModal(o);
                    }
                });

                window.budgetSpaInitialized = true;
            }
        })();
        </script>
    </div><!-- /#spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
</body>
</html>
