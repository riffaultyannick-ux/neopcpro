<?php
/**
 * NéoPcPro – Administration des fichiers (page autonome)
 */
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

if (!$isAdminAuthenticated) {
    header('Location: index.php');
    exit;
}

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Administration des fichiers – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/fichiers.css?v=12">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<main class="page"
      data-admin-authenticated="1"
      data-admin-auto-open="0">

<section class="hero" aria-labelledby="fm-admin-panel-title">
<div class="hero-content">
<?php require __DIR__ . '/includes/admin-fichiers-panel.php'; ?>
</div>
</section>

</main>

<?php require __DIR__ . '/includes/admin-modal.php'; ?>


</body>
</html>
