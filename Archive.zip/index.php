<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Page d'accueil : respecte le mode privé global
enforcePrivateAccess($isPrivateModeEnabled, $isUserAuthenticated, $isAdminAuthenticated, []);

$shouldAutoOpenAdminModal    = $isAdminAuthenticated && (string)($_GET['admin'] ?? '') === '1';
$shouldRenderMaintenanceView = $maintenanceEnabled && !$isAdminAuthenticated;
$isPrivateGuestView          = $isPrivateModeEnabled && !$isUserAuthenticated && !$isAdminAuthenticated;
$flash                       = getFlash();


$ogTitle = escape($siteSettings['site_title'] ?? 'NéoPcPro');
$ogDesc  = escape($siteSettings['site_subtitle'] ?? '');
$ogImage = escape($siteSettings['og_image'] ?? '');
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $ogDesc; ?>">
<meta name="robots" content="<?php echo $shouldRenderMaintenanceView ? 'noindex, nofollow' : 'index, follow'; ?>">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="<?php echo $ogTitle; ?>">
<meta property="og:description" content="<?php echo $ogDesc; ?>">
<meta property="og:site_name"   content="<?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?>">
<?php if ($ogImage !== ''): ?><meta property="og:image" content="<?php echo $ogImage; ?>"><?php endif; ?>
<title><?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/dashboard.css?v=1">
<link rel="stylesheet" href="assets/css/weather.css?v=1">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<link rel="stylesheet" href="assets/css/tv.css?v=9">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<div id="spa-page">
<main class="page is-dashboard"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="<?php echo $shouldAutoOpenAdminModal ? '1' : '0'; ?>">

<section class="hero is-centered-v" aria-labelledby="page-title">
<div class="hero-content is-dashboard<?php echo $shouldRenderMaintenanceView ? ' maintenance-layout' : ''; ?>">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<?php if (isset($_GET['need_login']) && !$isUserAuthenticated && !$isAdminAuthenticated): ?>
<div class="site-flash site-flash-info" role="status">
    <?php echo escape($userConfig['login_message'] ?? 'Vous devez être connecté pour accéder à ce site.'); ?>
</div>
<?php endif; ?>

<?php if ($isPrivateGuestView): ?>
<!-- ── MODE PRIVÉ (visiteur non connecté) ────────────────────── -->
<div class="private-guest-view">
    <span class="badge" aria-hidden="true">Accès restreint</span>
    <h1 id="page-title"><?php echo escape($siteSettings['site_title'] ?? 'NéoPcPro'); ?></h1>
    <p class="subtitle"><?php echo escape($userConfig['login_message'] ?? 'Ce site est en accès privé. Veuillez vous connecter.'); ?></p>
</div>

<?php elseif ($shouldRenderMaintenanceView): ?>
<!-- ── MAINTENANCE ───────────────────────────────────────────── -->
<section class="top-notice is-warning" aria-label="Information importante">
    <div class="top-notice-content">
        <strong class="top-notice-title"><?php echo escape($maintenance['notice_title'] ?? ''); ?></strong>
        <p class="top-notice-text"><?php echo escape($maintenance['notice_text'] ?? ''); ?></p>
    </div>
</section>
<span class="badge" aria-hidden="true"><?php echo escape($maintenance['badge_text'] ?? ''); ?></span>
<div>
    <h1 id="page-title"><?php echo escape($maintenance['title'] ?? ''); ?></h1>
    <p class="subtitle"><?php echo escape($maintenance['subtitle'] ?? ''); ?></p>
</div>
<div class="info-box">
    <article class="info-card"><h2><?php echo escape($maintenance['status_title'] ?? ''); ?></h2><p><?php echo escape($maintenance['status_text'] ?? ''); ?></p></article>
    <article class="info-card"><h2><?php echo escape($maintenance['why_title'] ?? ''); ?></h2><p><?php echo escape($maintenance['why_text'] ?? ''); ?></p></article>
    <article class="info-card"><h2><?php echo escape($maintenance['action_title'] ?? ''); ?></h2><p><?php echo escape($maintenance['action_text'] ?? ''); ?></p></article>
</div>
<div class="maintenance-actions">
    <section class="maintenance-panel"><h2><?php echo escape($maintenance['panel_message_title'] ?? ''); ?></h2><p><?php echo escape($maintenance['panel_message_text'] ?? ''); ?></p></section>
    <section class="maintenance-panel">
        <h2><?php echo escape($maintenance['tips_title'] ?? ''); ?></h2>
        <ul class="maintenance-list"><?php foreach (($maintenance['tips_lines'] ?? []) as $tip): ?><li><?php echo escape($tip); ?></li><?php endforeach; ?></ul>
    </section>
</div>
<footer class="site-footer">
    <p class="footer-note"><?php echo escape($maintenance['footer_note'] ?? ''); ?></p>
</footer>

<?php elseif ($isUserAuthenticated): ?>
<!-- ── TABLEAU DE BORD (utilisateur connecté) ────────────────── -->
<?php require __DIR__ . '/includes/dashboard-panel.php'; ?>
<?php $pinnedArticles = []; /* pas de carousel sur le dashboard */ ?>

<?php else: ?>
<!-- ── VUE NORMALE (visiteur non connecté) ──────────────────── -->
<h1 id="page-title"><?php echo escape($siteSettings['site_title'] ?? 'Bienvenue chez NéoPcPro'); ?></h1>
<p class="subtitle"><?php echo escape($siteSettings['site_subtitle'] ?? ''); ?></p>

<div class="buttons-grid">
<?php foreach ($buttons as $btn): ?>
<?php if (!isItemVisible($btn)) { continue; } ?>
<a class="btn btn-<?php echo escape($btn['type'] ?? 'secondary'); ?>"
   href="<?php echo escape($btn['url'] ?? '#'); ?>" target="_blank" rel="noopener noreferrer">
    <?php if (!empty($btn['icon'])): ?>
    <img class="btn-icon" src="<?php echo escape($btn['icon']); ?>" alt="" aria-hidden="true" loading="lazy" width="26" height="26">
    <?php endif; ?>
    <span class="btn-label"><?php echo escape($btn['label'] ?? 'Bouton'); ?></span>
</a>
<?php endforeach; ?>
</div>

<?php
// Carousel : articles épinglés et visibles
$pinnedArticles = [];
foreach ($newsArticles as $na) {
    if ((int)($na['visible'] ?? 0) === 1 && (int)($na['pinned'] ?? 0) === 1) {
        $pinnedArticles[] = $na;
    }
}
usort($pinnedArticles, function($a, $b) {
    return strcmp($b['date'] ?? '0000-00-00', $a['date'] ?? '0000-00-00');
});
?>
<?php if (!empty($pinnedArticles)): ?>
<div class="hero-news-carousel" id="hero-carousel">
    <span class="hero-news-carousel-label">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M18 20V10"/><path d="M12 20V4"/><path d="M6 20v-6"/></svg>
        Actualités épinglées
    </span>
    <div class="hero-news-carousel-track-wrap">
        <div class="hero-news-carousel-track" id="hero-carousel-track" role="list">
            <?php foreach ($pinnedArticles as $idx => $pa): ?>
            <?php
                $ts = @strtotime($pa['date'] ?? '');
                $dateStr = $ts ? date('j F Y', $ts) : escape($pa['date'] ?? '');
            ?>
            <button class="hero-news-vignette"
                    type="button"
                    role="listitem"
                    data-open-article-home="<?php echo escapeAttribute($pa['id']); ?>"
                    aria-label="Lire : <?php echo escapeAttribute($pa['title'] ?? ''); ?>">
                <?php if (!empty($pa['image'])): ?>
                <img class="hero-news-vignette-img" src="<?php echo escape($pa['image']); ?>" alt="" loading="lazy">
                <?php endif; ?>
                <div class="hero-news-vignette-text">
                    <span class="hero-news-vignette-title"><?php echo escape($pa['title'] ?? ''); ?></span>
                    <span class="hero-news-vignette-date"><?php echo $dateStr; ?></span>
                </div>
            </button>
            <?php endforeach; ?>
        </div>
    </div>
    <?php if (count($pinnedArticles) > 1): ?>
    <div class="hero-news-carousel-nav">
        <div class="hero-news-carousel-dots" id="hero-carousel-dots">
            <?php foreach ($pinnedArticles as $idx => $pa): ?>
            <button class="hero-news-carousel-dot<?php echo $idx === 0 ? ' is-active' : ''; ?>"
                    type="button"
                    data-carousel-dot="<?php echo $idx; ?>"
                    aria-label="Vignette <?php echo $idx + 1; ?>"></button>
            <?php endforeach; ?>
        </div>
        <div class="hero-news-carousel-arrows">
            <button class="hero-news-carousel-arrow" type="button" id="carousel-prev" aria-label="Précédent">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
            </button>
            <button class="hero-news-carousel-arrow" type="button" id="carousel-next" aria-label="Suivant">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
        </div>
    </div>
    <?php endif; ?>
</div>


<?php
$pinnedJson = json_encode(array_map(function($a) {
    $ts = @strtotime($a['date'] ?? '');
    return [
        'id'      => $a['id'],
        'title'   => $a['title'] ?? '',
        'date'    => $ts ? date('j F Y', $ts) : ($a['date'] ?? ''),
        'summary' => $a['summary'] ?? '',
        'content' => $a['content'] ?? '',
        'image'   => $a['image'] ?? '',
        'video'   => $a['video'] ?? '',
        'pinned'  => 1,
    ];
}, $pinnedArticles), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">var PINNED_ARTICLES = <?php echo $pinnedJson; ?>;
</script>

<?php endif; ?>

<?php if (!empty($siteSettings['pinned_below_text'])): ?>
<p class="pinned-below-text"><?php echo nl2br(escape($siteSettings['pinned_below_text'] ?? '')); ?></p>
<?php endif; ?>

<?php endif; ?>

</div>
</section>


</main>

<!-- Modale article (accueil) -->
<div class="article-modal" id="home-article-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="home-article-modal-title">
    <div class="article-modal-backdrop" id="home-article-modal-backdrop"></div>
    <div class="article-modal-dialog">
        <button class="article-modal-close" type="button" id="home-article-modal-close" aria-label="Fermer">&#215;</button>
        <div class="article-modal-header">
            <div class="article-modal-meta">
                <span class="article-modal-date" id="home-article-modal-date"></span>
                <span id="home-article-modal-pinned" style="display:none" class="news-pinned-badge">📌 Épinglé</span>
            </div>
            <div class="article-modal-title-row">
                <img class="article-modal-img" id="home-article-modal-img" src="" alt="" style="display:none">
                <h2 class="article-modal-title" id="home-article-modal-title"></h2>
            </div>
        </div>
        <div class="article-modal-body">
            <div class="article-modal-media-row">
                <div class="article-modal-video-wrap" id="home-article-modal-video-wrap" style="display:none"></div>
                <div class="article-modal-text-col">
                    <p class="article-modal-summary" id="home-article-modal-summary" style="display:none"></p>
                    <div class="article-modal-content" id="home-article-modal-content"></div>
                </div>
            </div>
        </div>
    </div>
</div>


<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">



(function(){
/* ── Carousel épinglés + modale article accueil ── */
var track   = document.getElementById('hero-carousel-track');
var prevBtn = document.getElementById('carousel-prev');
var nextBtn = document.getElementById('carousel-next');
var dots    = document.querySelectorAll('[data-carousel-dot]');
var modal   = document.getElementById('home-article-modal');
var backdrop= document.getElementById('home-article-modal-backdrop');
var closeBtn= document.getElementById('home-article-modal-close');
var imgEl   = document.getElementById('home-article-modal-img');
var dateEl  = document.getElementById('home-article-modal-date');
var pinnedEl= document.getElementById('home-article-modal-pinned');
var titleEl = document.getElementById('home-article-modal-title');
var summaryEl= document.getElementById('home-article-modal-summary');
var contentEl= document.getElementById('home-article-modal-content');
var modalBody= modal ? modal.querySelector('.article-modal-body') : null;

var articlesMap = {};
if (typeof PINNED_ARTICLES !== 'undefined') {
    PINNED_ARTICLES.forEach(function(a){ articlesMap[a.id] = a; });
}
if (typeof DASH_NEWS !== 'undefined') {
    DASH_NEWS.forEach(function(a){ articlesMap[a.id] = a; });
}

/* ─ Vidéo embed ─ */
var videoWrap = document.getElementById('home-article-modal-video-wrap');
function buildVideoEmbed(url) {
    if (!url) return '';
    // YouTube — iframe intégrée
    var yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/);
    if (yt) {
        var ytId = yt[1];
        return '<iframe src="https://www.youtube-nocookie.com/embed/' + ytId + '?rel=0" allowfullscreen title="Vidéo YouTube" class="article-modal-iframe" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin"></iframe>';
    }
    var vi = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    if (vi) return '<iframe src="https://player.vimeo.com/video/'+vi[1]+'" allowfullscreen title="Vidéo Vimeo" class="article-modal-iframe"></iframe>';
    if (/\.mp4|\.webm|\.ogv/i.test(url)) return '<video controls class="article-modal-video"><source src="'+url+'"></video>';
    return '';
}
/* ─ Modale ─ */
function openModal(id) {
    var a = articlesMap[id];
    if (!a || !modal) return;
    if (a.image) { imgEl.src = a.image; imgEl.style.display = 'block'; }
    else         { imgEl.style.display = 'none'; imgEl.src = ''; }
    dateEl.textContent = a.date;
    titleEl.textContent = a.title;
    if (pinnedEl) pinnedEl.style.display = a.pinned ? 'inline-flex' : 'none';
    if (a.summary) { summaryEl.textContent = a.summary; summaryEl.style.display = 'block'; }
    else           { summaryEl.style.display = 'none'; }
    if (videoWrap) {
        var embed = buildVideoEmbed(a.video || '');
        videoWrap.innerHTML = embed;
        videoWrap.style.display = embed ? 'block' : 'none';
        if (modalBody) modalBody.classList.toggle('has-video', !!embed);
    }
    contentEl.innerHTML = a.content ? a.content.replace(/\n/g,'<br>') : '';
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden'; document.documentElement.style.overflow = 'hidden';
    modal.scrollTop = 0;
    if (closeBtn) closeBtn.focus();
}
function closeModal() {
    if (!modal) return;
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow = ''; document.documentElement.style.overflow = '';
    if (videoWrap) { videoWrap.innerHTML = ''; videoWrap.style.display = 'none'; }
    if (modalBody) modalBody.classList.remove('has-video');
}

document.querySelectorAll('[data-open-article-home]').forEach(function(btn) {
    btn.addEventListener('click', function() { openModal(btn.getAttribute('data-open-article-home')); });
});
if (closeBtn) closeBtn.addEventListener('click', closeModal);
if (modal) modal.addEventListener('click', function(e){ if (e.target === modal) closeModal(); });
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeModal(); });
// Fermer le panneau admin en cliquant à l'extérieur
var adminOverlay = document.querySelector('.admin-panel-overlay');
if (adminOverlay) {
    adminOverlay.addEventListener('click', function(e){
        if (e.target === adminOverlay) {
            adminOverlay.classList.add('is-closing');
            setTimeout(function() {
                adminOverlay.classList.remove('is-closing');
                adminOverlay.style.display = 'none';
                if (window.history && window.history.pushState) {
                    var u = new URL(window.location.href);
                    u.searchParams.delete('panel'); u.searchParams.delete('tab'); u.hash = '';
                    window.history.pushState({}, '', u.toString());
                }
            }, 210);
        }
    });
}

/* ─ Carousel scroll ─ */
if (!track) return;
var current = 0;
var items = track.querySelectorAll('.hero-news-vignette');
var total  = items.length;
if (total <= 1) return;

function scrollTo(idx) {
    current = Math.max(0, Math.min(idx, total - 1));
    var item = items[current];
    if (item) {
        track.scrollTo({ left: item.offsetLeft - track.offsetLeft, behavior: 'smooth' });
    }
    dots.forEach(function(d, i) { d.classList.toggle('is-active', i === current); });
}
if (prevBtn) prevBtn.addEventListener('click', function() { scrollTo(current - 1); });
if (nextBtn) nextBtn.addEventListener('click', function() { scrollTo(current + 1); });
dots.forEach(function(d) {
    d.addEventListener('click', function() { scrollTo(parseInt(d.getAttribute('data-carousel-dot'))); });
});

// Sync dots on manual scroll
var scrollTimer;
track.addEventListener('scroll', function() {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function() {
        var center = track.scrollLeft + track.clientWidth / 2;
        var closest = 0, minDist = Infinity;
        items.forEach(function(item, i) {
            var dist = Math.abs((item.offsetLeft + item.offsetWidth / 2) - center);
            if (dist < minDist) { minDist = dist; closest = i; }
        });
        if (closest !== current) {
            current = closest;
            dots.forEach(function(d, i) { d.classList.toggle('is-active', i === current); });
        }
    }, 80);
});

// Auto-play toutes les 5 secondes si plusieurs vignettes
var autoPlay = setInterval(function() {
    scrollTo(current < total - 1 ? current + 1 : 0);
}, 5000);
track.addEventListener('mouseenter', function() { clearInterval(autoPlay); });
track.addEventListener('touchstart', function() { clearInterval(autoPlay); }, {passive:true});
})();

<?php if ($isUserAuthenticated): ?>
/* ── Mise à jour automatique des widgets du tableau de bord ── */
(function(){
    function setTxt(id, val) { var el = document.getElementById(id); if (el) el.textContent = val; }
    function showDot(id, show) { var el = document.getElementById(id); if (el) el.style.display = show ? '' : 'none'; }
    function toggleBadge(id, on) { var el = document.getElementById(id); if (el) el.classList.toggle('has-badge', on); }

    window.addEventListener('dashpollupdate', function(e) {
        var d = e.detail;
        if (!d) return;
        /* Messages non lus */
        var msgs = d.unread_messages || 0;
        setTxt('dash-num-messages', msgs);
        showDot('dash-dot-messages', msgs > 0);
        setTxt('dash-hint-messages', 'non lu' + (msgs > 1 ? 's' : ''));
        toggleBadge('dash-card-messages', msgs > 0);
        /* Partages non vus */
        var shares = d.unseen_shares || 0;
        showDot('dash-dot-shares', shares > 0);
        toggleBadge('dash-card-shares', shares > 0);
    });
}());
<?php endif; ?>

</script>

<!-- ══════════════════════════════════════════════════════════════
     MODALES UTILISATEURS
     ══════════════════════════════════════════════════════════════ -->

<!-- Modale Connexion -->
<div class="user-modal<?php echo (isset($_GET['show_login']) || $isPrivateGuestView || isset($_GET['need_login'])) && !$isUserAuthenticated && !$isAdminAuthenticated ? ' is-open' : ''; ?>" id="login-modal" data-user-modal="login">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>

        <h2 class="user-modal-title">Connexion</h2>
        <?php if ($maintenanceEnabled): ?>
        <p class="user-modal-subtitle user-modal-maintenance-notice">
            ⚠️ Le site est en cours de maintenance. Seuls les administrateurs peuvent se connecter.
        </p>
        <?php else: ?>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['login_message'] ?? 'Connectez-vous pour accéder au site.'); ?></p>
        <?php endif; ?>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="login_user">
            
            <div class="user-field">
                <label for="login_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="login_username" 
                    name="login_username" 
                    placeholder="Votre nom d'utilisateur"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="login_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="login_password" 
                    name="login_password" 
                    placeholder="Votre mot de passe"
                    required
                    autocomplete="current-password"
                >
            </div>
            
            <button type="submit" class="user-submit-btn">Se connecter</button>
        </form>
        
        <?php if ($allowRegistration): ?>
        <div class="user-modal-footer">
            Pas encore de compte ? <button type="button" data-switch-to-register>S'inscrire</button>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modale Inscription -->
<?php if ($allowRegistration): ?>
<div class="user-modal<?php echo isset($_GET['show_register']) ? ' is-open' : ''; ?>" id="register-modal" data-user-modal="register">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Inscription</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['registration_message'] ?? 'Créez un compte pour accéder au contenu.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="register_user">
            
            <div class="user-field">
                <label for="register_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="register_username" 
                    name="register_username" 
                    placeholder="Minimum 3 caractères"
                    minlength="3"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="register_email">Email</label>
                <input 
                    type="email" 
                    id="register_email" 
                    name="register_email" 
                    placeholder="votre@email.com"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="register_password" 
                    name="register_password" 
                    placeholder="Minimum 6 caractères"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password_confirm">Confirmer le mot de passe</label>
                <input 
                    type="password" 
                    id="register_password_confirm" 
                    name="register_password_confirm" 
                    placeholder="Retapez votre mot de passe"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="discovered_from">Comment avez-vous connu ce site ? (optionnel)</label>
                <input 
                    type="text" 
                    id="discovered_from" 
                    name="discovered_from" 
                    placeholder="Google, Discord, un ami..."
                >
            </div>
            
            <button type="submit" class="user-submit-btn">S'inscrire</button>
        </form>
        
        <div class="user-modal-footer">
            Déjà un compte ? <button type="button" data-switch-to-login>Se connecter</button>
        </div>
    </div>
</div>
<?php endif; ?>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
/* ══════════════════════════════════════════════════════════════
   GESTION DES MODALES UTILISATEURS
   ══════════════════════════════════════════════════════════════ */
(function() {
    var loginModal = document.getElementById('login-modal');
    var registerModal = document.getElementById('register-modal');
    
    // Boutons d'ouverture
    var loginOpenBtns = document.querySelectorAll('[data-user-login-open]');
    var registerOpenBtns = document.querySelectorAll('[data-user-register-open]');
    
    // Boutons de fermeture
    var closeBtns = document.querySelectorAll('[data-user-modal-close]');
    
    // Boutons de bascule
    var switchToRegisterBtns = document.querySelectorAll('[data-switch-to-register]');
    var switchToLoginBtns = document.querySelectorAll('[data-switch-to-login]');
    
    // Fonctions d'ouverture/fermeture
    function openModal(modal) {
        if (modal) {
            modal.classList.add('is-open');
            document.body.style.overflow = 'hidden'; document.documentElement.style.overflow = 'hidden';
        }
    }
    
    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('is-open');
            document.body.style.overflow = ''; document.documentElement.style.overflow = '';
        }
    }
    
    function closeAllModals() {
        closeModal(loginModal);
        closeModal(registerModal);
    }
    
    // Ouvrir connexion
    loginOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(loginModal);
        });
    });
    
    // Ouvrir inscription
    registerOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(registerModal);
        });
    });
    
    // Fermer
    closeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var modal = btn.closest('[data-user-modal]');
            closeModal(modal);
        });
    });
    
    // Basculer vers inscription
    switchToRegisterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(loginModal);
            openModal(registerModal);
        });
    });
    
    // Basculer vers connexion
    switchToLoginBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(registerModal);
            openModal(loginModal);
        });
    });
    
    // Fermer au clic sur le backdrop
    [loginModal, registerModal].forEach(function(modal) {
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        }
    });
    
    // Fermer avec Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
})();

</script>

</div><!-- #spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
</body>
</html>
