<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

if (!$isUserAuthenticated && !$isAdminAuthenticated) {
    header('Location: /index.php?show_login=1'); exit;
}
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php'); exit;
}

$flash = getFlash();

/* ── Répertoires ─────────────────────────────────────────────── */
$romsBase  = __DIR__ . '/web_private/roms';          // hors webroot
$coversDir = __DIR__ . '/assets/roms/covers';       // public (jaquettes)

/* ── Toutes les plateformes connues + cœur EmulatorJS associé ── */
/* Un onglet n'est affiché que si le fichier core *-wasm.data existe. */
$coresDir = __DIR__ . '/assets/emulatorjs/cores';
$allPlatforms = [
    /* ── Nintendo ─────────────────────────────────────────────── */
    'snes'      => ['label' => 'Super Nintendo',      'exts' => ['sfc','smc','fig','swc','zip','gz','7z'],               'core' => 'snes9x'],
    'nes'       => ['label' => 'NES / Famicom',       'exts' => ['nes','fds','unf','unif','zip','gz','7z'],              'core' => 'fceumm'],
    'n64'       => ['label' => 'Nintendo 64',         'exts' => ['z64','n64','v64','zip','gz','7z'],                     'core' => 'mupen64plus_next'],
    'gba'       => ['label' => 'Game Boy Advance',    'exts' => ['gba','zip','gz','7z'],                                 'core' => 'mgba'],
    'gb'        => ['label' => 'Game Boy / Color',    'exts' => ['gb','gbc','zip','gz','7z'],                            'core' => 'gambatte'],
    'nds'       => ['label' => 'Nintendo DS',         'exts' => ['nds','zip','gz','7z'],                                 'core' => 'melonds'],
    /* ── Sony ─────────────────────────────────────────────────── */
    'psx'       => ['label' => 'PlayStation',         'exts' => ['bin','cue','img','iso','pbp','chd','zip','gz','7z'],   'core' => 'pcsx_rearmed'],
    'psp'       => ['label' => 'PlayStation Portable','exts' => ['iso','cso','pbp','zip','gz','7z'],                     'core' => 'ppsspp'],
    /* ── Sega ─────────────────────────────────────────────────── */
    'md'        => ['label' => 'Mega Drive',          'exts' => ['md','bin','smd','gen','zip','gz','7z'],                'core' => 'genesis_plus_gx'],
    'sega32x'   => ['label' => 'Sega 32X',            'exts' => ['32x','bin','zip','gz','7z'],                           'core' => 'picodrive'],
    'segacd'    => ['label' => 'Mega-CD',             'exts' => ['bin','cue','iso','chd','zip','gz','7z'],               'core' => 'genesis_plus_gx'],
    'saturn'    => ['label' => 'Saturn',              'exts' => ['bin','cue','iso','chd','zip','gz','7z'],               'core' => 'yabause'],
    'sms'       => ['label' => 'Master System',       'exts' => ['sms','zip','gz','7z'],                                 'core' => 'smsplus'],
    'gg'        => ['label' => 'Game Gear',           'exts' => ['gg','zip','gz','7z'],                                  'core' => 'smsplus'],
    /* ── NEC ───────────────────────────────────────────────────── */
    'pce'       => ['label' => 'PC Engine',           'exts' => ['pce','zip','gz','7z'],                                 'core' => 'mednafen_pce'],
    'pcfx'      => ['label' => 'PC-FX',               'exts' => ['img','iso','zip','gz','7z'],                           'core' => 'mednafen_pcfx'],
    /* ── Arcade ────────────────────────────────────────────────── */
    'arcade'    => ['label' => 'Arcade',              'exts' => ['zip','7z'],                                            'core' => 'fbneo'],
    /* ── Atari ─────────────────────────────────────────────────── */
    'jaguar'    => ['label' => 'Atari Jaguar',        'exts' => ['j64','jag','zip','gz','7z'],                           'core' => 'virtualjaguar'],
    'lynx'      => ['label' => 'Atari Lynx',          'exts' => ['lnx','zip','gz','7z'],                                 'core' => 'handy'],
    /* ── SNK ───────────────────────────────────────────────────── */
    'ngp'       => ['label' => 'Neo Geo Pocket',      'exts' => ['ngp','ngc','zip','gz','7z'],                           'core' => 'mednafen_ngp'],
    /* ── Bandai ────────────────────────────────────────────────── */
    'ws'        => ['label' => 'WonderSwan',          'exts' => ['ws','wsc','zip','gz','7z'],                            'core' => 'mednafen_wswan'],
    /* ── Coleco ────────────────────────────────────────────────── */
    'coleco'    => ['label' => 'ColecoVision',        'exts' => ['col','cv','zip','gz','7z'],                            'core' => 'gearcoleco'],
    /* ── Ordinateurs ───────────────────────────────────────────── */
    'amiga'     => ['label' => 'Amiga',               'exts' => ['adf','hdf','zip','gz','7z'],                           'core' => 'puae'],
    'c64'       => ['label' => 'Commodore 64',        'exts' => ['d64','t64','prg','crt','tap','zip','gz','7z'],         'core' => 'vice_x64sc'],
    'c128'      => ['label' => 'Commodore 128',       'exts' => ['d64','t64','prg','zip','gz','7z'],                     'core' => 'vice_x128'],
];

/* Filtre : uniquement les plateformes dont le core est disponible
   (vérifie aussi les variantes -legacy et -thread pour les cores
   qui n'ont pas de version non-threadée, ex. ppsspp / dosbox_pure) */
$platforms = array_filter($allPlatforms, function($pdef) use ($coresDir) {
    $c = $pdef['core'];
    return file_exists($coresDir . '/' . $c . '-wasm.data')
        || file_exists($coresDir . '/' . $c . '-legacy-wasm.data')
        || file_exists($coresDir . '/' . $c . '-thread-wasm.data')
        || file_exists($coresDir . '/' . $c . '-thread-legacy-wasm.data');
});

/* ── Charger la liste des jeux depuis private/roms/ ─────────── */
$allGames = [];
foreach ($platforms as $pid => $pdef) {
    $dir   = $romsBase . '/' . $pid;
    $games = [];
    if (is_dir($dir)) {
        foreach (scandir($dir) ?: [] as $f) {
            if ($f[0] === '.') continue;
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            if (!in_array($ext, $pdef['exts'])) continue;
            $name  = pathinfo($f, PATHINFO_FILENAME);
            $label = trim(preg_replace('/\s*[\(\[][^\)\]]*[\)\]]\s*/', '', $name));
            $size  = filesize($dir . '/' . $f);
            /* ── Médias : stockés dans web_private/roms/{pid}/media/{name}/ ── */
            $mediaPriv = $romsBase . '/' . $pid . '/media/' . $name;
            $mediaApi  = '/api/rom-media.php?pid=' . rawurlencode($pid) . '&name=' . rawurlencode($name);
            $cover = '';
            foreach (['png','jpg','webp','jpeg'] as $ce) {
                if (is_file($mediaPriv . '/cover.' . $ce)) { $cover = $mediaApi . '&type=cover'; break; }
            }
            if (!$cover) {
                /* Fallback : ancien dossier assets/roms/covers/ */
                foreach (['png','jpg','webp','jpeg'] as $ce) {
                    $cp = __DIR__ . '/assets/roms/covers/' . $name . '.' . $ce;
                    if (file_exists($cp)) { $cover = 'assets/roms/covers/' . $name . '.' . $ce; break; }
                }
            }
            $fanart = '';
            foreach (['jpg','png','webp','jpeg'] as $fe) {
                if (is_file($mediaPriv . '/fanart.' . $fe)) { $fanart = $mediaApi . '&type=fanart'; break; }
            }
            $video = '';
            foreach (['mp4','webm'] as $ve) {
                if (is_file($mediaPriv . '/video.' . $ve)) { $video = $mediaApi . '&type=video'; break; }
            }
            /* ── Métadonnées ── */
            $meta = [];
            if (is_file($mediaPriv . '/meta.json')) {
                $meta = json_decode(file_get_contents($mediaPriv . '/meta.json'), true) ?: [];
            }
            $games[] = [
                'file'        => $f,
                'name'        => $meta['custom_name'] ?? $label,
                'raw'         => $name,
                'cover'       => $cover,
                'fanart'      => $fanart,
                'video'       => $video,
                'description' => $meta['description'] ?? '',
                'size'        => $size,
                'platform'    => $pid,
            ];
        }
        usort($games, fn($a,$b) => strcmp($a['name'], $b['name']));
    }
    $allGames[$pid] = $games;
}

/* ── Supprimer une ROM (admin) ───────────────────────────────── */
if ($isAdminAuthenticated && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_rom'])) {
    if (!hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
        setFlash('error', 'Token CSRF invalide.'); header('Location: jeux-retro.php'); exit;
    }
    $pid  = preg_replace('/[^a-z]/', '', $_POST['platform'] ?? '');
    $file = basename($_POST['filename'] ?? '');
    if ($pid && $file && isset($platforms[$pid])) {
        $path = $romsBase . '/' . $pid . '/' . $file;
        if (is_file($path)) { unlink($path); setFlash('success', 'ROM supprimée.'); }
    }
    header('Location: jeux-retro.php'); exit;
}

function fmtSize(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes/1048576, 1) . ' Mo';
    if ($bytes >= 1024)    return round($bytes/1024)      . ' Ko';
    return $bytes . ' o';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Jeux Rétro – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<link rel="stylesheet" href="assets/css/jeux-retro.css?v=16">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<div id="spa-page">
<main class="page is-dashboard"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="<?php echo ($shouldAutoOpenAdminModal ?? false) ? '1' : '0'; ?>">

<section class="hero retro-hero is-centered-v" aria-label="Jeux Rétro">
<div class="hero-content is-dashboard">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>


<div class="msg-tabs-row">
    <nav class="msg-tabs" id="retro-tabs" aria-label="Plateformes">
        <?php foreach ($platforms as $pid => $pdef): ?>
        <button class="msg-tab-btn<?php echo $pid === 'snes' ? ' is-active' : ''; ?>"
                data-platform="<?php echo escapeAttribute($pid); ?>"
                type="button">
            <?php echo escape($pdef['emoji'] . ' ' . $pdef['label']); ?>
        </button>
        <?php endforeach; ?>
    </nav>
</div>


<?php foreach ($platforms as $pid => $pdef): ?>
<div class="retro-platform-panel" id="panel-<?php echo escapeAttribute($pid); ?>"<?php echo $pid !== 'snes' ? ' hidden' : ''; ?>>
    <?php $games = $allGames[$pid]; ?>
    <?php if (empty($games)): ?>
    <div class="retro-empty">
        <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
            <rect x="2" y="6" width="20" height="12" rx="2"/>
            <path d="M12 12h.01M8 12a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM18 12a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
        </svg>
        <h3 style="color:var(--muted);font-size:1rem;font-weight:600;margin:.5rem 0 0">Aucun jeu disponible</h3>
        <p>Revenez bientôt.</p>
    </div>
    <?php else: ?>
    <p class="retro-count"><?php echo count($games); ?> jeu<?php echo count($games) > 1 ? 'x' : ''; ?></p>
    <div class="retro-grid">
        <?php foreach ($games as $g): ?>
        <div class="retro-card<?php echo $g['fanart'] ? ' has-fanart' : ''; ?>"
             data-name="<?php echo escapeAttribute($g['name']); ?>"
             data-file="<?php echo escapeAttribute($g['file']); ?>"
             data-raw="<?php echo escapeAttribute($g['raw']); ?>"
             data-platform="<?php echo escapeAttribute($pid); ?>"
             data-core="<?php echo escapeAttribute($pdef['core']); ?>"
             data-cover="<?php echo escapeAttribute($g['cover']); ?>"
             data-fanart="<?php echo escapeAttribute($g['fanart']); ?>"
             data-video="<?php echo escapeAttribute($g['video']); ?>"
             data-description="<?php echo escapeAttribute($g['description']); ?>"
             data-size="<?php echo escapeAttribute(fmtSize($g['size'])); ?>"
             data-label="<?php echo escapeAttribute($pdef['label']); ?>"
             tabindex="0" role="button"
             aria-label="<?php echo escapeAttribute($g['name']); ?>">
            <?php if ($g['fanart'] && !$g['cover']): ?>
            <div class="retro-card-fanart-bg" style="background-image:url('<?php echo escapeAttribute($g['fanart']); ?>')"></div>
            <?php endif; ?>
            <?php if ($g['cover']): ?>
            <img class="retro-card-cover"
                 src="<?php echo escapeAttribute($g['cover']); ?>"
                 alt="<?php echo escapeAttribute($g['name']); ?>"
                 loading="lazy">
            <?php elseif (!$g['fanart']): ?>
            <div class="retro-card-placeholder"><?php echo $pdef['emoji']; ?></div>
            <?php endif; ?>
            <div class="retro-card-body">
                <div class="retro-card-name" title="<?php echo escapeAttribute($g['name']); ?>">
                    <?php echo escape($g['name']); ?>
                </div>
                <div class="retro-card-meta">
                    <?php echo escape($pdef['label']); ?> · <?php echo fmtSize($g['size']); ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<!-- Admin : formulaires de suppression (hors grille pour éviter les nested forms) -->
<?php if ($isAdminAuthenticated): ?>
<div id="retro-delete-forms" hidden>
<?php foreach ($platforms as $pid => $pdef): foreach ($allGames[$pid] as $g): ?>
<form method="post" action="jeux-retro.php" id="del-<?php echo escapeAttribute($pid.'-'.$g['file']); ?>" class="retro-delete-form">
    <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
    <input type="hidden" name="delete_rom" value="1">
    <input type="hidden" name="platform" value="<?php echo escapeAttribute($pid); ?>">
    <input type="hidden" name="filename" value="<?php echo escapeAttribute($g['file']); ?>">
</form>
<?php endforeach; endforeach; ?>
</div>
<?php endif; ?>

</div><!-- /.hero-content -->
</section><!-- /.hero -->
</main>

<!-- ── Overlay Fiche du jeu ──────────────────────────────────── -->
<div class="retro-game-overlay" id="retro-game-overlay" aria-modal="true" role="dialog" aria-hidden="true">
    <button class="retro-game-close" id="retro-game-close" type="button" aria-label="Fermer">&#215;</button>
    <div class="retro-game-card" id="retro-game-card">
        <div class="retro-game-fanart-wrap" id="retro-game-fanart-wrap" hidden></div>
        <div id="retro-game-cover-wrap"></div>
        <div class="retro-game-card-body">
            <div class="retro-game-card-title" id="retro-game-title"></div>
            <div class="retro-game-card-meta" id="retro-game-meta"></div>
            <div class="retro-game-card-desc" id="retro-game-desc" hidden></div>
            <div class="retro-game-card-video-wrap" id="retro-game-video-wrap" hidden>
                <video class="retro-game-card-video" id="retro-game-video"
                       controls preload="none" playsinline></video>
            </div>
            <div class="retro-game-card-actions">
                <button class="retro-game-play-btn" id="retro-game-play" type="button">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                        <polygon points="5 3 19 12 5 21 5 3"/>
                    </svg>
                    Jouer
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ── Overlay Émulateur ─────────────────────────────────────── -->
<div class="retro-emu-overlay" id="retro-emu-overlay" aria-modal="true" role="dialog" aria-hidden="true">
    <div class="retro-emu-backdrop" aria-hidden="true"></div>
    <div class="retro-emu-box">
        <div class="retro-emu-bar">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" style="color:var(--primary);flex-shrink:0">
                <rect x="2" y="6" width="20" height="12" rx="2"/>
                <path d="M12 12h.01M8 12a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM18 12a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                <line x1="9" y1="9" x2="9" y2="15"/><line x1="6" y1="12" x2="12" y2="12"/>
            </svg>
            <span class="retro-emu-bar-title" id="retro-emu-title"></span>
            <button class="retro-emu-bar-btn" id="retro-emu-close" type="button" aria-label="Quitter">&#215;</button>
        </div>
        <div class="retro-emu-body" id="retro-emu-body"></div>
    </div>
</div>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
(function () {
    var ROM_API  = 'api/rom-serve.php';
    var IS_ADMIN = <?php echo $isAdminAuthenticated ? 'true' : 'false'; ?>;

    /* Confirmation suppression ROM (remplace onsubmit inline interdit par CSP) */
    document.querySelectorAll('.retro-delete-form').forEach(function(f) {
        f.addEventListener('submit', function(e) {
            if (!confirm('Supprimer cette ROM ?')) e.preventDefault();
        });
    });

    /* ── Onglets plateforme ─────────────────────────────── */
    var tabsNav    = document.getElementById('retro-tabs');
    var tabs       = document.querySelectorAll('#retro-tabs .msg-tab-btn');
    var panels     = document.querySelectorAll('.retro-platform-panel');

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            var pid = tab.getAttribute('data-platform');
            tabs.forEach(function (t) { t.classList.toggle('is-active', t === tab); });
            panels.forEach(function (p) {
                if (p.id === 'panel-' + pid) p.removeAttribute('hidden');
                else p.setAttribute('hidden', '');
            });
            /* Faire défiler l'onglet actif dans la vue */
            tab.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
        });
    });

    /* ── Overlay fiche jeu ──────────────────────────────── */
    var gameOverlay    = document.getElementById('retro-game-overlay');
    var gameClose      = document.getElementById('retro-game-close');
    var gameCard       = document.getElementById('retro-game-card');
    var fanartWrap     = document.getElementById('retro-game-fanart-wrap');
    var coverWrap      = document.getElementById('retro-game-cover-wrap');
    var titleEl        = document.getElementById('retro-game-title');
    var metaEl         = document.getElementById('retro-game-meta');
    var descEl         = document.getElementById('retro-game-desc');
    var videoWrap      = document.getElementById('retro-game-video-wrap');
    var videoEl        = document.getElementById('retro-game-video');
    var playBtn        = document.getElementById('retro-game-play');
    var currentGame    = null;

    function openGameOverlay(card) {
        currentGame = {
            name:        card.getAttribute('data-name'),
            file:        card.getAttribute('data-file'),
            raw:         card.getAttribute('data-raw'),
            platform:    card.getAttribute('data-platform'),
            core:        card.getAttribute('data-core'),
            cover:       card.getAttribute('data-cover'),
            fanart:      card.getAttribute('data-fanart') || '',
            video:       card.getAttribute('data-video')  || '',
            description: card.getAttribute('data-description') || '',
            size:        card.getAttribute('data-size'),
            label:       card.getAttribute('data-label'),
        };

        /* Fanart en fond */
        if (currentGame.fanart) {
            fanartWrap.style.backgroundImage = "url('" + currentGame.fanart.replace(/'/g, "\\'") + "')";
            fanartWrap.removeAttribute('hidden');
            gameCard.classList.add('has-fanart');
        } else {
            fanartWrap.setAttribute('hidden', '');
            gameCard.classList.remove('has-fanart');
        }

        /* Jaquette */
        coverWrap.innerHTML = '';
        if (currentGame.cover) {
            var img = document.createElement('img');
            img.className = 'retro-game-card-cover';
            img.src = currentGame.cover;
            img.alt = currentGame.name;
            coverWrap.appendChild(img);
        } else if (!currentGame.fanart) {
            var ph = document.createElement('div');
            ph.className = 'retro-game-card-placeholder';
            ph.textContent = '🎮';
            coverWrap.appendChild(ph);
        }

        titleEl.textContent = currentGame.name;
        metaEl.textContent  = currentGame.label + ' · ' + currentGame.size;

        /* Description */
        if (currentGame.description) {
            descEl.textContent = currentGame.description;
            descEl.removeAttribute('hidden');
        } else {
            descEl.setAttribute('hidden', '');
        }

        /* Vidéo */
        if (currentGame.video) {
            videoEl.src = currentGame.video;
            videoWrap.removeAttribute('hidden');
        } else {
            videoEl.removeAttribute('src');
            videoEl.load();
            videoWrap.setAttribute('hidden', '');
        }

        gameOverlay.classList.add('is-open');
        gameOverlay.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        document.body.classList.add('has-overlay-open');
    }

    function closeGameOverlay() {
        gameOverlay.classList.remove('is-open');
        gameOverlay.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        document.body.classList.remove('has-overlay-open');
        if (videoEl) { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); }
        currentGame = null;
    }

    gameClose.addEventListener('click', closeGameOverlay);
    gameOverlay.addEventListener('click', function (e) {
        if (e.target === gameOverlay) closeGameOverlay();
    });

    /* ── Cartes de jeu ──────────────────────────────────── */
    document.querySelectorAll('.retro-card').forEach(function (card) {
        function open() { openGameOverlay(card); }
        card.addEventListener('click', open);
        card.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
        });
    });

    /* ── Overlay émulateur ──────────────────────────────── */
    var emuOverlay = document.getElementById('retro-emu-overlay');
    var emuTitle   = document.getElementById('retro-emu-title');
    var emuBody    = document.getElementById('retro-emu-body');
    var emuClose   = document.getElementById('retro-emu-close');

    /* Portal : déplacer l'overlay en enfant direct de <body> pour qu'il
       survive quand body.has-emu-open cache #spa-page et les autres enfants. */
    if (gameOverlay && gameOverlay.parentElement !== document.body) {
        document.body.appendChild(gameOverlay);
    }
    if (emuOverlay && emuOverlay.parentElement !== document.body) {
        document.body.appendChild(emuOverlay);
    }

    function launchEmulator(game) {
        emuTitle.textContent = game.name;
        emuOverlay.classList.add('is-open');
        emuOverlay.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        document.body.classList.add('has-overlay-open');
        document.body.classList.add('has-emu-open'); /* cache tout sauf l'overlay → réduit les layers GPU */

        var url = 'retro-player.php'
            + '?pid='  + encodeURIComponent(game.platform)
            + '&file=' + encodeURIComponent(game.file)
            + '&core=' + encodeURIComponent(game.core)
            + '&name=' + encodeURIComponent(game.name);

        emuBody.innerHTML = '';
        var iframe = document.createElement('iframe');
        iframe.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:none;display:block;';
        iframe.setAttribute('allowfullscreen', '');
        iframe.setAttribute('allow', 'fullscreen; gamepad');
        iframe.src = url;
        /* Focus l'iframe dès qu'elle est chargée pour que le navigateur
           expose navigator.getGamepads() dans son contexte (requis par l'API Gamepad). */
        iframe.addEventListener('load', function () {
            try { iframe.contentWindow.focus(); } catch (e) {}
        });
        emuBody.appendChild(iframe);
        iframe.focus();
    }

    function closeEmulator() {
        /* Déclencher la sauvegarde SRAM depuis le parent avant de détruire l'iframe,
           car pagehide/beforeunload ne se déclenchent pas de façon fiable sur tous
           les navigateurs lors d'une suppression DOM programmatique. */
        var iframeEl = emuBody.querySelector('iframe');
        if (iframeEl && iframeEl.contentWindow) {
            try {
                if (typeof iframeEl.contentWindow._flushSram === 'function') {
                    iframeEl.contentWindow._flushSram();
                }
            } catch (e) {}
        }
        emuOverlay.classList.remove('is-open');
        emuOverlay.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        document.body.classList.remove('has-overlay-open');
        document.body.classList.remove('has-emu-open');
        emuBody.innerHTML = '';
    }

    emuClose.addEventListener('click', closeEmulator);
    emuOverlay.addEventListener('click', function (e) {
        if (e.target === emuOverlay || e.target.classList.contains('retro-emu-backdrop')) closeEmulator();
    });

    playBtn.addEventListener('click', function () {
        if (!currentGame) return;
        var game = currentGame;
        // On ne ferme plus l'overlay de détail pour qu'il reste en arrière-plan
        // closeGameOverlay();
        launchEmulator(game);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            if (emuOverlay.classList.contains('is-open')) { closeEmulator(); return; }
            if (gameOverlay.classList.contains('is-open')) { closeGameOverlay(); return; }
        }
    });

    /* ── Ouverture directe depuis la recherche globale ──────────────
       Expose window.retroOpenGame(pid, file) pour la recherche sur
       cette page, et gère le hash #retro-open:pid:file à l'arrivée
       depuis une autre page. */
    window.retroOpenGame = function(pid, file) {
        var card = null;
        document.querySelectorAll('.retro-card').forEach(function(c) {
            if (c.getAttribute('data-platform') === pid && c.getAttribute('data-file') === file) card = c;
        });
        if (!card) return;
        /* Switcher sur le bon onglet plateforme d'abord */
        var tab = document.querySelector('#retro-tabs .msg-tab-btn[data-tab="' + CSS.escape(pid) + '"]');
        if (tab) tab.click();
        openGameOverlay(card);
    };

    function handleRetroHash() {
        var hash = window.location.hash;
        if (!hash.startsWith('#retro-open:')) return;
        var parts = hash.slice('#retro-open:'.length).split(':');
        if (parts.length < 2) return;
        var pid  = decodeURIComponent(parts[0]);
        var file = decodeURIComponent(parts.slice(1).join(':'));
        history.replaceState(null, '', window.location.pathname);
        /* Laisser le temps au DOM de s'initialiser après navigation SPA */
        setTimeout(function() { window.retroOpenGame(pid, file); }, 100);
    }
    handleRetroHash();
    window.addEventListener('hashchange', handleRetroHash);
}());
</script>

<?php if ($isAdminAuthenticated) require __DIR__ . '/includes/jeux-retro-admin.php'; ?>
</div><!-- /#spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
</body>
</html>
