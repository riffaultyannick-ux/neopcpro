<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';

if (!$isUserAuthenticated && !$isAdminAuthenticated) {
    header('Location: /index.php?show_login=1'); exit;
}
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php'); exit;
}

$flash = getFlash();

/* ── Jours fériés français ──────────────────────────────────── */
function calFrHolidays(int $year): array {
    // Pâques (algorithme de Meeus/Jones/Butcher)
    $a = $year % 19; $b = (int)($year/100); $c = $year % 100;
    $d = (int)($b/4); $e = $b % 4; $f = (int)(($b+8)/25);
    $g = (int)(($b-$f+1)/3); $h = (19*$a+$b-$d-$g+15) % 30;
    $i = (int)($c/4); $k = $c % 4;
    $l = (32+2*$e+2*$i-$h-$k) % 7;
    $m = (int)(($a+11*$h+22*$l)/451);
    $easterMonth = (int)(($h+$l-7*$m+114)/31);
    $easterDay   = (($h+$l-7*$m+114) % 31) + 1;
    $easter = mktime(0,0,0,$easterMonth,$easterDay,$year);

    $h = [];
    $h[date('Y-m-d', mktime(0,0,0,1,1,$year))]    = 'Jour de l\'An';
    $h[date('Y-m-d', $easter+86400)]               = 'Lundi de Pâques';
    $h[date('Y-m-d', mktime(0,0,0,5,1,$year))]    = 'Fête du Travail';
    $h[date('Y-m-d', mktime(0,0,0,5,8,$year))]    = 'Victoire 1945';
    $h[date('Y-m-d', $easter+39*86400)]            = 'Ascension';
    $h[date('Y-m-d', $easter+50*86400)]            = 'Lundi de Pentecôte';
    $h[date('Y-m-d', mktime(0,0,0,7,14,$year))]   = 'Fête Nationale';
    $h[date('Y-m-d', mktime(0,0,0,8,15,$year))]   = 'Assomption';
    $h[date('Y-m-d', mktime(0,0,0,11,1,$year))]   = 'Toussaint';
    $h[date('Y-m-d', mktime(0,0,0,11,11,$year))]  = 'Armistice';
    $h[date('Y-m-d', mktime(0,0,0,12,25,$year))]  = 'Noël';
    return $h;
}

/* ── Phase de la lune ───────────────────────────────────────── */
function calMoonPhase(string $date): string {
    $ts = strtotime($date);
    $knownNew = strtotime('2000-01-06'); // nouvelle lune connue
    $cycle = 29.53058867;
    $days  = ($ts - $knownNew) / 86400;
    $phase = fmod($days, $cycle);
    if ($phase < 0) $phase += $cycle;
    if ($phase < 1.85 || $phase >= 27.68)  return '🌑'; // nouvelle lune
    if ($phase < 6.38)  return '';
    if ($phase < 8.38)  return '🌓'; // premier quartier
    if ($phase < 12.92) return '';
    if ($phase < 16.61) return '🌕'; // pleine lune
    if ($phase < 21.32) return '';
    if ($phase < 23.32) return '🌗'; // dernier quartier
    return '';
}

/* ── Saints du jour (calendrier liturgique français simplifié) ─ */
function calSaint(int $month, int $day): string {
    static $saints = [
        1  => [1=>'Marie',2=>'Basile',3=>'Geneviève',4=>'Odilon',5=>'Édouard',6=>'Melchior',7=>'Raymond',8=>'Lucien',9=>'Alix',10=>'Guillaume',11=>'Paulin',12=>'Tatiana',13=>'Yvette',14=>'Nina',15=>'Rémi',16=>'Marcel',17=>'Roseline',18=>'Prisca',19=>'Marius',20=>'Sébastien',21=>'Agnès',22=>'Vincent',23=>'Barnard',24=>'François de S.',25=>'Conv. Paul',26=>'Timothée',27=>'Angèle',28=>'Thomas d\'Aquin',29=>'Gildas',30=>'Martine',31=>'Marcelle'],
        2  => [1=>'Ella',2=>'Présentation',3=>'Blaise',4=>'Véronique',5=>'Agathe',6=>'Gaston',7=>'Eugénie',8=>'Jacqueline',9=>'Apolline',10=>'Arnaud',11=>'Lourdes',12=>'Félix',13=>'Béatrice',14=>'Valentin',15=>'Claude',16=>'Julienne',17=>'Alexis',18=>'Bernadette',19=>'Gabin',20=>'Aimée',21=>'Damien',22=>'Isabelle',23=>'Lazare',24=>'Modeste',25=>'Roméo',26=>'Nestor',27=>'Honorine',28=>'Romain',29=>'Auguste'],
        3  => [1=>'Aubin',2=>'Charles le B.',3=>'Guénolé',4=>'Casimir',5=>'Olive',6=>'Colette',7=>'Félicité',8=>'Jean de D.',9=>'Françoise R.',10=>'Vivien',11=>'Rosine',12=>'Justine',13=>'Rodrigue',14=>'Mathilde',15=>'Louise',16=>'Bénédicte',17=>'Patrick',18=>'Cyrille',19=>'Joseph',20=>'Herbert',21=>'Clémence',22=>'Léa',23=>'Victorien',24=>'Cath. de S.',25=>'Annonciation',26=>'Larissa',27=>'Habib',28=>'Gontran',29=>'Gwladys',30=>'Amédée',31=>'Benjamin'],
        4  => [1=>'Hugues',2=>'Sandrine',3=>'Richard',4=>'Isidore',5=>'Irène',6=>'Marcellin',7=>'J.-Baptiste',8=>'Julie',9=>'Gautier',10=>'Fulbert',11=>'Stanislas',12=>'Jules',13=>'Ida',14=>'Maxime',15=>'Paterne',16=>'Benoît-J.',17=>'Anicet',18=>'Parfait',19=>'Emma',20=>'Odette',21=>'Anselme',22=>'Alexandre',23=>'Georges',24=>'Fidèle',25=>'Marc',26=>'Alida',27=>'Zita',28=>'Valère',29=>'Cath. de S.',30=>'Robert'],
        5  => [1=>'Fête du Trav.',2=>'Boris',3=>'Phil. & Jacq.',4=>'Sylvain',5=>'Judith',6=>'Prudence',7=>'Gisèle',8=>'Victoire',9=>'Pacôme',10=>'Solange',11=>'Estelle',12=>'Achille',13=>'Rolande',14=>'Matthias',15=>'Denise',16=>'Honoré',17=>'Pascal',18=>'Éric',19=>'Yves',20=>'Bernardin',21=>'Constantin',22=>'Émile',23=>'Didier',24=>'Donatien',25=>'Sophie',26=>'Bérenger',27=>'Augustin',28=>'Germain',29=>'Aymar',30=>'Ferdinand',31=>'Visitation'],
        6  => [1=>'Justin',2=>'Blandine',3=>'Kévin',4=>'Clotilde',5=>'Igor',6=>'Norbert',7=>'Gilbert',8=>'Médard',9=>'Diane',10=>'Landry',11=>'Barnabé',12=>'Guy',13=>'Antoine de P.',14=>'Élisée',15=>'Germaine',16=>'J.-Fr. Régis',17=>'Hervé',18=>'Léonce',19=>'Romuald',20=>'Silvère',21=>'Rodolphe',22=>'Alban',23=>'Audrey',24=>'Jean-Baptiste',25=>'Prosper',26=>'Anthelme',27=>'Fernand',28=>'Irénée',29=>'Pierre & Paul',30=>'Martial'],
        7  => [1=>'Thierry',2=>'Martinien',3=>'Thomas',4=>'Florent',5=>'Antoine',6=>'Mariette',7=>'Raoul',8=>'Thibaut',9=>'Amandine',10=>'Ulrich',11=>'Benoît',12=>'Olivier',13=>'Henri',14=>'Fête Nat.',15=>'Donald',16=>'N.-D. du Carmel',17=>'Charlotte',18=>'Frédéric',19=>'Arsène',20=>'Marina',21=>'Victor',22=>'Marie-Mad.',23=>'Brigitte',24=>'Christine',25=>'Jacques',26=>'Anne & Joachim',27=>'Nathalie',28=>'Samson',29=>'Marthe',30=>'Juliette',31=>'Ignace de L.'],
        8  => [1=>'Alphonse',2=>'Julien E.',3=>'Lydie',4=>'Jean-Marie V.',5=>'Abel',6=>'Transfiguration',7=>'Gaétan',8=>'Dominique',9=>'Amour',10=>'Laurent',11=>'Claire',12=>'Clarisse',13=>'Hippolyte',14=>'Evrard',15=>'Assomption',16=>'Armel',17=>'Hyacinthe',18=>'Hélène',19=>'Jean-Eudes',20=>'Bernard',21=>'Christophe',22=>'Fabrice',23=>'Rose de Lima',24=>'Barthélemy',25=>'Louis',26=>'Natacha',27=>'Monique',28=>'Augustin',29=>'Sabine',30=>'Fiacre',31=>'Aristide'],
        9  => [1=>'Gilles',2=>'Ingrid',3=>'Grégoire',4=>'Rosalie',5=>'Raïssa',6=>'Bertrand',7=>'Reine',8=>'Nativité',9=>'Alain',10=>'Inès',11=>'Adelphe',12=>'Apollinaire',13=>'Aimé',14=>'La Croix',15=>'Roland',16=>'Edith',17=>'Renaud',18=>'Nadège',19=>'Émilie',20=>'Davy',21=>'Matthieu',22=>'Maurice',23=>'Constance',24=>'Thècle',25=>'Hermann',26=>'Côme & Damien',27=>'Vinc. de Paul',28=>'Venceslas',29=>'Michel',30=>'Jérôme'],
        10 => [1=>'Thérèse E.',2=>'Léger',3=>'Gérard',4=>'François d\'A.',5=>'Fleur',6=>'Bruno',7=>'Serge',8=>'Pélagie',9=>'Denis',10=>'Ghislain',11=>'Firmin',12=>'Wilfrid',13=>'Géraud',14=>'Juste',15=>'Thérèse d\'A.',16=>'Edwige',17=>'Baudouin',18=>'Luc',19=>'René',20=>'Adeline',21=>'Céline',22=>'Élodie',23=>'Jean de C.',24=>'Florentin',25=>'Crépin',26=>'Dimitri',27=>'Émeline',28=>'Simon & Jude',29=>'Narcisse',30=>'Bienheureux',31=>'Quentin'],
        11 => [1=>'Toussaint',2=>'Défunts',3=>'Hubert',4=>'Charles B.',5=>'Sylvie',6=>'Bertille',7=>'Carine',8=>'Geoffrey',9=>'Théodore',10=>'Léon',11=>'Armistice',12=>'Christian',13=>'Brice',14=>'Sidoine',15=>'Albert',16=>'Marguerite',17=>'Élisabeth',18=>'Aude',19=>'Tanguy',20=>'Edmond',21=>'Prés. Marie',22=>'Cécile',23=>'Clément',24=>'Flora',25=>'Catherine',26=>'Delphine',27=>'Sévrin',28=>'Jacques',29=>'Saturnin',30=>'André'],
        12 => [1=>'Florence',2=>'Viviane',3=>'François X.',4=>'Barbara',5=>'Gérald',6=>'Nicolas',7=>'Ambroise',8=>'Immaculée',9=>'Pierre F.',10=>'Romaric',11=>'Daniel',12=>'Chantal',13=>'Lucie',14=>'Odile',15=>'Ninon',16=>'Alice',17=>'Gaël',18=>'Gatien',19=>'Urbain',20=>'Abraham',21=>'Pierre C.',22=>'Françoise-X.',23=>'Armand',24=>'Adèle',25=>'Noël',26=>'Étienne',27=>'Jean',28=>'Innocents',29=>'David',30=>'Roger',31=>'Sylvestre'],
    ];
    return $saints[$month][$day] ?? '';
}

/* ── Détection mode embed (iframe agenda) ────────────────────── */
/* Vrai si appelé avec ?embed=1 (GET) ou après un POST en mode embed (champ cal_embed) */
$embedMode  = !empty($_GET['embed']) || !empty($_POST['cal_embed']);
$_calEmbed  = $embedMode ? '?embed=1' : '';

/* ── Actions POST ────────────────────────────────────────────── */
$action = (string)($_POST['cal_action'] ?? '');
if ($action !== '' && !hash_equals($csrfToken, (string)($_POST['csrf_token'] ?? ''))) {
    setFlash('error', 'Token CSRF invalide.'); header('Location: calendrier.php' . $_calEmbed); exit;
}

if ($action === 'create_event') {
    $title   = mb_substr(trim($_POST['title'] ?? ''), 0, 200);
    $desc    = mb_substr(trim($_POST['description'] ?? ''), 0, 2000);
    $loc     = mb_substr(trim($_POST['location'] ?? ''), 0, 300);
    $visio   = mb_substr(trim($_POST['visio_url'] ?? ''), 0, 500);
    $startAt = trim($_POST['start_at'] ?? '');
    $endAt   = trim($_POST['end_at'] ?? '');
    $allDay  = isset($_POST['all_day']) ? 1 : 0;
    $color   = preg_match('/^#[0-9a-f]{6}$/i', $_POST['color'] ?? '') ? $_POST['color'] : '#38bdf8';
    if ($title === '' || $startAt === '' || $endAt === '') {
        setFlash('error', 'Titre et dates sont obligatoires.');
        header('Location: calendrier.php' . $_calEmbed); exit;
    }
    $id = fmGenId();
    $db->prepare('INSERT INTO calendar_events (id,creator_id,title,description,location,visio_url,start_at,end_at,all_day,color) VALUES (?,?,?,?,?,?,?,?,?,?)')
       ->execute([$id, $meId, $title, $desc, $loc, $visio, $startAt, $endAt, $allDay, $color]);
    // Invités
    $invited = $_POST['invite_ids'] ?? [];
    foreach ((array)$invited as $uid) {
        $uid = trim($uid);
        if ($uid === '' || $uid === $meId) continue;
        $db->prepare('INSERT OR IGNORE INTO calendar_invites (event_id,user_id,status) VALUES (?,?,?)')
           ->execute([$id, $uid, 'pending']);
        notifCreate($db, $uid, 'calendar_invite', $meUsername . ' vous invite à un événement', $title, 'calendrier.php');
    }
    setFlash('success', 'Événement créé.');
    header('Location: calendrier.php' . $_calEmbed); exit;
}

if ($action === 'delete_event') {
    $eid = trim($_POST['event_id'] ?? '');
    if ($eid !== '') {
        $db->prepare('DELETE FROM calendar_events WHERE id=? AND creator_id=?')->execute([$eid, $meId]);
        $db->prepare('DELETE FROM calendar_invites WHERE event_id=?')->execute([$eid]);
    }
    setFlash('success', 'Événement supprimé.');
    header('Location: calendrier.php' . $_calEmbed); exit;
}

if ($action === 'respond_invite') {
    $eid    = trim($_POST['event_id'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['accepted','declined']) ? $_POST['status'] : 'accepted';
    if ($eid !== '') {
        $db->prepare('UPDATE calendar_invites SET status=? WHERE event_id=? AND user_id=?')
           ->execute([$status, $eid, $meId]);
    }
    header('Location: calendrier.php' . $_calEmbed); exit;
}

/* ── Charger les événements ─────────────────────────────────── */
$evStmt = $db->prepare(
    'SELECT e.* FROM calendar_events e
     WHERE e.creator_id=?
     UNION
     SELECT e.* FROM calendar_events e
     JOIN calendar_invites i ON i.event_id=e.id
     WHERE i.user_id=? AND i.status != \'declined\'
     ORDER BY start_at ASC'
);
$evStmt->execute([$meId, $meId]);
$allEvents = $evStmt->fetchAll(PDO::FETCH_ASSOC);

/* ── Invitations en attente ─────────────────────────────────── */
$pendingInvites = [];
$piStmt = $db->prepare(
    'SELECT e.*, i.status FROM calendar_events e
     JOIN calendar_invites i ON i.event_id=e.id
     WHERE i.user_id=? AND i.status=\'pending\''
);
$piStmt->execute([$meId]);
$pendingInvites = $piStmt->fetchAll(PDO::FETCH_ASSOC);

$year  = (int)date('Y');
$holidays = calFrHolidays($year);
// Also next year for cross-year events
$holidays += calFrHolidays($year + 1);

$recipients = [];
foreach ($users as $u) {
    if ($u['status'] === 'active' && $u['id'] !== $meId && $u['id'] !== '__admin__') {
        $recipients[] = ['id' => $u['id'], 'username' => $u['username']];
    }
}
usort($recipients, fn($a,$b) => strcmp($a['username'], $b['username']));
?>
<!DOCTYPE html>
<html lang="fr"<?php if ($embedMode): ?> class="embed-mode"<?php endif; ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agenda – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<link rel="stylesheet" href="assets/css/tv.css?v=9">
<link rel="stylesheet" href="assets/css/calendrier.css?v=2">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
<!-- styles déplacés dans #spa-page pour la navigation SPA -->
</head>
<body<?php if ($embedMode): ?> class="embed-mode"<?php endif; ?>>
<div class="background-layer" aria-hidden="true"></div>
<?php if (!$embedMode): require __DIR__ . '/includes/nav.php'; endif; ?>
<?php if (!$embedMode): require __DIR__ . '/includes/chat-sidebar.php'; endif; ?>

<div id="spa-page">
<main class="page is-dashboard">
<section class="hero is-centered-v">
<div class="hero-content is-dashboard">
<div class="cal-wrap">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status"><?php echo escape($flash['message'] ?? ''); ?></div>
<?php endif; ?>

<!-- Invitations en attente -->
<?php if (!empty($pendingInvites)): ?>
<div class="cal-invites">
    <?php foreach ($pendingInvites as $pi): ?>
    <div class="cal-invite-banner">
        <div>
            <div class="cal-invite-title">📅 <?php echo escape($pi['title']); ?></div>
            <div class="cal-invite-meta"><?php echo escape(date('d/m/Y H:i', strtotime($pi['start_at']))); ?></div>
        </div>
        <div class="cal-invite-btns">
            <form method="post" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <?php if ($embedMode): ?><input type="hidden" name="cal_embed" value="1"><?php endif; ?>
                <input type="hidden" name="cal_action" value="respond_invite">
                <input type="hidden" name="event_id" value="<?php echo escapeAttribute($pi['id']); ?>">
                <input type="hidden" name="status" value="accepted">
                <button type="submit" class="cal-invite-accept">✓ Accepter</button>
            </form>
            <form method="post" style="display:inline">
                <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <?php if ($embedMode): ?><input type="hidden" name="cal_embed" value="1"><?php endif; ?>
                <input type="hidden" name="cal_action" value="respond_invite">
                <input type="hidden" name="event_id" value="<?php echo escapeAttribute($pi['id']); ?>">
                <input type="hidden" name="status" value="declined">
                <button type="submit" class="cal-invite-decline">✕ Décliner</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Barre d'outils -->
<div class="cal-toolbar">
    <button class="cal-nav-btn" id="cal-prev" aria-label="Mois précédent">&#8249;</button>
    <button class="cal-nav-btn" id="cal-next" aria-label="Mois suivant">&#8250;</button>
    <button class="cal-today-btn" id="cal-today">Aujourd'hui</button>

    <div class="cal-toolbar-title" id="cal-title"></div>

    <div class="cal-view-btns">
        <button class="cal-view-btn is-active" data-view="month">Mois</button>
        <button class="cal-view-btn" data-view="week">Semaine</button>
        <button class="cal-view-btn" data-view="day">Jour</button>
    </div>
    <button class="cal-new-btn" id="cal-new-btn" type="button">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Nouvel événement
    </button>
</div>

<!-- Vue Mois -->
<div class="cal-month is-active" id="cal-month-view">
    <div class="cal-day-headers" id="cal-day-headers"></div>
    <div class="cal-grid" id="cal-grid"></div>
</div>

<!-- Vue Semaine -->
<div class="cal-week" id="cal-week-view">
    <div class="cal-week-grid" id="cal-week-grid"></div>
</div>

<!-- Vue Jour -->
<div class="cal-day-view" id="cal-day-view">
    <div class="cal-day-grid" id="cal-day-grid"></div>
</div>

</div>
</div><!-- /hero-content -->
</section><!-- /hero -->
</main>

<!-- ── Modal Création / Édition ──────────────────────────────── -->
<div class="cal-modal-backdrop" id="cal-modal-backdrop" hidden>
    <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="cal-modal-ttl">
        <div class="cal-modal-title">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            <span id="cal-modal-ttl">Nouvel événement</span>
        </div>
        <form method="post" action="calendrier.php" id="cal-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                <?php if ($embedMode): ?><input type="hidden" name="cal_embed" value="1"><?php endif; ?>
            <input type="hidden" name="cal_action" value="create_event">
            <input type="hidden" name="event_id" id="cal-edit-id" value="">

            <div class="cal-field">
                <label for="cal-title-input">Titre <abbr title="obligatoire">*</abbr></label>
                <input type="text" id="cal-title-input" name="title" required maxlength="200" placeholder="Titre de l'événement">
            </div>
            <div class="cal-row-2">
                <div class="cal-field">
                    <label for="cal-start">Début <abbr title="obligatoire">*</abbr></label>
                    <input type="datetime-local" id="cal-start" name="start_at" required>
                </div>
                <div class="cal-field">
                    <label for="cal-end">Fin <abbr title="obligatoire">*</abbr></label>
                    <input type="datetime-local" id="cal-end" name="end_at" required>
                </div>
            </div>
            <div class="cal-field" style="flex-direction:row;align-items:center;gap:.5rem">
                <input type="checkbox" id="cal-allday" name="all_day" value="1" style="width:auto">
                <label for="cal-allday" style="color:var(--text);font-size:.85rem;cursor:pointer">Toute la journée</label>
            </div>
            <div class="cal-field">
                <label for="cal-desc">Description</label>
                <textarea id="cal-desc" name="description" maxlength="2000" placeholder="Détails de l'événement…"></textarea>
            </div>
            <div class="cal-field">
                <label for="cal-loc">Lieu</label>
                <input type="text" id="cal-loc" name="location" maxlength="300" placeholder="Salle, adresse…">
            </div>
            <div class="cal-field">
                <label for="cal-visio">Lien visio</label>
                <input type="url" id="cal-visio" name="visio_url" maxlength="500" placeholder="https://…">
            </div>
            <div class="cal-field">
                <label>Couleur</label>
                <div class="cal-color-row" id="cal-color-row">
                    <?php foreach (['#38bdf8'=>'Bleu','#22c55e'=>'Vert','#f59e0b'=>'Jaune','#ef4444'=>'Rouge','#8b5cf6'=>'Violet','#f97316'=>'Orange'] as $c => $cl): ?>
                    <span class="cal-color-swatch<?php echo $c==='#38bdf8' ? ' is-selected' : ''; ?>"
                          style="background:<?php echo $c; ?>"
                          data-color="<?php echo $c; ?>"
                          title="<?php echo $cl; ?>"
                          tabindex="0" role="radio"
                          aria-label="<?php echo $cl; ?>"
                          aria-checked="<?php echo $c==='#38bdf8' ? 'true' : 'false'; ?>"></span>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="color" id="cal-color-input" value="#38bdf8">
            </div>
            <?php if (!empty($recipients)): ?>
            <div class="cal-field">
                <label for="cal-invite">Inviter des membres</label>
                <select id="cal-invite" name="invite_ids[]" multiple size="4" style="height:auto">
                    <?php foreach ($recipients as $r): ?>
                    <option value="<?php echo escapeAttribute($r['id']); ?>"><?php echo escape($r['username']); ?></option>
                    <?php endforeach; ?>
                </select>
                <small style="color:var(--muted);font-size:.73rem">Ctrl+clic pour sélection multiple</small>
            </div>
            <?php endif; ?>
            <div class="cal-form-actions">
                <button type="submit" class="cal-submit-btn">Enregistrer</button>
                <button type="button" class="cal-cancel-btn" id="cal-modal-cancel">Annuler</button>
            </div>
        </form>
    </div>
</div>

<!-- ── Modal Détail ──────────────────────────────────────────── -->
<div class="cal-modal-backdrop" id="cal-detail-backdrop" hidden>
    <div class="cal-modal" role="dialog" aria-modal="true" aria-labelledby="cal-detail-ttl">
        <div class="cal-modal-title" id="cal-detail-color-dot" style="gap:.6rem">
            <span id="cal-detail-dot" style="width:12px;height:12px;border-radius:50%;display:inline-block;flex-shrink:0"></span>
            <span id="cal-detail-ttl"></span>
        </div>
        <div id="cal-detail-dates" style="font-size:.82rem;color:var(--muted);"></div>
        <div id="cal-detail-desc" style="margin-top:.6rem;font-size:.88rem;color:var(--text);white-space:pre-wrap;"></div>
        <div class="cal-detail-loc" id="cal-detail-loc" style="display:none">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
            <span id="cal-detail-loc-text"></span>
        </div>
        <a id="cal-detail-visio" class="cal-detail-visio" href="#" target="_blank" rel="noopener" style="display:none">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
            Rejoindre la réunion
        </a>
        <div class="cal-detail-actions" id="cal-detail-actions"></div>
        <button type="button" class="cal-cancel-btn" id="cal-detail-close" style="margin-top:.75rem;width:100%">Fermer</button>
    </div>
</div>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
(function() {
var CAL_EVENTS   = <?php echo json_encode(array_values($allEvents), JSON_UNESCAPED_UNICODE); ?>;
var CAL_HOLIDAYS = <?php echo json_encode($holidays, JSON_UNESCAPED_UNICODE); ?>;
var ME_ID        = '<?php echo addslashes($meId); ?>';
var CSRF         = '<?php echo addslashes($csrfToken); ?>';
var EMBED_MODE   = <?php echo $embedMode ? 'true' : 'false'; ?>;

var now    = new Date();
var curY   = now.getFullYear();
var curM   = now.getMonth(); // 0-indexed
var curView = 'month';
var curDay  = now.getDate();

var DAYS_FR   = ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'];
var MONTHS_FR = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Août','Septembre','Octobre','Novembre','Décembre'];

/* ── DOM refs ─────────────────────────── */
var titleEl     = document.getElementById('cal-title');
var grid        = document.getElementById('cal-grid');
var dayHeaders  = document.getElementById('cal-day-headers');
var weekGrid    = document.getElementById('cal-week-grid');
var dayGrid     = document.getElementById('cal-day-grid');
var monthView   = document.getElementById('cal-month-view');
var weekView    = document.getElementById('cal-week-view');
var dayView     = document.getElementById('cal-day-view');
var modalBg     = document.getElementById('cal-modal-backdrop');
var detailBg    = document.getElementById('cal-detail-backdrop');
var form        = document.getElementById('cal-form');

/* ── Helpers ──────────────────────────── */
function pad(n) { return n < 10 ? '0' + n : '' + n; }
function dateStr(y, m, d) { return y + '-' + pad(m+1) + '-' + pad(d); }
function fmt(dt) {
    var d = new Date(dt);
    if (isNaN(d)) return dt;
    return d.toLocaleDateString('fr-FR', { weekday:'short', day:'numeric', month:'long', year:'numeric', hour:'2-digit', minute:'2-digit' });
}
function eventsOnDay(dateS) {
    return CAL_EVENTS.filter(function(e) {
        var s = e.start_at ? e.start_at.slice(0,10) : '';
        var en = e.end_at   ? e.end_at.slice(0,10)   : s;
        return s <= dateS && en >= dateS;
    });
}

/* ── Rendu Mois ───────────────────────── */
function renderMonth() {
    titleEl.textContent = MONTHS_FR[curM] + ' ' + curY;
    // En-têtes Lun … Dim (semaine FR commence Lun)
    dayHeaders.innerHTML = '';
    var days = ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];
    days.forEach(function(d) {
        var h = document.createElement('div');
        h.className = 'cal-day-header';
        h.textContent = d;
        dayHeaders.appendChild(h);
    });
    grid.innerHTML = '';
    var first = new Date(curY, curM, 1);
    // Offset : lundi=0, dimanche=6
    var startOffset = (first.getDay() + 6) % 7;
    var daysInMonth = new Date(curY, curM + 1, 0).getDate();
    var totalCells  = Math.ceil((startOffset + daysInMonth) / 7) * 7;

    for (var i = 0; i < totalCells; i++) {
        var dayOffset = i - startOffset;
        var cellDate  = new Date(curY, curM, 1 + dayOffset);
        var cellY = cellDate.getFullYear();
        var cellM = cellDate.getMonth();
        var cellD = cellDate.getDate();
        var ds = dateStr(cellY, cellM, cellD);

        var cell = document.createElement('div');
        cell.className = 'cal-cell';
        if (cellM !== curM) cell.classList.add('is-other-month');
        var dow = cellDate.getDay(); // 0=Sun
        if (dow === 0 || dow === 6) cell.classList.add('is-weekend');
        var todayStr = dateStr(now.getFullYear(), now.getMonth(), now.getDate());
        if (ds === todayStr) cell.classList.add('is-today');

        // Numéro du jour
        var numEl = document.createElement('div');
        numEl.className = 'cal-cell-num' + (ds === todayStr ? ' is-today-num' : '');
        numEl.textContent = cellD;
        cell.appendChild(numEl);

        // Lune
        var moonEmoji = calMoonPhase(ds);
        if (moonEmoji) {
            var moonEl = document.createElement('div');
            moonEl.className = 'cal-cell-moon';
            moonEl.textContent = moonEmoji;
            cell.appendChild(moonEl);
        }

        // Jour férié
        if (CAL_HOLIDAYS[ds]) {
            var hEl = document.createElement('div');
            hEl.className = 'cal-cell-holiday';
            hEl.textContent = CAL_HOLIDAYS[ds];
            cell.appendChild(hEl);
        }

        // Saint
        var saint = SAINTS[cellM+1] && SAINTS[cellM+1][cellD] ? SAINTS[cellM+1][cellD] : '';
        if (saint) {
            var sEl = document.createElement('div');
            sEl.className = 'cal-cell-saint';
            sEl.textContent = saint;
            cell.appendChild(sEl);
        }

        // Événements
        var dayEvs = eventsOnDay(ds);
        var maxShow = 2;
        dayEvs.slice(0, maxShow).forEach(function(ev) {
            var pill = document.createElement('div');
            pill.className = 'cal-pill';
            pill.style.background = ev.color || '#38bdf8';
            pill.textContent = (ev.all_day ? '' : (ev.start_at ? ev.start_at.slice(11,16) + ' ' : '')) + ev.title;
            pill.title = ev.title;
            pill.addEventListener('click', function(e) { e.stopPropagation(); showDetail(ev); });
            cell.appendChild(pill);
        });
        if (dayEvs.length > maxShow) {
            var more = document.createElement('div');
            more.className = 'cal-more';
            more.textContent = '+' + (dayEvs.length - maxShow) + ' autre' + (dayEvs.length - maxShow > 1 ? 's' : '');
            cell.appendChild(more);
        }

        cell.addEventListener('click', function(ds) {
            return function() { openModal(ds); };
        }(ds));

        grid.appendChild(cell);
    }
}

/* ── Phase de lune (JS) ───────────────── */
var knownNew = new Date('2000-01-06').getTime();
var cycle    = 29.53058867 * 86400000;
function calMoonPhase(ds) {
    var ts    = new Date(ds).getTime();
    var days  = (ts - knownNew) / 86400000;
    var phase = ((days % cycle/86400000) + cycle/86400000) % (cycle/86400000);
    if (phase < 1.85 || phase >= 27.68) return '🌑';
    if (phase >= 6.38 && phase < 8.38)  return '🌓';
    if (phase >= 12.92 && phase < 16.61) return '🌕';
    if (phase >= 21.32 && phase < 23.32) return '🌗';
    return '';
}

/* ── Saints (subset, injecté depuis PHP) ─ */
var SAINTS = <?php
$s = [];
for ($m=1;$m<=12;$m++) {
    $s[$m] = [];
    for ($d=1;$d<=31;$d++) {
        $v = calSaint($m,$d);
        if ($v !== '') $s[$m][$d] = $v;
    }
}
echo json_encode($s, JSON_UNESCAPED_UNICODE);
?>;

/* ── Vue Semaine ──────────────────────── */
function renderWeek() {
    // Trouver le lundi de la semaine courante
    var d = new Date(curY, curM, curDay);
    var dow = (d.getDay() + 6) % 7; // lundi=0
    var monday = new Date(d.getFullYear(), d.getMonth(), d.getDate() - dow);
    titleEl.textContent = 'Semaine du ' + monday.getDate() + ' ' + MONTHS_FR[monday.getMonth()].slice(0,3) + ' ' + monday.getFullYear();
    weekGrid.innerHTML = '';
    // Headers
    var timeHead = document.createElement('div');
    timeHead.className = 'cal-week-header';
    weekGrid.appendChild(timeHead);
    var weekDays = [];
    for (var i = 0; i < 7; i++) {
        var wd = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + i);
        weekDays.push(wd);
        var h = document.createElement('div');
        h.className = 'cal-week-header';
        var todayS = dateStr(now.getFullYear(), now.getMonth(), now.getDate());
        var wdS    = dateStr(wd.getFullYear(), wd.getMonth(), wd.getDate());
        h.textContent = DAYS_FR[(wd.getDay())] + ' ' + wd.getDate();
        if (wdS === todayS) h.style.color = 'var(--primary)';
        weekGrid.appendChild(h);
    }
    // Time slots
    for (var hour = 0; hour < 24; hour++) {
        var tEl = document.createElement('div');
        tEl.className = 'cal-week-time';
        tEl.textContent = pad(hour) + ':00';
        weekGrid.appendChild(tEl);
        weekDays.forEach(function(wd) {
            var slot = document.createElement('div');
            slot.className = 'cal-week-slot';
            var wdow = wd.getDay();
            if (wdow === 0 || wdow === 6) slot.classList.add('is-weekend');
            var wdS = dateStr(wd.getFullYear(), wd.getMonth(), wd.getDate());
            var slotEvs = CAL_EVENTS.filter(function(e) {
                if (!e.start_at) return false;
                var s = e.start_at.slice(0,10);
                var h2 = parseInt(e.start_at.slice(11,13) || '0');
                return s === wdS && h2 === hour;
            });
            slotEvs.forEach(function(ev) {
                var pill = document.createElement('div');
                pill.className = 'cal-pill';
                pill.style.background = ev.color || '#38bdf8';
                pill.style.fontSize = '.6rem';
                pill.style.position = 'absolute';
                pill.style.left = '2px'; pill.style.right = '2px'; pill.style.top = '2px';
                pill.textContent = ev.title;
                pill.addEventListener('click', function() { showDetail(ev); });
                slot.style.position = 'relative';
                slot.appendChild(pill);
            });
            weekGrid.appendChild(slot);
        });
    }
}

/* ── Vue Jour ─────────────────────────── */
function renderDay() {
    var d = new Date(curY, curM, curDay);
    var ds = dateStr(curY, curM, curDay);
    titleEl.textContent = DAYS_FR[d.getDay()] + ' ' + curDay + ' ' + MONTHS_FR[curM] + ' ' + curY;
    if (CAL_HOLIDAYS[ds]) titleEl.textContent += ' – ' + CAL_HOLIDAYS[ds];
    dayGrid.innerHTML = '';
    for (var hour = 0; hour < 24; hour++) {
        var tEl = document.createElement('div');
        tEl.className = 'cal-week-time';
        tEl.textContent = pad(hour) + ':00';
        dayGrid.appendChild(tEl);
        var slot = document.createElement('div');
        slot.className = 'cal-week-slot';
        var slotEvs = CAL_EVENTS.filter(function(e) {
            if (!e.start_at) return false;
            var s  = e.start_at.slice(0,10);
            var h2 = parseInt(e.start_at.slice(11,13) || '0');
            return s === ds && h2 === hour;
        });
        slotEvs.forEach(function(ev) {
            var pill = document.createElement('div');
            pill.className = 'cal-pill';
            pill.style.background = ev.color || '#38bdf8';
            pill.style.marginBottom = '2px';
            pill.textContent = (ev.start_at ? ev.start_at.slice(11,16) + ' ' : '') + ev.title;
            pill.addEventListener('click', function() { showDetail(ev); });
            slot.appendChild(pill);
        });
        dayGrid.appendChild(slot);
    }
}

/* ── Render dispatcher ────────────────── */
function render() {
    if (curView === 'month')  { monthView.classList.add('is-active'); weekView.classList.remove('is-active'); dayView.classList.remove('is-active'); renderMonth(); }
    if (curView === 'week')   { weekView.classList.add('is-active');  monthView.classList.remove('is-active'); dayView.classList.remove('is-active'); renderWeek(); }
    if (curView === 'day')    { dayView.classList.add('is-active');   monthView.classList.remove('is-active'); weekView.classList.remove('is-active'); renderDay(); }
    
    if (EMBED_MODE && window.parent && window.parent !== window) {
        var sendH = function() {
            var el = document.querySelector('.page') || document.querySelector('.cal-wrap');
            var h = el ? (el.getBoundingClientRect().height + 40) : document.body.offsetHeight;
            window.parent.postMessage({ type: 'resize_iframe', id: 'agenda-overlay-fr', height: h }, '*');
        };
        if (window.ResizeObserver && !window._calResizeInit) {
            window._calResizeInit = true;
            new ResizeObserver(sendH).observe(document.body);
        }
        window.addEventListener('load', sendH);
        setInterval(sendH, 100);
    }
}

/* ── Navigation ───────────────────────── */
document.getElementById('cal-prev').addEventListener('click', function() {
    if (curView === 'month') { curM--; if (curM < 0) { curM = 11; curY--; } }
    else if (curView === 'week') { curDay -= 7; var d = new Date(curY, curM, curDay); curY=d.getFullYear(); curM=d.getMonth(); curDay=d.getDate(); }
    else { curDay--; var d2 = new Date(curY, curM, curDay); curY=d2.getFullYear(); curM=d2.getMonth(); curDay=d2.getDate(); }
    render();
});
document.getElementById('cal-next').addEventListener('click', function() {
    if (curView === 'month') { curM++; if (curM > 11) { curM = 0; curY++; } }
    else if (curView === 'week') { curDay += 7; var d = new Date(curY, curM, curDay); curY=d.getFullYear(); curM=d.getMonth(); curDay=d.getDate(); }
    else { curDay++; var d2 = new Date(curY, curM, curDay); curY=d2.getFullYear(); curM=d2.getMonth(); curDay=d2.getDate(); }
    render();
});
document.getElementById('cal-today').addEventListener('click', function() {
    curY = now.getFullYear(); curM = now.getMonth(); curDay = now.getDate(); render();
});

/* ── Switcher de vue ──────────────────── */
document.querySelectorAll('.cal-view-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        curView = btn.getAttribute('data-view');
        document.querySelectorAll('.cal-view-btn').forEach(function(b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        render();
    });
});

/* ── Modal Création ───────────────────── */
function showModalWithAnim(bg) {
    bg.classList.remove('is-closing');
    bg.removeAttribute('hidden');
    void bg.offsetWidth;
    bg.classList.add('is-open');
}
function closeModalWithAnim(bg) {
    bg.classList.add('is-closing');
    bg.classList.remove('is-open');
    setTimeout(function() {
        bg.setAttribute('hidden', '');
        bg.classList.remove('is-closing');
    }, 220);
}
function openModal(defaultDate) {
    document.getElementById('cal-modal-ttl').textContent = 'Nouvel événement';
    document.getElementById('cal-edit-id').value = '';
    form.reset();
    if (defaultDate) {
        document.getElementById('cal-start').value = defaultDate + 'T09:00';
        document.getElementById('cal-end').value   = defaultDate + 'T10:00';
    }
    // Reset color
    document.querySelectorAll('.cal-color-swatch').forEach(function(s) { s.classList.remove('is-selected'); s.setAttribute('aria-checked','false'); });
    document.querySelector('.cal-color-swatch[data-color="#38bdf8"]').classList.add('is-selected');
    document.querySelector('.cal-color-swatch[data-color="#38bdf8"]').setAttribute('aria-checked','true');
    document.getElementById('cal-color-input').value = '#38bdf8';
    showModalWithAnim(modalBg);
}
document.getElementById('cal-new-btn').addEventListener('click', function() {
    var ds = dateStr(now.getFullYear(), now.getMonth(), now.getDate());
    openModal(ds);
});
document.getElementById('cal-modal-cancel').addEventListener('click', function() { closeModalWithAnim(modalBg); });
modalBg.addEventListener('click', function(e) { if (e.target === modalBg) closeModalWithAnim(modalBg); });

// Couleurs
document.querySelectorAll('.cal-color-swatch').forEach(function(sw) {
    sw.addEventListener('click', function() {
        document.querySelectorAll('.cal-color-swatch').forEach(function(s) { s.classList.remove('is-selected'); s.setAttribute('aria-checked','false'); });
        sw.classList.add('is-selected');
        sw.setAttribute('aria-checked','true');
        document.getElementById('cal-color-input').value = sw.getAttribute('data-color');
    });
    sw.addEventListener('keydown', function(e) { if (e.key==='Enter'||e.key===' ') sw.click(); });
});

/* ── Detail Modal ─────────────────────── */
function showDetail(ev) {
    document.getElementById('cal-detail-ttl').textContent = ev.title;
    document.getElementById('cal-detail-dot').style.background = ev.color || '#38bdf8';
    var sd = ev.all_day ? ev.start_at.slice(0,10) : fmt(ev.start_at);
    var ed = ev.all_day ? ev.end_at.slice(0,10)   : fmt(ev.end_at);
    document.getElementById('cal-detail-dates').textContent = sd === ed ? sd : sd + ' → ' + ed;
    var descEl = document.getElementById('cal-detail-desc');
    descEl.textContent = ev.description || '';
    descEl.style.display = ev.description ? '' : 'none';
    var locEl = document.getElementById('cal-detail-loc');
    var locTxt = document.getElementById('cal-detail-loc-text');
    if (ev.location) { locEl.style.display = ''; locTxt.textContent = ev.location; } else { locEl.style.display = 'none'; }
    var visioEl = document.getElementById('cal-detail-visio');
    if (ev.visio_url) { visioEl.style.display = ''; visioEl.href = ev.visio_url; } else { visioEl.style.display = 'none'; }
    // Actions (supprimer si créateur)
    var actEl = document.getElementById('cal-detail-actions');
    actEl.innerHTML = '';
    if (ev.creator_id === ME_ID) {
        var delForm = document.createElement('form');
        delForm.method = 'post';
        delForm.action = 'calendrier.php';
        delForm.innerHTML = '<input type="hidden" name="csrf_token" value="' + CSRF + '">' +
            (EMBED_MODE ? '<input type="hidden" name="cal_embed" value="1">' : '') +
            '<input type="hidden" name="cal_action" value="delete_event">' +
            '<input type="hidden" name="event_id" value="' + ev.id + '">' +
            '<button type="submit" class="cal-detail-delete" onclick="return confirm(\'Supprimer cet événement ?\')">🗑 Supprimer</button>';
        actEl.appendChild(delForm);
    }
    showModalWithAnim(detailBg);
}
document.getElementById('cal-detail-close').addEventListener('click', function() { closeModalWithAnim(detailBg); });
detailBg.addEventListener('click', function(e) { if (e.target === detailBg) closeModalWithAnim(detailBg); });

/* ── Keyboard ─────────────────────────── */
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (!modalBg.hasAttribute('hidden'))  { closeModalWithAnim(modalBg); return; }
        if (!detailBg.hasAttribute('hidden')) { closeModalWithAnim(detailBg); return; }
    }
});

/* ── Init ─────────────────────────────── */
render();
}());
</script>
</div><!-- /#spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
</body>
</html>
