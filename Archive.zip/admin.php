<?php
/**
 * NéoPcPro – Pilotage du site (page autonome)
 */
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

if (!$isAdminAuthenticated) {
    header('Location: index.php');
    exit;
}

$flash = getFlash();

$ogTitle = 'Pilotage du site – NéoPcPro';
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Pilotage du site – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<main class="page is-dashboard"
      data-admin-authenticated="1"
      data-admin-auto-open="0">

<section class="hero is-centered-v" aria-labelledby="admin-page-section">
<div class="hero-content is-dashboard">
<?php require __DIR__ . '/includes/admin-panel.php'; ?>
</div>
</section>

</main>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">


(function(){
var modal=document.querySelector('[data-admin-modal]'),opens=document.querySelectorAll('[data-admin-open]'),closes=document.querySelectorAll('[data-admin-close]'),page=document.querySelector('.page'),pwd=document.getElementById('admin-password');
if(!modal||!page||!opens.length)return;
function open(){modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('has-admin-modal-open'); document.documentElement.classList.add('has-admin-modal-open');if(pwd)setTimeout(function(){pwd.focus();},40);}
function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('has-admin-modal-open'); document.documentElement.classList.remove('has-admin-modal-open');}
opens.forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();open();});});
closes.forEach(function(b){b.addEventListener('click',close);});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))close();});
})();
</script>

</body>
</html>
