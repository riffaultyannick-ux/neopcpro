<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Rediriger si non connecté
if (!$isUserAuthenticated) {
    header('Location: /index.php?show_login=1');
    exit;
}

// Maintenance : bloquer les membres non-admin déjà connectés
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php');
    exit;
}

$flash = getFlash();

$ogTitle = 'Mon Profil – NéoPcPro';
$ogDesc  = 'Gérez votre profil utilisateur sur NéoPcPro.';
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/profil.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $ogDesc; ?>">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="<?php echo escape($ogTitle); ?>">
<meta property="og:description" content="<?php echo $ogDesc; ?>">
<meta property="og:site_name"   content="NéoPcPro">
<title>Mon Profil – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/partages.css?v=1">
<link rel="stylesheet" href="assets/css/securite.css?v=1">
<link rel="stylesheet" href="assets/css/weather.css?v=1">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<div id="spa-page">
<main class="page is-dashboard">
<section class="hero is-centered-v">
<div class="hero-content is-dashboard">
<?php require __DIR__ . '/includes/profil-panel.php'; ?>
</div>
</section>
</main>

</div><!-- #spa-page -->
</body>
</html>
