<?php
/**
 * NéoPcPro – API Chat instantané
 * Supporte : salons publics (rooms) + messages directs (DM).
 */
define('NEOPCPRO_LOADED', 1);
require __DIR__ . '/includes/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

/* ── Config ───────────────────────────────────────────────────── */
$chatCfg     = $siteSettings['chat'] ?? [];
$chatEnabled = (int)($chatCfg['enabled'] ?? 1) === 1;

if (!$chatEnabled) {
    http_response_code(503);
    echo json_encode(['error' => 'Chat désactivé.']);
    exit;
}

// Maintenance : seuls les admins peuvent continuer
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    http_response_code(503);
    echo json_encode(['error' => 'maintenance']);
    exit;
}

$action    = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');
$hardLimit = 500;

/* ── Helpers ──────────────────────────────────────────────────── */

/** Génère une clé unique et stable pour une paire DM. */
function chatDmKey(string $uid1, string $uid2): string
{
    $ids = [$uid1, $uid2];
    sort($ids);
    return substr(md5(implode(':', $ids)), 0, 12);
}

/** Identifiant courant : userId si disponible (role-admin), sinon '__admin__' (admin mot-de-passe). */
function chatMeId(bool $isAdmin, ?string $userId): string
{
    if ($userId !== null && $userId !== '') return $userId;
    return $isAdmin ? '__admin__' : '';
}

/** Nom affiché pour l'expéditeur courant.
 * Les role-admins (username non vide) conservent leur vrai pseudonyme.
 * L'admin mot-de-passe (sans username) utilise admin_display_name. */
function chatMeName(bool $isAdmin, ?string $username, array $cfg): string
{
    if (!empty($username)) return $username;
    if ($isAdmin) return normalizeText($cfg['admin_display_name'] ?? '') ?: 'Admin';
    return 'Inconnu';
}

/* ══ ROOMS ═════════════════════════════════════════════════════ */
if ($action === 'rooms') {
    if (!$isUserAuthenticated && !$isAdminAuthenticated) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentification requise.']);
        exit;
    }
    /* ── Salons publics ── */
    $rooms = $chatRooms;
    if (empty($rooms)) {
        $rooms = [['id' => 'general', 'name' => 'Général', 'emoji' => '💬', 'visible' => 1, 'order' => 1]];
    }
    $rooms = array_values(array_filter($rooms, fn($r) => (int)($r['visible'] ?? 1) === 1));
    usort($rooms, fn($a, $b) => (int)($a['order'] ?? 0) - (int)($b['order'] ?? 0));

    foreach ($rooms as &$room) {
        $last = dbGetChatLastMessage($db, 'room', $room['id']);
        $room['last_ts']     = $last ? (int)($last['ts'] ?? 0) : 0;
        $room['last_author'] = $last ? ($last['author'] ?? '') : '';
        $room['last_text']   = $last ? mb_substr($last['text'] ?? '', 0, 45) : '';
    }
    unset($room);

    /* ── Salons privés ── */
    $allPrivate   = $privateRooms;
    $unlockedIds  = $_SESSION['chat_unlocked_private_rooms'] ?? [];
    $privateRooms = array_values(array_filter($allPrivate, fn($r) => (int)($r['visible'] ?? 0) === 1));
    usort($privateRooms, fn($a, $b) => (int)($a['order'] ?? 0) - (int)($b['order'] ?? 0));

    foreach ($privateRooms as &$pr) {
        $unlocked = in_array($pr['id'], $unlockedIds, true);
        $pr['unlocked'] = $unlocked;
        if ($unlocked) {
            $last = dbGetChatLastMessage($db, 'room', $pr['id']);
            $pr['last_ts']     = $last ? (int)($last['ts'] ?? 0) : 0;
            $pr['last_author'] = $last ? ($last['author'] ?? '') : '';
            $pr['last_text']   = $last ? mb_substr($last['text'] ?? '', 0, 45) : '';
        } else {
            $pr['last_ts'] = 0; $pr['last_author'] = ''; $pr['last_text'] = '';
        }
        unset($pr['password_hash']); // ne jamais exposer le hash
    }
    unset($pr);

    echo json_encode(['rooms' => $rooms, 'private_rooms' => $privateRooms]);
    exit;
}

/* ══ JOIN PRIVATE ROOM ══════════════════════════════════════════ */
if ($action === 'join_private_room') {
    if ($requestMethod !== 'POST') {
        http_response_code(405); echo json_encode(['ok' => false, 'error' => 'POST requis.']); exit;
    }
    $token = (string)($_POST['csrf_token'] ?? '');
    if (!verifyCsrfToken($token)) {
        http_response_code(403); echo json_encode(['ok' => false, 'error' => 'Token CSRF invalide.']); exit;
    }

    $roomId   = normalizeText($_POST['room_id'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    $found = null;
    foreach ($privateRooms as $pr) {
        if (($pr['id'] ?? '') === $roomId) { $found = $pr; break; }
    }

    if (!$found) {
        http_response_code(404); echo json_encode(['ok' => false, 'error' => 'Salon introuvable.']); exit;
    }
    if (!password_verify($password, $found['password_hash'] ?? '')) {
        http_response_code(403); echo json_encode(['ok' => false, 'error' => 'Mot de passe incorrect.']); exit;
    }

    if (!isset($_SESSION['chat_unlocked_private_rooms'])) $_SESSION['chat_unlocked_private_rooms'] = [];
    if (!in_array($roomId, $_SESSION['chat_unlocked_private_rooms'], true)) {
        $_SESSION['chat_unlocked_private_rooms'][] = $roomId;
    }

    $unlockToken = hash_hmac('sha256', $roomId, $found['password_hash']);
    echo json_encode(['ok' => true, 'unlock_token' => $unlockToken]);
    exit;
}

/* ══ RESTORE PRIVATE ROOMS (localStorage → session) ════════════ */
if ($action === 'restore_private_rooms') {
    if ($requestMethod !== 'POST') {
        http_response_code(405); echo json_encode(['ok' => false]); exit;
    }
    $entries = json_decode((string)($_POST['rooms'] ?? '[]'), true);
    $byId    = [];
    foreach ($privateRooms as $pr) { if (($pr['id'] ?? '') !== '') $byId[$pr['id']] = $pr; }

    if (!isset($_SESSION['chat_unlocked_private_rooms'])) $_SESSION['chat_unlocked_private_rooms'] = [];
    $restored = 0;
    foreach ((is_array($entries) ? $entries : []) as $entry) {
        $rid   = (string)($entry['room_id'] ?? '');
        $token = (string)($entry['token']   ?? '');
        if ($rid === '' || $token === '' || !isset($byId[$rid])) continue;
        $expected = hash_hmac('sha256', $rid, $byId[$rid]['password_hash'] ?? '');
        if (hash_equals($expected, $token)) {
            if (!in_array($rid, $_SESSION['chat_unlocked_private_rooms'], true)) {
                $_SESSION['chat_unlocked_private_rooms'][] = $rid;
            }
            $restored++;
        }
    }
    echo json_encode(['ok' => true, 'restored' => $restored]);
    exit;
}

/* ══ CONVERSATIONS DM (pour l'utilisateur courant) ═════════════ */
if ($action === 'conversations') {
    if (!$isUserAuthenticated && !$isAdminAuthenticated) {
        echo json_encode(['conversations' => []]);
        exit;
    }
    $meId     = chatMeId($isAdminAuthenticated, $currentUserId);
    $index    = dbGetDmIndex($db);
    $dmReadAll = dbGetDmReadAll($db);
    $myReads  = $dmReadAll[$meId] ?? [];
    $convs    = [];

    foreach ($index as $entry) {
        if (!in_array($meId, $entry['participants'] ?? [])) continue;
        /* Masquer les conversations impliquant le profil bootstrap __admin__ */
        if (in_array('__admin__', $entry['participants'] ?? [])) continue;
        $entryType = $entry['type'] ?? 'dm';
        $otherId   = null;
        $otherName = null;
        if ($entryType === 'dm') {
            foreach ($entry['participants'] as $uid) {
                if ($uid !== $meId) {
                    $otherId   = $uid;
                    $otherName = $entry['participant_names'][$uid] ?? $uid;
                    break;
                }
            }
        }
        $key         = $entry['key'];
        $lastTs      = (int)($entry['last_ts'] ?? 0);
        $myReadTs    = (int)($myReads[$key] ?? 0);
        $otherReadTs = ($entryType === 'dm' && $otherId !== null) ? (int)(($dmReadAll[$otherId] ?? [])[$key] ?? 0) : 0;

        /* Comptage des messages non lus */
        $unreadCount = 0;
        if ($lastTs > $myReadTs) {
            $newMsgs = dbGetChatMessages($db, $entryType, $key, 500, $myReadTs);
            foreach ($newMsgs as $dm) {
                if (($dm['author_id'] ?? '') !== $meId) $unreadCount++;
            }
        }

        $convs[] = [
            'key'            => $key,
            'type'           => $entryType,
            'name'           => $entry['name'] ?? '',
            'participants'   => $entry['participants'] ?? [],
            'other_id'       => $otherId,
            'other_name'     => $otherName,
            'last_ts'        => $lastTs,
            'last_author'    => $entry['last_author']    ?? '',
            'last_author_id' => $entry['last_author_id'] ?? '',
            'last_text'      => $entry['last_text']      ?? '',
            'my_read_ts'     => $myReadTs,
            'other_read_ts'  => $otherReadTs,
            'unread_count'   => $unreadCount,
        ];
    }
    usort($convs, fn($a, $b) => $b['last_ts'] - $a['last_ts']);
    echo json_encode(['conversations' => $convs]);
    exit;
}

/* ══ USERS (liste pour sélecteur DM) ═══════════════════════════ */
if ($action === 'users') {
    if (!$isUserAuthenticated && !$isAdminAuthenticated) {
        http_response_code(401);
        echo json_encode(['error' => 'Connexion requise.']);
        exit;
    }
    $meId      = chatMeId($isAdminAuthenticated, $currentUserId);
    $onlineSet = array_flip(dbGetOnlineUsernames($db, 20));
    $list = [];

    foreach ($users as $u) {
        if (($u['status'] ?? '') !== 'active') continue;
        if (($u['id'] ?? '') === $meId) continue;
        $uname = $u['username'] ?? '';
        $list[] = [
            'id'        => $u['id'],
            'name'      => $uname,
            'is_admin'  => (($u['role'] ?? 'user') === 'admin') ? 1 : 0,
            'is_online' => isset($onlineSet[$uname]) ? 1 : 0,
        ];
    }

    echo json_encode(['users' => $list]);
    exit;
}

/* ══ LIST ══════════════════════════════════════════════════════ */
if ($action === 'list') {
    $type  = (string)($_GET['type']  ?? 'room');
    $id    = (string)($_GET['id']    ?? 'general');
    $since = (int)($_GET['since']    ?? 0);

    if ($type === 'dm' && !$isUserAuthenticated && !$isAdminAuthenticated) {
        http_response_code(401);
        echo json_encode(['error' => 'Connexion requise.']);
        exit;
    }

    $limit = min((int)($chatCfg['history_limit'] ?? 100), 500);
    $msgs  = dbGetChatMessages($db, $type, $id, $limit, $since);

    /* Marquer le DM/groupe comme lu + récupérer le timestamp de lecture de l'autre */
    $otherReadTs = 0;
    if (($type === 'dm' || $type === 'group') && $id !== '') {
        $meId = chatMeId($isAdminAuthenticated, $currentUserId);
        $now  = time();
        dbSetDmRead($db, $meId, $id, $now);

        /* Timestamp de lecture de l'autre participant (DM uniquement) */
        if ($type === 'dm') {
            $index    = dbGetDmIndex($db);
            $idxEntry = $index[$id] ?? null;
            if ($idxEntry) {
                $dmReadAll = dbGetDmReadAll($db);
                foreach ($idxEntry['participants'] as $uid) {
                    if ($uid !== $meId) {
                        $otherReadTs = (int)(($dmReadAll[$uid] ?? [])[$id] ?? 0);
                        break;
                    }
                }
            }
        }
    }

    echo json_encode(['messages' => array_values($msgs), 'other_read_ts' => $otherReadTs]);
    exit;
}

/* ══ SEND ══════════════════════════════════════════════════════ */
if ($action === 'send') {
    if ($requestMethod !== 'POST') {
        http_response_code(405); echo json_encode(['error' => 'POST requis.']); exit;
    }
    if (!$isUserAuthenticated && !$isAdminAuthenticated) {
        http_response_code(401); echo json_encode(['error' => 'Connexion requise.']); exit;
    }
    $token = (string)($_POST['csrf_token'] ?? '');
    if (!verifyCsrfToken($token)) {
        http_response_code(403); echo json_encode(['error' => 'Token CSRF invalide.']); exit;
    }

    $type   = (string)($_POST['type']    ?? 'room');
    $id     = (string)($_POST['id']      ?? 'general');
    $text   = trim((string)($_POST['message'] ?? ''));
    $maxLen = (int)($chatCfg['max_length'] ?? 500);

    if ($text === '') { echo json_encode(['error' => 'Message vide.']); exit; }
    if (mb_strlen($text) > $maxLen) {
        echo json_encode(['error' => 'Message trop long (' . $maxLen . ' car. max).']); exit;
    }

    $meId   = chatMeId($isAdminAuthenticated, $currentUserId);
    $meName = chatMeName($isAdminAuthenticated, $currentUsername, $chatCfg);

    // Pour les DM : vérifier/recalculer la clé
    $toId   = '';
    $toName = '';
    if ($type === 'dm') {
        $toId   = (string)($_POST['to_id']   ?? '');
        $toName = (string)($_POST['to_name'] ?? '');
        $id     = chatDmKey($meId, $toId);
    } elseif ($type === 'group') {
        $id = preg_replace('/[^a-z0-9_]/i', '', $id); // sécuriser la clé groupe
    }

    $msg = [
        'id'        => uniqid('c', true),
        'author'    => $meName,
        'author_id' => $meId,
        'is_admin'  => $isAdminAuthenticated ? 1 : 0,
        'text'      => $text,
        'ts'        => time(),
    ];

    dbAddChatMessage($db, $type, $id, $msg);

    // Journaliser l'activité (membres uniquement, pas l'admin système)
    if ($isUserAuthenticated && $currentUserId) {
        if ($type === 'dm') {
            dbLogActivity($db, $meId, $meName, 'chat_dm', 'Message direct à : ' . $toName);
        } else {
            dbLogActivity($db, $meId, $meName, 'chat_message', 'Salon : ' . $id);
        }
    }

    if ($type === 'dm' && $toId !== '') {
        $entry = [
            'key'               => $id,
            'type'              => 'dm',
            'participants'      => [$meId, $toId],
            'participant_names' => [$meId => $meName, $toId => $toName],
            'last_ts'           => $msg['ts'],
            'last_author'       => $meName,
            'last_author_id'    => $meId,
            'last_text'         => mb_substr($text, 0, 60),
        ];
        dbUpsertDmIndex($db, $id, $entry);
    } elseif ($type === 'group') {
        $index    = dbGetDmIndex($db);
        $existing = $index[$id] ?? null;
        if ($existing) {
            $existing['last_ts']        = $msg['ts'];
            $existing['last_author']    = $meName;
            $existing['last_author_id'] = $meId;
            $existing['last_text']      = mb_substr($text, 0, 60);
            dbUpsertDmIndex($db, $id, $existing);
        }
    }

    echo json_encode([
        'message'   => $msg,
        'dm_key'    => ($type === 'dm')    ? $id : null,
        'group_key' => ($type === 'group') ? $id : null,
    ]);
    exit;
}

/* ══ INVITE (ajouter un membre à une conv DM ou groupe) ════════ */
if ($action === 'invite') {
    if ($requestMethod !== 'POST') {
        http_response_code(405); echo json_encode(['error' => 'POST requis.']); exit;
    }
    if (!$isUserAuthenticated && !$isAdminAuthenticated) {
        http_response_code(401); echo json_encode(['error' => 'Connexion requise.']); exit;
    }
    $token = (string)($_POST['csrf_token'] ?? '');
    if (!verifyCsrfToken($token)) {
        http_response_code(403); echo json_encode(['error' => 'Token CSRF invalide.']); exit;
    }

    $convKey = preg_replace('/[^a-z0-9_]/i', '', (string)($_POST['conv_key'] ?? ''));
    $toId    = trim((string)($_POST['to_id']   ?? ''));
    $toName  = trim((string)($_POST['to_name'] ?? ''));

    if ($convKey === '' || $toId === '' || $toName === '') {
        http_response_code(400); echo json_encode(['error' => 'Paramètres manquants.']); exit;
    }

    $meId   = chatMeId($isAdminAuthenticated, $currentUserId);
    $meName = chatMeName($isAdminAuthenticated, $currentUsername, $chatCfg);

    $index = dbGetDmIndex($db);

    if (!isset($index[$convKey])) {
        http_response_code(404); echo json_encode(['error' => 'Conversation introuvable.']); exit;
    }
    $entry = $index[$convKey];

    if (!in_array($meId, $entry['participants'] ?? [])) {
        http_response_code(403); echo json_encode(['error' => 'Non autorisé.']); exit;
    }
    if (in_array($toId, $entry['participants'] ?? [])) {
        http_response_code(400); echo json_encode(['error' => 'Ce membre est déjà dans la conversation.']); exit;
    }

    /* Nouvelle clé de groupe */
    $newKey = 'grp_' . bin2hex(random_bytes(6));

    /* Copier les messages existants */
    $oldMsgs = dbGetChatMessages($db, $entry['type'] ?? 'dm', $convKey, 9999, 0);

    /* Message système d'invitation */
    $systemMsg = [
        'id'        => uniqid('sys', true),
        'author'    => '',
        'author_id' => '__system__',
        'is_admin'  => 0,
        'is_system' => 1,
        'text'      => $meName . ' a invité ' . $toName . ' à rejoindre la conversation.',
        'ts'        => time(),
    ];

    /* Nouveaux participants */
    $newParticipants     = array_merge($entry['participants'] ?? [], [$toId]);
    $newParticipantNames = array_merge($entry['participant_names'] ?? [], [$toId => $toName]);
    $nameList  = implode(', ', array_values($newParticipantNames));
    $groupName = 'Groupe · ' . (mb_strlen($nameList) > 45 ? mb_substr($nameList, 0, 45) . '…' : $nameList);

    /* Écrire les messages dans la nouvelle conv groupe */
    foreach (array_merge($oldMsgs, [$systemMsg]) as $m) {
        dbAddChatMessage($db, 'group', $newKey, $m);
    }

    /* Mettre à jour l'index */
    $newEntry = [
        'key'               => $newKey,
        'type'              => 'group',
        'name'              => $groupName,
        'participants'      => $newParticipants,
        'participant_names' => $newParticipantNames,
        'last_ts'           => $systemMsg['ts'],
        'last_author'       => $meName,
        'last_author_id'    => $meId,
        'last_text'         => mb_substr($systemMsg['text'], 0, 60),
    ];
    dbUpsertDmIndex($db, $newKey, $newEntry);

    echo json_encode([
        'group_key'    => $newKey,
        'group_name'   => $groupName,
        'participants' => $newParticipants,
    ]);
    exit;
}

/* ══ PURGE (admin) ═════════════════════════════════════════════ */
if ($action === 'purge') {
    if (!$isAdminAuthenticated) {
        http_response_code(403); echo json_encode(['error' => 'Non autorisé.']); exit;
    }
    if ($requestMethod !== 'POST') {
        http_response_code(405); echo json_encode(['error' => 'POST requis.']); exit;
    }
    $token = (string)($_POST['csrf_token'] ?? '');
    if (!verifyCsrfToken($token)) {
        http_response_code(403); echo json_encode(['error' => 'Token CSRF invalide.']); exit;
    }
    $type = (string)($_POST['type'] ?? 'room');
    $id   = (string)($_POST['id']   ?? 'general');
    dbPurgeChatMessages($db, $type, $id);
    echo json_encode(['ok' => true]);
    exit;
}

/* ══ SIGNAL (WebRTC – appels audio) ═══════════════════════════ */
if ($action === 'signal') {
    if (!$isUserAuthenticated && !$isAdminAuthenticated) {
        http_response_code(401);
        echo json_encode(['error' => 'Connexion requise.']);
        exit;
    }
    $meId = chatMeId($isAdminAuthenticated, $currentUserId);
    $now  = time();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        /* ── Envoyer un signal ─────────────────────────────── */
        $body    = json_decode(file_get_contents('php://input'), true) ?? [];
        $toId    = normalizeText($body['to_id']    ?? '');
        $type    = normalizeText($body['type']      ?? '');
        $fromNm  = normalizeText($body['from_name'] ?? '');
        $data    = $body['data'] ?? null;

        if ($toId === '' || $type === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Paramètres manquants.']);
            exit;
        }

        dbAddCallSignal($db, $toId, $meId, $fromNm, $type, $data, $now);
        echo json_encode(['ok' => true]);
        exit;
    }

    /* ── Récupérer et vider les signaux en attente ─────────── */
    $mine = dbGetCallSignals($db, $meId, $now);
    dbClearCallSignals($db, $meId);

    echo json_encode(['signals' => $mine]);
    exit;
}

echo json_encode(['error' => 'Action inconnue.']);
