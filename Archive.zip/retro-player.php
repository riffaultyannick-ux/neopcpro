<?php
/**
 * Page émulateur rétro — chargée dans un iframe depuis jeux-retro.php.
 * Pas de nav, pas de layout site — uniquement l'émulateur plein écran.
 */
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';

if (!$isUserAuthenticated && !$isAdminAuthenticated) {
    http_response_code(403);
    exit('Accès refusé');
}

/* ── Paramètres ────────────────────────────────────────────────── */
$validPlatforms = [
    'snes','nes','n64','gba','gb','nds',
    'psx','psp',
    'md','sega32x','segacd','saturn','sms','gg',
    'pce','pcfx',
    'arcade',
    'jaguar','lynx',
    'ngp','ws',
    'coleco',
    'amiga','c64','c128',
];
$validCores = [
    'snes9x','fceumm','nestopia','mesen',
    'mupen64plus_next','parallel_n64',
    'mgba','gambatte',
    'melonds','desmume','desmume2015',
    'pcsx_rearmed','mednafen_psx_hw',
    'ppsspp',
    'genesis_plus_gx','picodrive',
    'yabause',
    'smsplus',
    'mednafen_pce','mednafen_pcfx',
    'fbneo','fbalpha2012_cps1','fbalpha2012_cps2','mame2003','mame2003_plus',
    'virtualjaguar','handy',
    'mednafen_ngp','mednafen_wswan',
    'gearcoleco',
    'puae','vice_x64sc','vice_x64','vice_x128',
];
$validExts = [
    'sfc','smc','fig','swc',
    'nes','fds','unf','unif',
    'z64','n64','v64',
    'gba','gb','gbc',
    'nds',
    'vb','vboy',
    'bin','cue','img','iso','pbp','chd','cso',
    'md','smd','gen','32x',
    'sms','gg',
    'pce',
    'a26','a52','a78',
    'j64','jag',
    'lnx','ngp','ngc','ws','wsc',
    'col','cv',
    'adf','hdf',
    'd64','t64','prg','crt','tap','tzx',
    'z80','sna','dsk',
    'wad',
    'zip','gz','7z',
];

$pid    = preg_replace('/[^a-z0-9]/', '', $_GET['pid']  ?? '');
$file   = basename($_GET['file']  ?? '');
$core   = preg_replace('/[^a-z0-9_]/', '', $_GET['core'] ?? '');
$name   = trim(strip_tags($_GET['name'] ?? $file));

/* Validation */
if (!$pid || !in_array($pid, $validPlatforms, true)) { http_response_code(400); exit('Plateforme invalide'); }
if (!$file) { http_response_code(400); exit('Fichier manquant'); }
if (!in_array($core, $validCores, true)) { http_response_code(400); exit('Core invalide'); }
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
if (!in_array($ext, $validExts, true)) { http_response_code(403); exit; }
$romPath = __DIR__ . '/web_private/roms/' . $pid . '/' . $file;
if (!is_file($romPath)) { http_response_code(404); exit('ROM introuvable'); }

/* URL ROM — URL PHP directe, compatible nginx (pas de mod_rewrite requis) */
$romUrl  = '/api/rom-serve.php?pid=' . rawurlencode($pid) . '&file=' . rawurlencode($file);
$ejsBase = '/assets/emulatorjs/';

/* Threads : nécessite SharedArrayBuffer (headers COOP/COEP côté serveur) */
$useThreads = 'false';

/* Nonce CSP : réutilise celui de la session (posé par config.php) et
   remplace le header CSP générique par un header adapté à EmulatorJS */
$nonce = $cspNonce;
header_remove('Content-Security-Policy');
header(
    "Content-Security-Policy: " .
    "default-src 'self'; " .
    "script-src 'self' 'nonce-{$nonce}' blob: 'unsafe-eval'; " .
    "style-src 'self' 'unsafe-inline'; " .
    "img-src 'self' data: blob:; " .
    "media-src 'self' blob:; " .
    "connect-src 'self' blob:; " .
    "worker-src 'self' blob:; " .
    "frame-src 'none';"
);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($name, ENT_QUOTES); ?></title>
<style>
*, *::before, *::after { box-sizing: border-box; }
html, body {
    margin: 0; padding: 0;
    width: 100%; height: 100%;
    background: #000;
    overflow: hidden;
}
#game {
    width: 100%;
    height: 100%;
}
/* Force le canvas à remplir le conteneur (stretch adaptatif) */
#game canvas {
    width: 100% !important;
    height: 100% !important;
    display: block;
    object-fit: fill;
}
</style>
</head>
<body>
<div id="game"></div>
<div id="gp-hint" style="
    position:fixed;bottom:1.2rem;left:50%;transform:translateX(-50%);
    background:rgba(0,0,0,.78);color:#fff;padding:.45rem 1rem;
    border-radius:8px;font-size:.82rem;white-space:nowrap;
    pointer-events:none;z-index:9999;
    transition:opacity .4s;
">🎮 Appuie sur un bouton de ta manette pour l'activer</div>
<script nonce="<?php echo $nonce; ?>">
EJS_player         = '#game';
EJS_core           = <?php echo json_encode($core); ?>;
EJS_gameUrl        = <?php echo json_encode($romUrl); ?>;
EJS_gameName       = <?php echo json_encode($name); ?>;
EJS_pathtodata     = <?php echo json_encode($ejsBase); ?>;
EJS_startOnLoaded  = true;
/* Désactiver le stockage interne d'EmulatorJS (IndexedDB/localStorage)
   afin que le serveur soit la seule source de vérité pour les sauvegardes.
   EJS_onLoadSave et EJS_onSaveSave gèrent tout. */
EJS_disableDatabases    = true;
EJS_disableLocalStorage = true;
EJS_language       = 'fr-FR';
EJS_threads        = <?php echo $useThreads; ?>;
EJS_color          = '#38bdf8';
EJS_backgroundColor = '#000000';

/* ── Sauvegarde serveur ── */
var _savePlatform = <?php echo json_encode($pid); ?>;
var _saveBase     = '/api/game-save.php?platform=' + encodeURIComponent(_savePlatform);
/* Slug stable dérivé du vrai nom de fichier ROM (pas de l'URL du script). */
var _saveSlug     = <?php echo json_encode(pathinfo($file, PATHINFO_FILENAME)); ?>;

function _saveToServer(filename, data, onDone) {
    fetch(_saveBase + '&file=' + encodeURIComponent(filename), {
        method: 'POST',
        body: data instanceof Uint8Array ? data : new Uint8Array(data),
        credentials: 'same-origin'
    }).then(function(r) {
        if (onDone) onDone(r.ok);
    }).catch(function() { if (onDone) onDone(false); });
}

function _loadFromServer(filename, onData) {
    fetch(_saveBase + '&file=' + encodeURIComponent(filename), {
        credentials: 'same-origin'
    }).then(function(r) {
        if (!r.ok) { onData(null); return; }
        return r.arrayBuffer();
    }).then(function(buf) {
        onData(buf ? new Uint8Array(buf) : null);
    }).catch(function() { onData(null); });
}

/* ── Save State ── */
EJS_onSaveState = function(data) {
    var emu = window.EJS_emulator;
    _saveToServer(_saveSlug + '.state', data.state, function(ok) {
        if (emu) emu.displayMessage(ok ? 'Sauvegarde enregistrée' : 'Échec de la sauvegarde');
    });
};

/* ── Load State ── */
EJS_onLoadState = function() {
    var emu = window.EJS_emulator;
    _loadFromServer(_saveSlug + '.state', function(bytes) {
        if (!emu) return;
        if (bytes) {
            emu.gameManager.loadState(bytes);
            emu.displayMessage('Sauvegarde chargée');
        } else {
            emu.displayMessage('Aucune sauvegarde trouvée');
        }
    });
};

/* Sync state: _loading=true pendant le fetch du serveur */
var _sramLoading = false;
var _sramLoaded = false;

/* ── Export SRAM (appelé par EmulatorJS quand le jeu sauvegarde) ── */
EJS_onSaveSave = function(data) {
    var emu = window.EJS_emulator;
    var saveData = data.save;
    if (!saveData) return;

    /* Convertir en Uint8Array si nécessaire */
    var bytes = (saveData instanceof Uint8Array) ? saveData : new Uint8Array(saveData);

    /* 1. Envoyer au serveur IMMÉDIATEMENT */
    _saveToServer(_saveSlug + '.srm', bytes, function(ok) {
        if (emu) emu.displayMessage(ok ? '💾 Sauvegarde enregistrée' : '⚠️ Échec de la sauvegarde');
    });

    /* 2. Mettre à jour le cache localStorage comme sauvegarde de secours */
    try {
        var b64 = btoa(String.fromCharCode.apply(null, bytes));
        localStorage.setItem('_sram_' + _saveSlug, b64);
    } catch(e) {}
};

/* ── Import SRAM (appelé par EmulatorJS au démarrage) ── */
EJS_onLoadSave = function() {
    var emu = window.EJS_emulator;
    if (!emu) return;
    _sramLoading = true;

    /* Charger depuis le serveur (source autoritaire) */
    _loadFromServer(_saveSlug + '.srm', function(bytes) {
        _sramLoading = false;
        _sramLoaded = true;

        if (!bytes) {
            emu.displayMessage('Aucune sauvegarde trouvée');
            return;
        }

        _writeSramToCore(bytes);

        /* Mettre à jour le cache localStorage */
        try {
            var b64 = btoa(String.fromCharCode.apply(null, bytes));
            localStorage.setItem('_sram_' + _saveSlug, b64);
        } catch(e) {}

        emu.displayMessage('✓ Sauvegarde chargée');
    });
};

/* Écrit les bytes SRAM dans le FS et recharge le cœur. */
function _writeSramToCore(bytes) {
    var emu = window.EJS_emulator;
    if (!bytes || !emu || !emu.gameManager) return;
    var path = (emu.gameManager.getSaveFilePath)
             ? emu.gameManager.getSaveFilePath()
             : '/' + _saveSlug + '.srm';
    var dir = path.split('/').slice(0, -1).join('/');
    if (dir) { try { emu.gameManager.FS.mkdirTree(dir); } catch(e) {} }
    try { emu.gameManager.FS.writeFile(path, bytes); } catch(e) { return; }
    if (emu.gameManager.loadSaveFiles) try { emu.gameManager.loadSaveFiles(); } catch(e) {}
}

/* ── Initialisation au démarrage du jeu ── */
EJS_onGameStart = function() {
    var emu = window.EJS_emulator;
    if (!emu) return;

    /* EmulatorJS monte /data/saves via IDBFS (IndexedDB) AVANT ce callback :
       la SRAM déjà chargée par IDBFS peut être obsolète si le fichier serveur
       a été supprimé ou modifié. On charge depuis le serveur (source autoritaire)
       et on écrase immédiatement ce qu'IDBFS a injecté. */
    _loadFromServer(_saveSlug + '.srm', function(bytes) {
        if (!bytes) {
            /* Aucune sauvegarde sur le serveur → forcer la SRAM vide en écrasant
               le fichier IDBFS avec des zéros de même taille, puis recharger.
               Un simple unlink() est ignoré par certains cores (ils gardent la
               SRAM en mémoire vive). Écrire un buffer nul force le rechargement. */
            try {
                var path = (emu.gameManager.getSaveFilePath)
                    ? emu.gameManager.getSaveFilePath()
                    : '/data/saves/' + _saveSlug + '.srm';
                var info = emu.gameManager.FS.analyzePath(path);
                if (info && info.exists) {
                    var existing = emu.gameManager.FS.readFile(path);
                    var zeros    = new Uint8Array(existing ? existing.length : 0);
                    emu.gameManager.FS.writeFile(path, zeros);
                    if (emu.gameManager.loadSaveFiles) emu.gameManager.loadSaveFiles();
                }
            } catch(e) {}
            return;
        }
        /* Écriture de la SRAM serveur dans le cœur — remplace la version IDBFS */
        _writeSramToCore(bytes);
    });

    /* Sauvegarder la SRAM dès que RetroArch l'écrit (auto-save toutes les
       60 s, et à chaque sauvegarde manuelle via le menu RetroArch).
       L'event 'saveSaveFiles' est émis par GameManager.saveSaveFiles() qui
       est lui-même appelé par la boucle autosave_interval de RetroArch. */
    emu.on('saveSaveFiles', function() { _flushSram(false); });

    /* Sauvegarder la SRAM à la fermeture propre de l'émulateur. */
    emu.on('exit', function() { _flushSram(); });
};

/* Sauvegarde SRAM fiable et immédiate (pas seulement à la fermeture).
   sendBeacon garantit l'envoi même lors du déchargement de la page.
   Un cache localStorage sert de secours temporaire si le réseau est indisponible. */
function _flushSram(isUnload) {
    var emu = window.EJS_emulator;
    if (!emu || !emu.gameManager) return;

    /* Synchroniser la SRAM du cœur vers le FS avant de la lire */
    if (emu.gameManager.saveSaveFiles) {
        try { emu.gameManager.saveSaveFiles(); } catch(e) {}
    }

    if (!emu.gameManager.getSaveFile) return;

    var saveData = emu.gameManager.getSaveFile();
    if (!saveData || !saveData.length) return;

    /* Convertir en Uint8Array si nécessaire */
    var bytes = (saveData instanceof Uint8Array) ? saveData : new Uint8Array(saveData);

    /* Cache localStorage temporaire — sauvegarde de secours si le serveur est indisponible */
    try {
        var b64 = btoa(String.fromCharCode.apply(null, bytes));
        localStorage.setItem('_sram_' + _saveSlug, b64);
    } catch(e) {}

    /* Envoi serveur */
    var url = _saveBase + '&file=' + encodeURIComponent(_saveSlug + '.srm');
    if (isUnload && navigator.sendBeacon) {
        /* À la fermeture de la page: sendBeacon est plus fiable
           (survit au déchargement de la page) */
        navigator.sendBeacon(url, new Blob([bytes], { type: 'application/octet-stream' }));
    } else {
        /* Pendant la partie: fetch classique pour confirmer l'envoi */
        _saveToServer(_saveSlug + '.srm', bytes, null);
    }
}

/* Sauvegarde à la fermeture de la page */
window.addEventListener('pagehide',     function() { _flushSram(true); });
window.addEventListener('beforeunload', function() { _flushSram(true); });

/* ── Synchronise les attributs width/height du canvas avec sa taille CSS ──
   EmulatorJS fixe canvas.width/height à la résolution native du jeu (ex. 256×224
   pour SNES). Le CSS les étire à 100% mais WebGL lit les attributs, d'où le
   warning "Drawing to a destination rect smaller than the viewport rect".
   On observe le conteneur #game et, dès qu'un canvas apparaît, on aligne
   les attributs sur la taille affichée. ─────────────────────────────────── */
(function () {
    var ro = new ResizeObserver(function () {
        var canvas = document.querySelector('#game canvas');
        if (!canvas) return;
        var w = Math.round(canvas.getBoundingClientRect().width)  || canvas.offsetWidth;
        var h = Math.round(canvas.getBoundingClientRect().height) || canvas.offsetHeight;
        if (w > 0 && h > 0 && (canvas.width !== w || canvas.height !== h)) {
            canvas.width  = w;
            canvas.height = h;
        }
    });
    var game = document.getElementById('game');
    if (game) ro.observe(game);
    /* Aussi surveiller l'apparition tardive du canvas (EmulatorJS l'insère après init) */
    var mo = new MutationObserver(function (mutations) {
        mutations.forEach(function (m) {
            m.addedNodes.forEach(function (n) {
                if (n.nodeName === 'CANVAS') { ro.observe(n); }
            });
        });
    });
    if (game) mo.observe(game, { childList: true, subtree: true });
})();

/* ── Détection continue des manettes ────────────────────────────────────
   Le navigateur ne fire "gamepadconnected" que si la manette est branchée
   APRÈS le chargement de la page. Pour les manettes déjà connectées on
   utilise un polling qui surveille navigator.getGamepads() et dispatch
   un événement synthétique dès qu'une nouvelle manette apparaît.
   Fonctionne aussi à chaque rechargement de jeu. */
(function () {
    var hint = document.getElementById('gp-hint');

    /* Masquer le hint dès qu'une manette est détectée (native ou synthétique). */
    function hideHint() {
        if (!hint) return;
        hint.style.opacity = '0';
        setTimeout(function () { if (hint && hint.parentNode) hint.parentNode.removeChild(hint); }, 400);
        hint = null;
    }

    /* Masquer le hint si pas de support Gamepad API. */
    if (!navigator.getGamepads) hideHint();

    var seen      = {};
    var synthetic = false; /* flag pour distinguer dispatch synthétique / natif */

    window.addEventListener('gamepadconnected', function (e) {
        if (!synthetic) {
            /* Événement natif : la manette est vraiment activée. */
            seen[e.gamepad.index] = true;
            hideHint();
        }
    });
    window.addEventListener('gamepaddisconnected', function (e) {
        delete seen[e.gamepad.index];
    });

    function poll() {
        var gps = navigator.getGamepads ? navigator.getGamepads() : [];
        for (var i = 0; i < gps.length; i++) {
            var gp = gps[i];
            if (gp && !seen[gp.index]) {
                /* Ne pas marquer comme vu ici — on continue de réessayer
                   jusqu'à ce que l'événement natif confirme l'activation. */
                synthetic = true;
                try { window.dispatchEvent(new GamepadEvent('gamepadconnected', { gamepad: gp })); } catch (e) {}
                synthetic = false;
            }
        }
    }

    /* Démarrer le polling seulement après le chargement d'EmulatorJS
       pour que son listener gamepadconnected soit déjà enregistré. */
    window.addEventListener('load', function () {
        setTimeout(function () {
            poll();
            setInterval(poll, 1000);
        }, 800);
    });
    window.addEventListener('focus', poll);
})();
</script>
<script src="<?php echo htmlspecialchars($ejsBase . 'loader.js', ENT_QUOTES); ?>" nonce="<?php echo $nonce; ?>"></script>
</body>
</html>
