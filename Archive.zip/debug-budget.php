<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
$meId = $_SESSION['user_id'] ?? '';
$settings = dbGetBudgetSettings($db, $meId);
echo "User: " . $meId . "\n";
print_r($settings);
