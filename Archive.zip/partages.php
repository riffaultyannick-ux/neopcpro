<?php
/**
 * NéoPcPro – Mes partages
 * Vue centralisée des partages entrants/sortants, liens, favoris et verrous.
 */
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

if (!$isUserAuthenticated) {
    header('Location: index.php?show_login=1');
    exit;
}
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: index.php');
    exit;
}

$flash = getFlash();

/* ── Données ──────────────────────────────────────────────── */

// 1. Partagés avec moi
$sharedWithMe = fmGetSharedWithMe($db, $currentUserId);

// 2. Partagés par moi
$sharedByMe = fmGetSharedByMe($db, $currentUserId);

// 3. Liens temporaires actifs (que j'ai créés)
$now = date('Y-m-d H:i:s');
$linkStmt = $db->prepare(
    'SELECT sl.id, sl.token, sl.expires_at, sl.created_at,
            sl.password_hash != "" AS has_password,
            f.original_name, f.id AS file_id
     FROM fm_share_links sl
     JOIN fm_files f ON f.id = sl.file_id
     WHERE sl.owner_id=? AND sl.expires_at > ?
     ORDER BY sl.expires_at ASC'
);
$linkStmt->execute([$currentUserId, $now]);
$activeLinks = $linkStmt->fetchAll();

// 4. Fichiers partagés récemment (auditlog : action=share, derniers 20)
$presentedStmt = $db->prepare(
    'SELECT a.target_name, a.created_at, f.id AS file_id, f.mime_type, f.size
     FROM fm_audit a
     LEFT JOIN fm_files f ON f.original_name = a.target_name AND f.user_id = a.user_id
     WHERE a.user_id=? AND a.action=?
     ORDER BY a.created_at DESC LIMIT 20'
);
$presentedStmt->execute([$currentUserId, 'share']);
$recentlyShared = $presentedStmt->fetchAll();

// 5. Favoris — fichiers reçus en partage que j'ai mis en favoris
$favData  = fmListFavorites($db, $currentUserId);
$favFiles = $favData['files'] ?? [];
// Filtrer : garder uniquement ceux partagés avec moi
$sharedIds = array_column($sharedWithMe, 'id');
$favReceived = array_filter($favFiles, function($f) use ($sharedIds) {
    return in_array($f['id'], $sharedIds);
});

// 6. Documents verrouillés par moi
$lockStmt = $db->prepare(
    'SELECT l.id AS lock_id, l.locked_at, l.expires_at,
            f.id AS file_id, f.original_name, f.mime_type, f.size
     FROM fm_locks l
     JOIN fm_files f ON f.id = l.file_id
     WHERE l.user_id=?
     ORDER BY l.expires_at ASC'
);
$lockStmt->execute([$currentUserId]);
$lockedFiles = $lockStmt->fetchAll();

/* ── Helpers ──────────────────────────────────────────────── */
function _ptFmt(int $bytes): string {
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 1) . ' Go';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 1) . ' Mo';
    if ($bytes >= 1024)       return round($bytes / 1024, 1) . ' Ko';
    return $bytes . ' o';
}
function _ptRelTime(string $dateStr): string {
    $ts = @strtotime($dateStr);
    if (!$ts) return $dateStr;
    $diff = time() - $ts;
    if ($diff < 60)     return 'À l\'instant';
    if ($diff < 3600)   return 'Il y a ' . floor($diff / 60) . ' min';
    if ($diff < 86400)  return 'Il y a ' . floor($diff / 3600) . ' h';
    if ($diff < 604800) return 'Il y a ' . floor($diff / 86400) . ' j';
    return date('j M Y', $ts);
}
function _ptTimeLeft(string $expiresAt): string {
    $ts = @strtotime($expiresAt);
    if (!$ts) return '';
    $diff = $ts - time();
    if ($diff <= 0) return 'Expiré';
    if ($diff < 3600)  return 'Expire dans ' . floor($diff / 60) . ' min';
    if ($diff < 86400) return 'Expire dans ' . floor($diff / 3600) . ' h';
    return 'Expire dans ' . floor($diff / 86400) . ' j';
}
function _ptMimeIcon(string $mime): string {
    if (str_starts_with($mime, 'image/'))  return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>';
    if (str_starts_with($mime, 'video/'))  return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>';
    if ($mime === 'application/pdf')       return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
    return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex, nofollow">
<title>Mes partages – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/partages.css?v=1">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<main class="page is-dashboard">
<section class="hero is-centered-v">
<div class="hero-content is-dashboard">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<div class="pt-wrap">

    <div class="pt-header">
        <a href="fichiers.php" class="pt-btn-back">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
            Mes fichiers
        </a>
    </div>

    <!-- Stats rapides -->
    <div class="pt-stats">
        <div class="pt-stat">
            <span class="pt-stat-num"><?php echo count($sharedWithMe); ?></span>
            <span class="pt-stat-label">Reçus</span>
        </div>
        <div class="pt-stat">
            <span class="pt-stat-num"><?php echo count($sharedByMe); ?></span>
            <span class="pt-stat-label">Envoyés</span>
        </div>
        <div class="pt-stat">
            <span class="pt-stat-num"><?php echo count($activeLinks); ?></span>
            <span class="pt-stat-label">Liens actifs</span>
        </div>
        <div class="pt-stat">
            <span class="pt-stat-num"><?php echo count($lockedFiles); ?></span>
            <span class="pt-stat-label">Verrouillés</span>
        </div>
    </div>

    <div class="pt-grid">

        <!-- ── 1. Partagés avec moi ──────────────────────────── -->
        <section class="pt-card" aria-label="Partagés avec moi">
            <div class="pt-card-head">
                <h2 class="pt-card-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    Partagés avec moi
                </h2>
                <span class="pt-count"><?php echo count($sharedWithMe); ?></span>
            </div>
            <?php if (empty($sharedWithMe)): ?>
            <p class="pt-empty">Aucun fichier partagé avec vous.</p>
            <?php else: ?>
            <ul class="pt-list">
                <?php foreach ($sharedWithMe as $s): ?>
                <li class="pt-item">
                    <span class="pt-item-icon"><?php echo _ptMimeIcon($s['mime_type'] ?? ''); ?></span>
                    <div class="pt-item-meta">
                        <span class="pt-item-name" title="<?php echo escape($s['original_name']); ?>"><?php echo escape($s['original_name']); ?></span>
                        <span class="pt-item-sub">Par <?php echo escape($s['owner_name']); ?> · <?php echo _ptFmt((int)($s['size'] ?? 0)); ?> · <?php echo _ptRelTime($s['shared_at'] ?? ''); ?></span>
                        <?php if (!empty($s['share_message'])): ?>
                        <span class="pt-item-msg"><?php echo escape($s['share_message']); ?></span>
                        <?php endif; ?>
                    </div>
                    <a href="api/dl-fichier.php?id=<?php echo urlencode($s['id']); ?>&dl=1"
                       class="pt-item-btn" title="Télécharger" aria-label="Télécharger <?php echo escape($s['original_name']); ?>">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

        <!-- ── 2. Partagés par moi ───────────────────────────── -->
        <section class="pt-card" aria-label="Partagés par moi">
            <div class="pt-card-head">
                <h2 class="pt-card-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                    Partagés par moi
                </h2>
                <span class="pt-count"><?php echo count($sharedByMe); ?></span>
            </div>
            <?php if (empty($sharedByMe)): ?>
            <p class="pt-empty">Vous n'avez partagé aucun fichier.</p>
            <?php else: ?>
            <ul class="pt-list">
                <?php foreach ($sharedByMe as $s): ?>
                <li class="pt-item">
                    <span class="pt-item-icon">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    </span>
                    <div class="pt-item-meta">
                        <span class="pt-item-name" title="<?php echo escape($s['original_name']); ?>"><?php echo escape($s['original_name']); ?></span>
                        <span class="pt-item-sub">Avec <?php echo escape($s['recipient_name']); ?> · <?php echo _ptRelTime($s['shared_at'] ?? ''); ?></span>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

        <!-- ── 3. Liens temporaires actifs ──────────────────── -->
        <section class="pt-card" aria-label="Liens temporaires">
            <div class="pt-card-head">
                <h2 class="pt-card-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>
                    Liens temporaires
                </h2>
                <span class="pt-count"><?php echo count($activeLinks); ?></span>
            </div>
            <?php if (empty($activeLinks)): ?>
            <p class="pt-empty">Aucun lien de partage actif.</p>
            <?php else: ?>
            <ul class="pt-list">
                <?php foreach ($activeLinks as $lk):
                    $shareUrl = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http')
                        . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
                        . '/partage.php?t=' . urlencode($lk['token']);
                ?>
                <li class="pt-item">
                    <span class="pt-item-icon" style="color:var(--primary)">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </span>
                    <div class="pt-item-meta">
                        <span class="pt-item-name" title="<?php echo escape($lk['original_name']); ?>"><?php echo escape($lk['original_name']); ?></span>
                        <span class="pt-item-sub">
                            <?php echo _ptTimeLeft($lk['expires_at']); ?>
                            <?php if ($lk['has_password']): ?> · <span class="pt-badge-pw">🔒 Protégé</span><?php endif; ?>
                        </span>
                    </div>
                    <button class="pt-item-btn pt-copy-btn" type="button"
                            data-copy="<?php echo escape($shareUrl); ?>"
                            title="Copier le lien">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

        <!-- ── 4. Partagés récemment ─────────────────────────── -->
        <section class="pt-card" aria-label="Partagés récemment">
            <div class="pt-card-head">
                <h2 class="pt-card-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    Partagés récemment
                </h2>
                <span class="pt-count"><?php echo count($recentlyShared); ?></span>
            </div>
            <?php if (empty($recentlyShared)): ?>
            <p class="pt-empty">Aucun partage récent.</p>
            <?php else: ?>
            <ul class="pt-list">
                <?php foreach ($recentlyShared as $rs): ?>
                <li class="pt-item">
                    <span class="pt-item-icon"><?php echo _ptMimeIcon($rs['mime_type'] ?? ''); ?></span>
                    <div class="pt-item-meta">
                        <span class="pt-item-name" title="<?php echo escape($rs['target_name']); ?>"><?php echo escape($rs['target_name']); ?></span>
                        <span class="pt-item-sub"><?php echo _ptRelTime($rs['created_at'] ?? ''); ?></span>
                    </div>
                    <?php if (!empty($rs['file_id'])): ?>
                    <a href="api/dl-fichier.php?id=<?php echo urlencode($rs['file_id']); ?>&dl=1"
                       class="pt-item-btn" title="Télécharger">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </a>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

        <!-- ── 5. Favoris reçus ──────────────────────────────── -->
        <section class="pt-card" aria-label="Favoris reçus">
            <div class="pt-card-head">
                <h2 class="pt-card-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none" aria-hidden="true"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01z"/></svg>
                    Favoris reçus
                </h2>
                <span class="pt-count"><?php echo count($favReceived); ?></span>
            </div>
            <?php if (empty($favReceived)): ?>
            <p class="pt-empty">Aucun fichier reçu mis en favori.</p>
            <?php else: ?>
            <ul class="pt-list">
                <?php foreach ($favReceived as $fav): ?>
                <li class="pt-item">
                    <span class="pt-item-icon" style="color:#f59e0b"><?php echo _ptMimeIcon($fav['mime_type'] ?? ''); ?></span>
                    <div class="pt-item-meta">
                        <span class="pt-item-name" title="<?php echo escape($fav['original_name']); ?>"><?php echo escape($fav['original_name']); ?></span>
                        <span class="pt-item-sub"><?php echo _ptFmt((int)($fav['size'] ?? 0)); ?></span>
                    </div>
                    <a href="api/dl-fichier.php?id=<?php echo urlencode($fav['id']); ?>&dl=1"
                       class="pt-item-btn" title="Télécharger">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </a>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

        <!-- ── 6. Documents verrouillés ─────────────────────── -->
        <section class="pt-card" aria-label="Documents verrouillés">
            <div class="pt-card-head">
                <h2 class="pt-card-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                    Documents verrouillés
                </h2>
                <span class="pt-count"><?php echo count($lockedFiles); ?></span>
            </div>
            <?php if (empty($lockedFiles)): ?>
            <p class="pt-empty">Aucun document verrouillé.</p>
            <?php else: ?>
            <ul class="pt-list">
                <?php foreach ($lockedFiles as $lf): ?>
                <li class="pt-item">
                    <span class="pt-item-icon" style="color:var(--danger)"><?php echo _ptMimeIcon($lf['mime_type'] ?? ''); ?></span>
                    <div class="pt-item-meta">
                        <span class="pt-item-name" title="<?php echo escape($lf['original_name']); ?>"><?php echo escape($lf['original_name']); ?></span>
                        <span class="pt-item-sub"><?php echo _ptTimeLeft($lf['expires_at']); ?> · <?php echo _ptFmt((int)($lf['size'] ?? 0)); ?></span>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </section>

    </div><!-- .pt-grid -->

</div><!-- .pt-wrap -->

</div>
</section>
</main>

<?php require __DIR__ . '/includes/admin-modal.php'; ?>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">


/* Copier un lien */
document.querySelectorAll('.pt-copy-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var url = btn.getAttribute('data-copy');
        if (!url) return;
        navigator.clipboard.writeText(url).then(function() {
            var orig = btn.innerHTML;
            btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>';
            setTimeout(function(){ btn.innerHTML = orig; }, 1500);
        }).catch(function() {});
    });
});
</script>

</body>
</html>
