<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Réservé aux membres : rediriger les visiteurs non connectés
if (!$isUserAuthenticated && !$isAdminAuthenticated) {
    header('Location: /index.php?show_login=1');
    exit;
}

// Maintenance : bloquer les membres non-admin déjà connectés
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php');
    exit;
}

// Mode embed (iframe depuis overlay) : ne pas rendre le chrome complet
$embedMode  = !empty($_GET['embed']);
$embedParam = $embedMode ? '&embed=1' : '';

// URL de retour après POST (pour _panel_referer)
$returnUrl = '/messages.php?' . http_build_query($_GET);

// Réglages messagerie
$msgEnabled   = (int)($siteSettings['messaging']['enabled'] ?? 1);
$msgMaxLength = max(50, (int)($siteSettings['messaging']['max_length'] ?? 3000));

// Modale admin
if ($isAdminAuthenticated && (string)($_GET['admin'] ?? '') === '1') {
    $shouldAutoOpenAdminModal = true;
}

$flash = getFlash();

// Onglets messagerie (compose géré via overlay)
$tabOptions = ['inbox' => 'Boîte de réception', 'sent' => 'Messages envoyés', 'trash' => 'Corbeille', 'dossiers' => 'Dossiers'];
$activeTab  = isset($_GET['tab']) && array_key_exists($_GET['tab'], $tabOptions) ? $_GET['tab'] : 'inbox';

// Dossiers de messagerie
$msgFolders    = dbGetMessageFolders($db, $meId);
$activeFolderId = normalizeText($_GET['folder'] ?? '');
$activeFolder   = $activeFolderId !== '' ? dbGetMessageFolder($db, $activeFolderId, $meId) : null;
$folderMessages = ($activeTab === 'dossiers' && $activeFolderId !== '') ? dbGetFolderMessages($db, $meId, $activeFolderId) : [];
$folderBreadcrumb = ($activeFolderId !== '') ? dbGetMessageFolderPath($db, $meId, $activeFolderId) : [];

// Overlay Gestion de la messagerie
$openMsgAdminOverlay = $isAdminAuthenticated && (string)($_GET['msg-panel'] ?? '') === 'open';
$activeMsgAdminTab   = 'settings';
$allMsgsSorted       = [];
$msgParticipants     = [];
if ($openMsgAdminOverlay) {
    $msgTabOpt         = (string)($_GET['msg-tab'] ?? 'settings');
    $activeMsgAdminTab = in_array($msgTabOpt, ['settings', 'messages'], true) ? $msgTabOpt : 'settings';
    $allMsgsSorted     = $messages;
    foreach ($allMsgsSorted as $m) {
        if ($m['from_id'] !== '__admin__' && $m['from_username'] !== '') $msgParticipants[$m['from_id']] = $m['from_username'];
        if ($m['to_id']   !== '__admin__' && $m['to_username']   !== '') $msgParticipants[$m['to_id']]   = $m['to_username'];
    }
    asort($msgParticipants);
}

// Filtres — exclure les messages classés dans un dossier
$inbox = array_values(array_filter($messages, fn($m) =>
    $m['to_id'] === $meId &&
    (int)($m['deleted_by_recipient'] ?? 0) === 0 &&
    ($m['recipient_folder_id'] ?? '') === ''
));
$sent  = array_values(array_filter($messages, fn($m) =>
    $m['from_id'] === $meId &&
    (int)($m['deleted_by_sender'] ?? 0) === 0 &&
    ($m['sender_folder_id'] ?? '') === ''
));
// Corbeille : messages où l'utilisateur a effectué une suppression douce (1) ou permanente en attente (2)
$trash = array_values(array_filter($messages, fn($m) =>
    ($m['to_id']   === $meId && (int)($m['deleted_by_recipient'] ?? 0) === 1) ||
    ($m['from_id'] === $meId && (int)($m['deleted_by_sender']    ?? 0) === 1)
));

// Destinataires disponibles
$recipients = [];
foreach ($users as $u) {
    if ($u['status'] === 'active' && $u['id'] !== $meId && $u['id'] !== '__admin__') {
        $recipients[] = ['id' => $u['id'], 'username' => $u['username'], 'avatar' => $u['avatar'] ?? ''];
    }
}
usort($recipients, fn($a, $b) => strcmp($a['username'], $b['username']));

$preselectedTo = normalizeText($_GET['to'] ?? '');

// Overlay compose : auto-ouvrir si ?compose=1 ou ?to=xxx
$autoOpenCompose = (string)($_GET['compose'] ?? '') === '1' || $preselectedTo !== '';

// Tous les messages (admin uniquement)
$allMessages = $isAdminAuthenticated
    ? array_values(usort($messages, fn($a, $b) => strcmp($b['created_at'], $a['created_at'])) ? $messages : $messages)
    : [];

// Helper : formatage de date
function fmtMsgDate(string $iso): string {
    $ts = @strtotime($iso);
    if (!$ts) return '';
    $now  = time();
    $diff = $now - $ts;
    if ($diff < 60)     return 'À l\'instant';
    if ($diff < 3600)   return floor($diff / 60) . ' min';
    if ($diff < 86400)  return floor($diff / 3600) . 'h';
    if ($diff < 604800) return floor($diff / 86400) . 'j';
    return date('d/m/Y', $ts);
}
?>
<?php if (!$embedMode): ?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Messages – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=36">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<link rel="stylesheet" href="assets/css/tv.css?v=9">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>
<div id="spa-page">
<?php else: ?>
<!DOCTYPE html>
<html lang="fr" data-embed="1">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Messages</title>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=36">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<script>
/* En mode embed, ajoute _panel_referer à chaque soumission de formulaire
   pour que handle-post.php redirige vers la même URL avec &embed=1. */
document.addEventListener('DOMContentLoaded', function() {
    document.addEventListener('submit', function(e) {
        var form = e.target;
        if (!form.querySelector('[name="_panel_referer"]')) {
            var inp = document.createElement('input');
            inp.type = 'hidden';
            inp.name = '_panel_referer';
            inp.value = window.location.pathname + window.location.search;
            form.appendChild(inp);
        }
    }, true);
});
</script>
</head>
<body class="embed-mode">
<div>
<?php endif; ?>
<main class="page msg-page is-dashboard"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="0">

<section class="hero msg-hero is-centered-v" aria-labelledby="msg-page-title">
<div class="hero-content is-dashboard">

<?php if ($flash !== []): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<?php if (!$msgEnabled && !$isAdminAuthenticated): ?>
<!-- Messagerie désactivée -->
<div class="msg-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><line x1="2" y1="2" x2="22" y2="22" stroke-width="2"/></svg>
    <p>La messagerie privée est actuellement désactivée.</p>
</div>
<?php else: ?>

<!-- Onglets + bouton composer -->
<div class="msg-tabs-row">
    <nav class="msg-tabs" aria-label="Sections messagerie">
        <?php foreach ($tabOptions as $key => $label): ?>
        <a class="msg-tab-btn<?php echo $activeTab === $key ? ' is-active' : ''; ?><?php echo $key === 'trash' ? ' msg-tab-btn--trash' : ''; ?>"
           href="messages.php?tab=<?php echo $key; ?><?php echo $embedParam; ?>">
            <?php if ($key === 'trash'): ?>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
            <?php endif; ?>
            <?php echo escape($label); ?>
            <?php if ($key === 'inbox'): ?>
            <?php $unread = count(array_filter($inbox, fn($m) => $m['read_at'] === null)); ?>
            <?php if ($unread > 0): ?><span class="msg-tab-badge"><?php echo $unread; ?></span><?php endif; ?>
            <?php endif; ?>
            <?php if ($key === 'trash' && !empty($trash)): ?><span class="msg-tab-badge msg-tab-badge--trash"><?php echo count($trash); ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
    </nav>
    <?php if ($msgEnabled || $isAdminAuthenticated): ?>
    <button type="button" class="msg-compose-btn" id="compose-open-btn" title="Nouveau message" aria-label="Nouveau message">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
    </button>
    <?php endif; ?>
</div>

<!-- ── Boîte de réception ─────────────────────────────────────────── -->
<?php if ($activeTab === 'inbox'): ?>

<?php if (!empty($inbox)): ?>
<div class="msg-search-bar">
    <input type="text" id="inbox-search" placeholder="Rechercher dans la boîte de réception…" aria-label="Rechercher dans la boîte de réception">
    <span id="inbox-search-count" class="msg-search-count"></span>
</div>
<?php endif; ?>

<?php if (empty($inbox)): ?>
<div class="msg-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
    <p>Votre boîte de réception est vide.</p>
</div>
<?php else: ?>
<ul class="msg-list" id="inbox-list">
<?php foreach ($inbox as $m): ?>
<li class="msg-row<?php echo $m['read_at'] === null ? ' is-unread' : ''; ?>" data-msg-id="<?php echo escapeAttribute($m['id']); ?>" data-search-from="<?php echo escapeAttribute(mb_strtolower($m['from_username'])); ?>" data-search-content="<?php echo escapeAttribute(mb_strtolower(mb_substr($m['content'], 0, 200))); ?>">
    <button type="button" class="msg-row-link" data-msg-open="<?php echo escapeAttribute($m['id']); ?>" data-msg-origin="inbox">
        <div class="msg-row-avatar" aria-hidden="true"><?php echo mb_strtoupper(mb_substr($m['from_username'], 0, 1)); ?></div>
        <div class="msg-row-body">
            <span class="msg-row-from"><span class="user-status-dot" data-status-user="<?php echo escapeAttribute($m['from_username']); ?>"></span><?php echo escape($m['from_username']); ?></span>
            <?php if (!empty($m['subject'])): ?>
            <span class="msg-row-subject"><?php echo escape($m['subject']); ?></span>
            <?php endif; ?>
            <span class="msg-row-preview"><?php echo escape(mb_substr($m['content'], 0, 80) . (mb_strlen($m['content']) > 80 ? '…' : '')); ?></span>
        </div>
        <div class="msg-row-right">
            <span class="msg-row-date"><?php echo escape(fmtMsgDate($m['created_at'])); ?></span>
            <?php if ($m['read_at'] === null): ?><span class="msg-unread-dot" aria-label="Non lu"></span><?php endif; ?>
        </div>
    </button>
    <form method="post" class="admin-inline-form msg-row-delete">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="delete_message">
        <input type="hidden" name="msg_id"       value="<?php echo escapeAttribute($m['id']); ?>">
        <input type="hidden" name="origin"       value="inbox">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <button type="submit" class="msg-row-delete-btn" data-confirm="Supprimer ce message ?" title="Supprimer">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M9 6V4h6v2"/></svg>
        </button>
    </form>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<!-- ── Messages envoyés ───────────────────────────────────────────── -->
<?php elseif ($activeTab === 'sent'): ?>

<?php if (!empty($sent)): ?>
<div class="msg-search-bar">
    <input type="text" id="sent-search" placeholder="Rechercher dans les messages envoyés…" aria-label="Rechercher dans les messages envoyés">
    <span id="sent-search-count" class="msg-search-count"></span>
</div>
<?php endif; ?>

<?php if (empty($sent)): ?>
<div class="msg-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
    <p>Vous n'avez encore envoyé aucun message.</p>
</div>
<?php else: ?>
<ul class="msg-list" id="sent-list">
<?php foreach ($sent as $m): ?>
<li class="msg-row" data-search-to="<?php echo escapeAttribute(mb_strtolower($m['to_username'])); ?>" data-search-content="<?php echo escapeAttribute(mb_strtolower(mb_substr($m['content'], 0, 200))); ?>">
    <button type="button" class="msg-row-link" data-msg-open="<?php echo escapeAttribute($m['id']); ?>" data-msg-origin="sent">
        <div class="msg-row-avatar" aria-hidden="true"><?php echo mb_strtoupper(mb_substr($m['to_username'], 0, 1)); ?></div>
        <div class="msg-row-body">
            <span class="msg-row-from">
                <span class="user-status-dot" data-status-user="<?php echo escapeAttribute($m['to_username']); ?>"></span>À&nbsp;: <?php echo escape($m['to_username']); ?>
                <?php if ($m['read_at'] !== null): ?>
                <span class="msg-read-tag">✓ Lu</span>
                <?php endif; ?>
            </span>
            <span class="msg-row-preview"><?php echo escape(mb_substr($m['content'], 0, 80) . (mb_strlen($m['content']) > 80 ? '…' : '')); ?></span>
        </div>
        <div class="msg-row-right">
            <span class="msg-row-date"><?php echo escape(fmtMsgDate($m['created_at'])); ?></span>
        </div>
    </button>
    <form method="post" class="admin-inline-form msg-row-delete">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="delete_message">
        <input type="hidden" name="msg_id"       value="<?php echo escapeAttribute($m['id']); ?>">
        <input type="hidden" name="origin"       value="sent">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <button type="submit" class="msg-row-delete-btn" data-confirm="Supprimer ce message ?" title="Supprimer">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M9 6V4h6v2"/></svg>
        </button>
    </form>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<!-- ── Corbeille ──────────────────────────────────────────────────── -->
<?php elseif ($activeTab === 'trash'): ?>

<div class="msg-trash-toolbar">
    <?php if (!empty($trash)): ?>
    <form method="post" class="admin-inline-form" style="margin:0">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="empty_trash">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <button type="submit" class="msg-empty-trash-btn"
                data-confirm="Vider la corbeille ? Cette action est irréversible.">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            Vider la corbeille
        </button>
    </form>
    <span class="msg-trash-count"><?php echo count($trash); ?> message<?php echo count($trash) > 1 ? 's' : ''; ?></span>
    <?php endif; ?>
</div>

<?php if (empty($trash)): ?>
<div class="msg-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
    <p>La corbeille est vide.</p>
</div>
<?php else: ?>
<ul class="msg-list" id="trash-list">
<?php foreach ($trash as $m): ?>
<?php $isFromMe = ($m['from_id'] === $meId); ?>
<li class="msg-row msg-row--trash" data-msg-id="<?php echo escapeAttribute($m['id']); ?>">
    <button type="button" class="msg-row-link" data-msg-open="<?php echo escapeAttribute($m['id']); ?>" data-msg-origin="trash">
        <div class="msg-row-avatar" aria-hidden="true">
            <?php echo mb_strtoupper(mb_substr($isFromMe ? $m['to_username'] : $m['from_username'], 0, 1)); ?>
        </div>
        <div class="msg-row-body">
            <span class="msg-row-from">
                <?php if ($isFromMe): ?>
                <span class="msg-sent-label">Envoyé à&nbsp;:</span> <?php echo escape($m['to_username']); ?>
                <?php else: ?>
                <?php echo escape($m['from_username']); ?>
                <?php endif; ?>
            </span>
            <span class="msg-row-preview"><?php echo escape(mb_substr($m['content'], 0, 80) . (mb_strlen($m['content']) > 80 ? '…' : '')); ?></span>
        </div>
        <div class="msg-row-right">
            <span class="msg-row-date"><?php echo escape(fmtMsgDate($m['created_at'])); ?></span>
        </div>
    </button>
    <div class="msg-row-trash-actions">
        <!-- Restaurer -->
        <form method="post" class="admin-inline-form" style="margin:0">
            <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="restore_message">
            <input type="hidden" name="msg_id"       value="<?php echo escapeAttribute($m['id']); ?>">
            <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
            <button type="submit" class="msg-trash-restore-btn" title="Restaurer">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 102.13-9.36L1 10"/></svg>
                Restaurer
            </button>
        </form>
        <!-- Supprimer définitivement -->
        <form method="post" class="admin-inline-form" style="margin:0">
            <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="perm_delete_message">
            <input type="hidden" name="msg_id"       value="<?php echo escapeAttribute($m['id']); ?>">
            <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
            <button type="submit" class="msg-row-delete-btn msg-trash-perm-btn"
                    data-confirm="Supprimer définitivement ? Cette action est irréversible." title="Supprimer définitivement">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            </button>
        </form>
    </div>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<!-- ── Dossiers ────────────────────────────────────────────────────── -->
<?php elseif ($activeTab === 'dossiers'): ?>

<?php
// Construire l'arborescence des dossiers pour le rendu
function buildFolderTree(array $folders, string $parentId = ''): array {
    $tree = [];
    foreach ($folders as $f) {
        if ($f['parent_id'] === $parentId) {
            $f['children'] = buildFolderTree($folders, $f['id']);
            $tree[] = $f;
        }
    }
    return $tree;
}
function renderFolderTree(array $tree, int $depth = 0): void {
    global $csrfToken, $embedParam, $returnUrl;
    foreach ($tree as $f): ?>
<li class="msg-folder-li">
    <div class="msg-folder-item<?php echo $depth > 0 ? ' msg-folder-item--nested' : ''; ?>">
    <a href="messages.php?tab=dossiers&folder=<?php echo urlencode($f['id']); ?><?php echo $embedParam; ?>" class="msg-folder-link">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
        <span class="msg-folder-name"><?php echo escape($f['name']); ?></span>
        <?php if (!empty($f['children'])): ?><span class="msg-folder-sub-count"><?php echo count($f['children']); ?> sous-dossier<?php echo count($f['children']) > 1 ? 's' : ''; ?></span><?php endif; ?>
    </a>
    <div class="msg-folder-actions">
        <a href="messages.php?tab=dossiers&folder=<?php echo urlencode($f['id']); ?>&action=rename<?php echo $embedParam; ?>" class="msg-folder-action-btn" title="Renommer">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </a>
        <form method="post" class="admin-inline-form" style="margin:0">
            <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="delete_msg_folder">
            <input type="hidden" name="folder_id"    value="<?php echo escapeAttribute($f['id']); ?>">
            <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
            <button type="submit" class="msg-folder-action-btn msg-folder-delete-btn"
                    data-confirm="Supprimer le dossier « <?php echo escapeAttribute($f['name']); ?> » ? Les messages seront remis dans la boîte de réception / envoyés."
                    title="Supprimer">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            </button>
        </form>
    </div>
    </div>
<?php if (!empty($f['children'])): ?>
<ul class="msg-folder-list msg-folder-list--nested">
<?php renderFolderTree($f['children'], $depth + 1); ?>
</ul>
<?php endif; ?>
</li>
<?php endforeach;
}
?>

<?php
// En-tête dossier actif : breadcrumb + créer sous-dossier
if ($activeFolderId !== '' && $activeFolder !== null):
    $renameFolderMode = normalizeText($_GET['action'] ?? '') === 'rename';
?>
<div class="msg-folder-header">
    <nav class="msg-folder-breadcrumb" aria-label="Chemin du dossier">
        <a href="messages.php?tab=dossiers<?php echo $embedParam; ?>" class="msg-folder-bc-link">Dossiers</a>
        <?php foreach ($folderBreadcrumb as $bc): ?>
        <span class="msg-folder-bc-sep">›</span>
        <a href="messages.php?tab=dossiers&folder=<?php echo urlencode($bc['id']); ?><?php echo $embedParam; ?>" class="msg-folder-bc-link"><?php echo escape($bc['name']); ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if ($renameFolderMode): ?>
    <form method="post" class="msg-folder-create-form" style="margin-top:.5rem">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="rename_msg_folder">
        <input type="hidden" name="folder_id"    value="<?php echo escapeAttribute($activeFolderId); ?>">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <input type="text" name="folder_name" class="msg-folder-input"
               value="<?php echo escapeAttribute($activeFolder['name']); ?>"
               placeholder="Nouveau nom…" maxlength="80" required autofocus>
        <button type="submit" class="msg-folder-create-btn">Renommer</button>
        <a href="messages.php?tab=dossiers&folder=<?php echo urlencode($activeFolderId); ?><?php echo $embedParam; ?>" class="msg-folder-cancel-btn">Annuler</a>
    </form>
    <?php else: ?>
    <form method="post" class="msg-folder-create-form">
        <input type="hidden" name="csrf_token"     value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action"   value="create_msg_folder">
        <input type="hidden" name="parent_folder_id" value="<?php echo escapeAttribute($activeFolderId); ?>">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <input type="text" name="folder_name" class="msg-folder-input"
               placeholder="Nouveau sous-dossier…" maxlength="80" required>
        <button type="submit" class="msg-folder-create-btn">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Créer
        </button>
    </form>
    <?php endif; ?>
</div>

<?php
// Sous-dossiers dans le dossier actif
$subFolders = array_values(array_filter($msgFolders, fn($f) => $f['parent_id'] === $activeFolderId));
if (!empty($subFolders)): ?>
<ul class="msg-folder-list msg-folder-list--sub" style="margin-bottom:.75rem">
<?php foreach ($subFolders as $sf): ?>
<li class="msg-folder-li">
    <div class="msg-folder-item">
        <a href="messages.php?tab=dossiers&folder=<?php echo urlencode($sf['id']); ?><?php echo $embedParam; ?>" class="msg-folder-link">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
            <span class="msg-folder-name"><?php echo escape($sf['name']); ?></span>
        </a>
        <div class="msg-folder-actions">
            <a href="messages.php?tab=dossiers&folder=<?php echo urlencode($sf['id']); ?>&action=rename<?php echo $embedParam; ?>" class="msg-folder-action-btn" title="Renommer">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </a>
            <form method="post" class="admin-inline-form" style="margin:0">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="delete_msg_folder">
                <input type="hidden" name="folder_id"    value="<?php echo escapeAttribute($sf['id']); ?>">
                <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
                <button type="submit" class="msg-folder-action-btn msg-folder-delete-btn"
                        data-confirm="Supprimer ce dossier ?" title="Supprimer">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                </button>
            </form>
        </div>
    </div>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<!-- Messages dans ce dossier -->
<?php if (empty($folderMessages)): ?>
<div class="msg-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
    <p>Ce dossier est vide.</p>
</div>
<?php else: ?>
<ul class="msg-list">
<?php foreach ($folderMessages as $m): ?>
<?php $isFromMe = ($m['from_id'] === $meId); ?>
<li class="msg-row" data-msg-id="<?php echo escapeAttribute($m['id']); ?>">
    <button type="button" class="msg-row-link" data-msg-open="<?php echo escapeAttribute($m['id']); ?>" data-msg-origin="folder">
        <div class="msg-row-avatar" aria-hidden="true">
            <?php echo mb_strtoupper(mb_substr($isFromMe ? $m['to_username'] : $m['from_username'], 0, 1)); ?>
        </div>
        <div class="msg-row-body">
            <span class="msg-row-from">
                <?php if ($isFromMe): ?><span class="msg-sent-label">À&nbsp;:</span> <?php echo escape($m['to_username']); ?>
                <?php else: ?><?php echo escape($m['from_username']); ?><?php endif; ?>
            </span>
            <span class="msg-row-preview"><?php echo escape(mb_substr($m['content'], 0, 80) . (mb_strlen($m['content']) > 80 ? '…' : '')); ?></span>
        </div>
        <div class="msg-row-right">
            <span class="msg-row-date"><?php echo escape(fmtMsgDate($m['created_at'])); ?></span>
        </div>
    </button>
    <form method="post" class="admin-inline-form msg-row-delete">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="move_message_to_folder">
        <input type="hidden" name="msg_id"       value="<?php echo escapeAttribute($m['id']); ?>">
        <input type="hidden" name="folder_id"    value="">
        <input type="hidden" name="origin"       value="<?php echo $isFromMe ? 'sent' : 'inbox'; ?>">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <button type="submit" class="msg-row-delete-btn" title="Retirer du dossier" data-confirm="Retirer ce message du dossier ?">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg>
        </button>
    </form>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<?php else: ?>
<!-- Vue racine des dossiers -->
<div class="msg-folder-header">
    <form method="post" class="msg-folder-create-form">
        <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
        <input type="hidden" name="admin_action" value="create_msg_folder">
        <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
        <input type="text" name="folder_name" class="msg-folder-input"
               placeholder="Nom du nouveau dossier…" maxlength="80" required>
        <button type="submit" class="msg-folder-create-btn">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Créer un dossier
        </button>
    </form>
</div>

<?php
$rootFolderTree = buildFolderTree($msgFolders, '');
if (empty($rootFolderTree)): ?>
<div class="msg-empty">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
    <p>Aucun dossier. Créez-en un pour organiser vos messages.</p>
</div>
<?php else: ?>
<ul class="msg-folder-list">
<?php renderFolderTree($rootFolderTree); ?>
</ul>
<?php endif; ?>

<?php endif; ?>

<?php endif; ?>

<?php endif; ?>

</div><!-- /hero-content -->
</section>

</main>


<!-- ══════════════════════════════════════════════════════════════
     OVERLAY NOUVEAU MESSAGE
     ══════════════════════════════════════════════════════════════ -->
<?php if (($msgEnabled || $isAdminAuthenticated) && !empty($recipients)): ?>
<div class="article-modal" id="compose-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="compose-modal-title">
    <div class="article-modal-dialog" style="max-width:560px">
        <button class="article-modal-close" type="button" id="compose-modal-close" aria-label="Fermer">&#215;</button>
        <div class="article-modal-header">
            <div class="article-modal-title-row">
                <h2 class="article-modal-title" id="compose-modal-title">Nouveau message</h2>
            </div>
        </div>
        <div class="article-modal-body">
            <form method="post" action="/messages.php" class="msg-compose-form" style="padding:0"
                  enctype="multipart/form-data">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="send_message">
                <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($_SERVER['SCRIPT_NAME'] . '?tab=sent' . $embedParam); ?>">
                <div class="admin-form-grid" style="margin-bottom:1rem">
                    <label class="admin-field admin-field-full">
                        <span>Destinataire <abbr title="obligatoire">*</abbr></span>
                        <div style="display:flex;align-items:center;gap:.5rem">
                            <select name="to_id" id="compose-to-select" required style="flex:1;min-width:0">
                                <option value="">— Choisir un destinataire —</option>
                                <?php foreach ($recipients as $r): ?>
                                <option value="<?php echo escapeAttribute($r['id']); ?>"<?php echo $preselectedTo === $r['id'] ? ' selected' : ''; ?>>
                                    <?php echo escape($r['username']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <span id="compose-recipient-avatar" style="display:none;align-items:center;justify-content:center;width:2.2rem;height:2.2rem;border-radius:50%;overflow:hidden;background:var(--accent,#6c63ff);flex-shrink:0"></span>
                        </div>
                    </label>
                    <label class="admin-field admin-field-full">
                        <span>Objet <abbr title="obligatoire">*</abbr></span>
                        <input type="text" name="msg_subject" maxlength="150" required
                               placeholder="Objet de votre message…">
                    </label>
                    <label class="admin-field admin-field-full">
                        <span>Message <abbr title="obligatoire">*</abbr></span>
                        <textarea name="msg_content" rows="5" maxlength="<?php echo $msgMaxLength; ?>" required
                                  placeholder="Votre message…"></textarea>
                        <small style="color:var(--muted);margin-top:.25rem">Maximum <?php echo $msgMaxLength; ?> caractères.</small>
                    </label>
                    <!-- Pièce jointe -->
                    <div class="admin-field admin-field-full">
                        <span>Pièce jointe <small style="color:var(--muted);font-weight:400">(optionnel, max 10 Mo)</small></span>
                        <label class="msg-attach-label" id="msg-attach-label">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>
                            <span id="msg-attach-name">Joindre un fichier</span>
                            <input type="file" name="msg_attachment" id="msg-attachment-input"
                                   style="position:absolute;opacity:0;inset:0;width:100%;cursor:pointer"
                                   accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.txt,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.7z,.mp3,.mp4,.odt,.ods,.odp,.csv,.md">
                        </label>
                        <div class="msg-attach-clear" id="msg-attach-clear" style="display:none">
                            <button type="button" id="msg-attach-remove-btn" class="msg-attach-remove">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                Retirer
                            </button>
                        </div>
                    </div>
                </div>
                <div class="admin-form-actions">
                    <button class="admin-save-button" type="submit">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        Envoyer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════════
     MODALE LECTURE DE MESSAGE
     ══════════════════════════════════════════════════════════════ -->
<div class="article-modal" id="msg-view-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="msg-view-modal-title">
    <div class="article-modal-backdrop" id="msg-view-modal-backdrop"></div>
    <div class="article-modal-dialog">
        <button class="article-modal-close" type="button" id="msg-view-modal-close" aria-label="Fermer">&#215;</button>
        <div class="article-modal-header">
            <div class="article-modal-meta">
                <span class="article-modal-date" id="msg-view-modal-date"></span>
            </div>
            <div class="article-modal-title-row">
                <div class="msg-view-modal-avatar" id="msg-view-modal-avatar" aria-hidden="true"></div>
                <div>
                    <h2 class="article-modal-title" id="msg-view-modal-title"></h2>
                    <p id="msg-view-modal-subject" style="margin:0;font-size:.82rem;color:var(--muted);font-style:italic;"></p>
                </div>
            </div>
        </div>
        <div class="article-modal-body">
            <div class="article-modal-text-col">
                <div class="article-modal-content" id="msg-view-modal-content"></div>
                <div class="msg-modal-attachment" id="msg-view-modal-attachment" style="display:none">
                    <a class="msg-attach-download" id="msg-view-modal-attach-link" href="#" target="_blank" rel="noopener">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>
                        <span id="msg-view-modal-attach-name"></span>
                        <span class="msg-attach-size" id="msg-view-modal-attach-size"></span>
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </a>
                </div>
                <div class="msg-modal-read-status" id="msg-view-modal-read-status"></div>
            </div>
        </div>

        <!-- Zone de réponse inline -->
        <div class="msg-reply-zone" id="msg-reply-zone" style="display:none">
            <form method="post" action="/messages.php" class="msg-reply-inline-form" id="msg-reply-inline-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="send_message">
                <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($_SERVER['SCRIPT_NAME'] . '?tab=sent' . $embedParam); ?>">
                <input type="hidden" name="to_id"        id="msg-reply-to-id" value="">
                <input type="hidden" name="msg_subject"  id="msg-reply-subject" value="">
                <textarea name="msg_content" id="msg-reply-content" rows="4"
                          maxlength="<?php echo max(50,(int)($siteSettings['messaging']['max_length']??3000)); ?>"
                          placeholder="Votre réponse…" required></textarea>
                <div class="msg-reply-inline-actions">
                    <button type="submit" class="msg-reply-send-btn">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                        Envoyer
                    </button>
                    <button type="button" class="msg-reply-cancel-btn" id="msg-reply-cancel">Annuler</button>
                </div>
            </form>
        </div>

        <div class="msg-view-modal-footer">
            <!-- Bouton Répondre (inbox seulement) -->
            <button type="button" class="msg-reply-btn" id="msg-view-modal-reply-btn" style="display:none">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/></svg>
                Répondre
            </button>
            <!-- Bouton Marquer non lu (inbox seulement) -->
            <button type="button" class="msg-unread-toggle-btn" id="msg-view-modal-unread-btn" style="display:none">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/></svg>
                Marquer non lu
            </button>
            <!-- Déplacer vers un dossier -->
            <?php if (!empty($msgFolders)): ?>
            <form method="post" id="msg-view-modal-move-form" class="msg-move-form" style="display:inline">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="move_message_to_folder">
                <input type="hidden" name="msg_id"       id="msg-move-msg-id"    value="">
                <input type="hidden" name="origin"       id="msg-move-origin"    value="inbox">
                <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
                <select name="folder_id" id="msg-move-folder-select" class="msg-move-select">
                    <option value="">— Déplacer vers… —</option>
                    <?php
                    function renderFolderOptions(array $folders, string $parentId = '', string $prefix = ''): void {
                        foreach ($folders as $f) {
                            if ($f['parent_id'] !== $parentId) continue;
                            echo '<option value="' . escapeAttribute($f['id']) . '">' . escape($prefix . $f['name']) . '</option>';
                            renderFolderOptions($folders, $f['id'], $prefix . $f['name'] . ' › ');
                        }
                    }
                    renderFolderOptions($msgFolders);
                    ?>
                </select>
                <button type="submit" class="msg-move-btn" id="msg-move-submit-btn">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
                </button>
            </form>
            <?php endif; ?>
            <!-- Formulaire suppression -->
            <form method="post" id="msg-view-modal-delete-form" style="display:inline">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="delete_message">
                <input type="hidden" name="msg_id"       id="msg-view-modal-id"     value="">
                <input type="hidden" name="origin"       id="msg-view-modal-origin" value="inbox">
                <input type="hidden" name="_panel_referer" value="<?php echo escapeAttribute($returnUrl); ?>">
                <button type="submit" class="msg-delete-btn" data-confirm="Supprimer ce message ?">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg>
                    Supprimer
                </button>
            </form>
        </div>
    </div>
</div>

<!-- ── Modale admin ──────────────────────────────────────────────── -->
<div class="admin-modal<?php echo $shouldAutoOpenAdminModal ? ' is-open' : ''; ?>"
     data-admin-modal aria-hidden="<?php echo $shouldAutoOpenAdminModal ? 'false' : 'true'; ?>">
    <div class="admin-modal-backdrop" data-admin-close></div>
    <div class="admin-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="admin-modal-msg-title">
        <button class="admin-modal-close" type="button" aria-label="Fermer" data-admin-close>&#215;</button>
        <div class="admin-modal-content">
            <h2 class="admin-modal-title" id="admin-modal-msg-title"><?php echo escape($adminUi['modal_title'] ?? 'Espace administrateur'); ?></h2>
            <?php if ($isAdminAuthenticated): ?>
            <p class="admin-modal-text">Session admin active.</p>
            <nav class="admin-modal-links admin-links-grid" aria-label="Boutons administrateur">
                <?php foreach ($adminLinks as $al): ?>
                <?php if (!isItemVisible($al)) { continue; } ?>
                <a class="admin-link admin-link-block admin-link-manual" href="<?php echo escape($al['url'] ?? '#'); ?>" target="_blank" rel="noopener noreferrer"><?php echo escape($al['label'] ?? ''); ?></a>
                <?php endforeach; ?>
            </nav>
            <?php else: ?>
            <p class="admin-modal-text"><?php echo escape($adminUi['help_text'] ?? ''); ?></p>
            <?php if ($isLoginLocked): ?>
            <p class="admin-auth-error" role="alert">Trop de tentatives. Réessayez dans <?php echo $loginLockSecondsRemaining; ?> seconde(s).</p>
            <?php elseif ($adminAuthError !== ''): ?>
            <p class="admin-auth-error" role="alert"><?php echo escape($adminAuthError); ?></p>
            <?php endif; ?>
            <form method="post" class="admin-password-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="login">
                <label class="visually-hidden" for="admin-password-msg">Mot de passe administrateur</label>
                <input class="admin-password-input" id="admin-password-msg" name="admin_password"
                       type="password" autocomplete="current-password"
                       placeholder="<?php echo escapeAttribute($adminUi['password_placeholder'] ?? 'Mot de passe'); ?>"
                       <?php echo $isLoginLocked ? 'disabled' : 'required'; ?>>
                <button class="admin-password-submit" type="submit" <?php echo $isLoginLocked ? 'disabled' : ''; ?>>Ouvrir les boutons admin</button>
            </form>
            <?php endif; ?>
            <?php if ($isAdminAuthenticated): ?>
            <nav class="admin-modal-links" aria-label="Pilotage du site">
                <a class="admin-link admin-link-block" href="admin.php"><?php echo escape($adminUi['dashboard_label'] ?? 'Pilotage du site'); ?></a>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
/* ── Données messages ── */
var INBOX_DATA = <?php echo json_encode(array_values(array_map(function($m) {
    return [
        'id'              => $m['id'],
        'from_id'         => $m['from_id'],
        'from_username'   => $m['from_username'],
        'subject'         => $m['subject'] ?? '',
        'content'         => $m['content'],
        'created_at'      => $m['created_at'],
        'read_at'         => $m['read_at'],
        'attachment_id'   => $m['attachment_id']   ?? '',
        'attachment_name' => $m['attachment_name'] ?? '',
        'attachment_size' => (int)($m['attachment_size'] ?? 0),
    ];
}, $inbox)), JSON_UNESCAPED_UNICODE); ?>;

var SENT_DATA = <?php echo json_encode(array_values(array_map(function($m) {
    return [
        'id'              => $m['id'],
        'to_id'           => $m['to_id'],
        'to_username'     => $m['to_username'],
        'subject'         => $m['subject'] ?? '',
        'content'         => $m['content'],
        'created_at'      => $m['created_at'],
        'read_at'         => $m['read_at'],
        'attachment_id'   => $m['attachment_id']   ?? '',
        'attachment_name' => $m['attachment_name'] ?? '',
        'attachment_size' => (int)($m['attachment_size'] ?? 0),
    ];
}, $sent)), JSON_UNESCAPED_UNICODE); ?>;

var TRASH_DATA = <?php echo json_encode(array_values(array_map(function($m) use ($meId) {
    $isFromMe = ($m['from_id'] === $meId);
    return [
        'id'              => $m['id'],
        'from_id'         => $m['from_id'],
        'from_username'   => $m['from_username'],
        'to_id'           => $m['to_id'],
        'to_username'     => $m['to_username'],
        'is_from_me'      => $isFromMe,
        'subject'         => $m['subject'] ?? '',
        'content'         => $m['content'],
        'created_at'      => $m['created_at'],
        'read_at'         => $m['read_at'],
        'attachment_id'   => $m['attachment_id']   ?? '',
        'attachment_name' => $m['attachment_name'] ?? '',
        'attachment_size' => (int)($m['attachment_size'] ?? 0),
    ];
}, $trash)), JSON_UNESCAPED_UNICODE); ?>;

var FOLDER_DATA = <?php echo json_encode(array_values(array_map(function($m) use ($meId) {
    $isFromMe = ($m['from_id'] === $meId);
    return [
        'id'              => $m['id'],
        'from_id'         => $m['from_id'],
        'from_username'   => $m['from_username'],
        'to_id'           => $m['to_id'],
        'to_username'     => $m['to_username'],
        'is_from_me'      => $isFromMe,
        'subject'         => $m['subject'] ?? '',
        'content'         => $m['content'],
        'created_at'      => $m['created_at'],
        'read_at'         => $m['read_at'],
        'attachment_id'   => $m['attachment_id']   ?? '',
        'attachment_name' => $m['attachment_name'] ?? '',
        'attachment_size' => (int)($m['attachment_size'] ?? 0),
    ];
}, $folderMessages)), JSON_UNESCAPED_UNICODE); ?>;

var CSRF_TOKEN = '<?php echo escapeAttribute($csrfToken); ?>';

/* ── Modale admin ── */
(function(){
var modal=document.querySelector('[data-admin-modal]'),opens=document.querySelectorAll('[data-admin-open]'),closes=document.querySelectorAll('[data-admin-close]'),page=document.querySelector('.page'),pwd=document.getElementById('admin-password-msg');
if(!modal||!page||!opens.length)return;
function open(){modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('has-admin-modal-open'); document.documentElement.classList.add('has-admin-modal-open');if(pwd)setTimeout(function(){pwd.focus();},40);}
function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('has-admin-modal-open'); document.documentElement.classList.remove('has-admin-modal-open');}
opens.forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();open();});});
closes.forEach(function(b){b.addEventListener('click',close);});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))close();});
if(page.getAttribute('data-admin-auto-open')==='1')open();
})();


/* ── Modale lecture de message ── */
(function(){
var modal         = document.getElementById('msg-view-modal');
var closeBtn      = document.getElementById('msg-view-modal-close');
var backdropEl    = document.getElementById('msg-view-modal-backdrop');
var titleEl       = document.getElementById('msg-view-modal-title');
var dateEl        = document.getElementById('msg-view-modal-date');
var avatarEl      = document.getElementById('msg-view-modal-avatar');
var contentEl     = document.getElementById('msg-view-modal-content');
var replyBtn      = document.getElementById('msg-view-modal-reply-btn');
var unreadBtn     = document.getElementById('msg-view-modal-unread-btn');
var msgIdEl       = document.getElementById('msg-view-modal-id');
var originEl      = document.getElementById('msg-view-modal-origin');
var replyZone     = document.getElementById('msg-reply-zone');
var readStatusEl  = document.getElementById('msg-view-modal-read-status');
var replyForm     = document.getElementById('msg-reply-inline-form');
var replyToId     = document.getElementById('msg-reply-to-id');
var replyContent  = document.getElementById('msg-reply-content');
var replyCancel   = document.getElementById('msg-reply-cancel');
if (!modal) return;

var currentMsg = null;

function fmtDate(iso) {
    var ts = new Date(iso);
    if (isNaN(ts.getTime())) return '';
    var now = Date.now();
    var diff = (now - ts.getTime()) / 1000;
    if (diff < 60)     return 'À l\'instant';
    if (diff < 3600)   return Math.floor(diff / 60) + ' min';
    if (diff < 86400)  return Math.floor(diff / 3600) + 'h';
    if (diff < 604800) return Math.floor(diff / 86400) + 'j';
    return ts.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
}

function setContent(text) {
    var tmp = document.createElement('div');
    tmp.textContent = text;
    contentEl.innerHTML = tmp.innerHTML.replace(/\n/g, '<br>');
}

function serverPost(data) {
    var fd = new FormData();
    fd.append('csrf_token', CSRF_TOKEN);
    for (var k in data) { fd.append(k, data[k]); }
    // keepalive : la requête survit à la navigation de page
    return fetch('messages.php', { method: 'POST', body: fd, keepalive: true });
}

function updateBadge(delta) {
    var navBadge = document.querySelector('.nav-msg-badge');
    var navBtn   = document.querySelector('.nav-msg-btn');
    var tabBadge = document.querySelector('.msg-tab-btn[href*="inbox"] .msg-tab-badge');
    if (navBadge) {
        var c = Math.max(0, (parseInt(navBadge.textContent, 10) || 0) + delta);
        navBadge.textContent = c;
        navBadge.style.display = c > 0 ? '' : 'none';
        if (navBtn) navBtn.classList.toggle('has-unread', c > 0);
    }
    if (tabBadge) {
        var t = Math.max(0, (parseInt(tabBadge.textContent, 10) || 0) + delta);
        if (t === 0) tabBadge.remove();
        else tabBadge.textContent = t;
    }
}

var inboxMap = {};
INBOX_DATA.forEach(function(m) { inboxMap[m.id] = m; });
var sentMap = {};
SENT_DATA.forEach(function(m) { sentMap[m.id] = m; });
var trashMap = {};
TRASH_DATA.forEach(function(m) { trashMap[m.id] = m; });
var folderMap = {};
FOLDER_DATA.forEach(function(m) { folderMap[m.id] = m; });

function openModal(msgData, origin) {
    currentMsg = msgData;
    // Réinitialiser la zone de réponse
    replyZone.style.display = 'none';
    if (replyContent) replyContent.value = '';

    var name;
    if (origin === 'inbox') {
        name = msgData.from_username;
        replyToId.value = msgData.from_id;
        replyBtn.style.display = '';
        unreadBtn.style.display = msgData.read_at ? '' : 'none';
    } else if (origin === 'trash' || origin === 'folder') {
        // Corbeille / dossier : affichage selon sens du message
        if (msgData.is_from_me) {
            name = 'À\u00a0: ' + msgData.to_username;
        } else {
            name = msgData.from_username;
        }
        replyBtn.style.display = 'none';
        unreadBtn.style.display = 'none';
    } else {
        name = 'À\u00a0: ' + msgData.to_username;
        replyBtn.style.display = 'none';
        unreadBtn.style.display = 'none';
    }
    titleEl.textContent = name;
    avatarEl.textContent = name.replace(/^À\u00a0:\u00a0/, '').charAt(0).toUpperCase();
    dateEl.textContent   = fmtDate(msgData.created_at);
    /* Afficher le sujet sous le nom */
    var subjEl = document.getElementById('msg-view-modal-subject');
    if (subjEl) subjEl.textContent = msgData.subject || '';
    /* Préfixer le sujet de réponse avec Re: */
    var replySubjEl = document.getElementById('msg-reply-subject');
    if (replySubjEl) {
        var s = msgData.subject || '';
        replySubjEl.value = s.startsWith('Re:') ? s : ('Re: ' + s);
    }
    setContent(msgData.content);
    if (readStatusEl) {
        if (origin === 'sent') {
            readStatusEl.innerHTML = msgData.read_at
                ? '<span class="msg-status-tag msg-status-read">\u2713\u2713 Lu le ' + fmtDate(msgData.read_at) + '</span>'
                : '<span class="msg-status-tag msg-status-unread">\u25cf Non lu</span>';
        } else if (origin === 'inbox') {
            readStatusEl.innerHTML = msgData.read_at
                ? '<span class="msg-status-tag msg-status-read">\u2713 Lu</span>'
                : '<span class="msg-status-tag msg-status-unread">\u25cf Non lu</span>';
        } else {
            readStatusEl.innerHTML = '';
        }
    }

    // Pièce jointe
    var attachDiv  = document.getElementById('msg-view-modal-attachment');
    var attachLink = document.getElementById('msg-view-modal-attach-link');
    var attachName = document.getElementById('msg-view-modal-attach-name');
    var attachSize = document.getElementById('msg-view-modal-attach-size');
    if (attachDiv) {
        if (msgData.attachment_id) {
            if (attachLink) attachLink.href = 'dl-fichier.php?id=' + encodeURIComponent(msgData.attachment_id);
            if (attachName) attachName.textContent = msgData.attachment_name || 'Fichier joint';
            if (attachSize && msgData.attachment_size) {
                var s = msgData.attachment_size;
                var sLabel = s < 1024 ? s + '\u00a0o' : s < 1048576 ? Math.round(s/1024) + '\u00a0Ko' : (s/1048576).toFixed(1) + '\u00a0Mo';
                attachSize.textContent = sLabel;
            } else if (attachSize) {
                attachSize.textContent = '';
            }
            attachDiv.style.display = '';
        } else {
            attachDiv.style.display = 'none';
        }
    }

    msgIdEl.value  = msgData.id;
    originEl.value = origin;

    // Synchroniser le formulaire "Déplacer vers un dossier"
    var moveMsgId  = document.getElementById('msg-move-msg-id');
    var moveOrigin = document.getElementById('msg-move-origin');
    var moveSel    = document.getElementById('msg-move-folder-select');
    if (moveMsgId) moveMsgId.value  = msgData.id;
    if (moveOrigin) moveOrigin.value = (origin === 'folder' || origin === 'trash') ? (msgData.is_from_me ? 'sent' : 'inbox') : origin;
    if (moveSel) moveSel.value = '';

    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden'; document.documentElement.style.overflow = 'hidden';
    modal.scrollTop = 0;
    closeBtn.focus();

    // Marquer comme lu automatiquement à l'ouverture (inbox uniquement)
    if (origin === 'inbox' && !msgData.read_at) {
        msgData.read_at = new Date().toISOString();
        var row = document.querySelector('[data-msg-id="' + msgData.id + '"]');
        if (row) {
            row.classList.remove('is-unread');
            var dot = row.querySelector('.msg-unread-dot');
            if (dot) dot.remove();
        }
        updateBadge(-1);
        unreadBtn.style.display = '';
        if (readStatusEl) readStatusEl.innerHTML = '<span class="msg-status-tag msg-status-read">\u2713 Lu</span>';
        serverPost({ admin_action: 'mark_message_read', msg_id: msgData.id })
            .catch(function() { window.location.reload(); });
    }
}

function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = ''; document.documentElement.style.overflow = '';
    replyZone.style.display = 'none';
    currentMsg = null;
}

// Bouton Répondre → affiche la zone de réponse inline
replyBtn.addEventListener('click', function() {
    replyZone.style.display = replyZone.style.display === 'none' ? '' : 'none';
    if (replyZone.style.display !== 'none' && replyContent) replyContent.focus();
});

// Bouton Annuler dans la zone de réponse
replyCancel.addEventListener('click', function() {
    replyZone.style.display = 'none';
    if (replyContent) replyContent.value = '';
});

// Bouton Marquer non lu
unreadBtn.addEventListener('click', function() {
    if (!currentMsg) return;
    currentMsg.read_at = null;
    var row = document.querySelector('[data-msg-id="' + currentMsg.id + '"]');
    if (row) {
        row.classList.add('is-unread');
        if (!row.querySelector('.msg-unread-dot')) {
            var dot = document.createElement('span');
            dot.className = 'msg-unread-dot';
            dot.setAttribute('aria-label', 'Non lu');
            var right = row.querySelector('.msg-row-right');
            if (right) right.appendChild(dot);
        }
    }
    updateBadge(1);
    unreadBtn.style.display = 'none';
    serverPost({ admin_action: 'mark_message_unread', msg_id: currentMsg.id })
        .catch(function() { window.location.reload(); });
    closeModal();
});

document.querySelectorAll('[data-msg-open]').forEach(function(el) {
    el.addEventListener('click', function() {
        var id     = el.getAttribute('data-msg-open');
        var origin = el.getAttribute('data-msg-origin') || 'inbox';
        var data   = origin === 'inbox' ? inboxMap[id] : (origin === 'trash' ? trashMap[id] : (origin === 'folder' ? folderMap[id] : sentMap[id]));
        if (data) openModal(data, origin);
    });
});

closeBtn.addEventListener('click', closeModal);
// Fermer en cliquant sur le fond (le backdrop CSS est display:none,
// on écoute donc directement le clic sur le conteneur modal)
modal.addEventListener('click', function(e) {
    if (e.target === modal) closeModal();
});
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
});
})();

/* ── Overlay Nouveau message ── */
(function(){
var modal    = document.getElementById('compose-modal');
var openBtn  = document.getElementById('compose-open-btn');
var closeBtn = document.getElementById('compose-modal-close');
if (!modal) return;

/* Carte id → { avatar, username } pour la miniature */
var recipientMap = <?php
    $rMap = [];
    foreach ($recipients as $r) {
        $rMap[$r['id']] = ['avatar' => $r['avatar'], 'username' => $r['username']];
    }
    echo json_encode($rMap, JSON_HEX_TAG | JSON_HEX_AMP);
?>;

function updateRecipientPreview(val) {
    var avatarEl = document.getElementById('compose-recipient-avatar');
    if (!avatarEl) return;
    if (!val || !recipientMap[val]) { avatarEl.style.display = 'none'; return; }
    var r = recipientMap[val];
    if (r.avatar) {
        avatarEl.innerHTML = '<img src="' + r.avatar + '" alt="" style="width:100%;height:100%;object-fit:cover" loading="lazy">';
    } else {
        var initiale = (r.username || '?').charAt(0).toUpperCase();
        avatarEl.innerHTML = '<span style="color:#fff;font-weight:700;font-size:1rem">' + initiale + '</span>';
    }
    avatarEl.style.display = 'inline-flex';
}

function openCompose() {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden'; document.documentElement.style.overflow = 'hidden';
    var sel = modal.querySelector('select[name="to_id"]');
    if (sel) {
        setTimeout(function(){ sel.focus(); }, 40);
        updateRecipientPreview(sel.value);
    }
}
function closeCompose() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = ''; document.documentElement.style.overflow = '';
}

if (openBtn) openBtn.addEventListener('click', openCompose);
if (closeBtn) closeBtn.addEventListener('click', closeCompose);
modal.addEventListener('click', function(e){ if (e.target === modal) closeCompose(); });
document.addEventListener('keydown', function(e){
    if (e.key === 'Escape' && modal.classList.contains('is-open')) closeCompose();
});

var toSelect = document.getElementById('compose-to-select');
if (toSelect) toSelect.addEventListener('change', function(){ updateRecipientPreview(this.value); });

// Auto-ouvrir si ?compose=1 ou ?to= présent
if (<?php echo $autoOpenCompose ? 'true' : 'false'; ?>) openCompose();
})();

/* ── Recherche / filtrage inbox ── */
(function(){
var searchInput  = document.getElementById('inbox-search');
var countEl      = document.getElementById('inbox-search-count');
var list         = document.getElementById('inbox-list');
if (!searchInput || !list) return;
searchInput.addEventListener('input', function() {
    var val  = searchInput.value.toLowerCase().trim();
    var rows = list.querySelectorAll('li.msg-row');
    var visible = 0;
    rows.forEach(function(row) {
        var from    = (row.getAttribute('data-search-from')    || '').toLowerCase();
        var content = (row.getAttribute('data-search-content') || '').toLowerCase();
        var show = !val || from.indexOf(val) !== -1 || content.indexOf(val) !== -1;
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    if (countEl) {
        countEl.textContent = val ? visible + ' résultat' + (visible !== 1 ? 's' : '') : '';
    }
});
})();

/* ── Recherche / filtrage messages envoyés ── */
(function(){
var searchInput  = document.getElementById('sent-search');
var countEl      = document.getElementById('sent-search-count');
var list         = document.getElementById('sent-list');
if (!searchInput || !list) return;
searchInput.addEventListener('input', function() {
    var val  = searchInput.value.toLowerCase().trim();
    var rows = list.querySelectorAll('li.msg-row');
    var visible = 0;
    rows.forEach(function(row) {
        var to      = (row.getAttribute('data-search-to')      || '').toLowerCase();
        var content = (row.getAttribute('data-search-content') || '').toLowerCase();
        var show = !val || to.indexOf(val) !== -1 || content.indexOf(val) !== -1;
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    if (countEl) {
        countEl.textContent = val ? visible + ' résultat' + (visible !== 1 ? 's' : '') : '';
    }
});
})();

/* ── Pièce jointe dans le formulaire de composition ── */
(function(){
var fileInput  = document.getElementById('msg-attachment-input');
var nameEl     = document.getElementById('msg-attach-name');
var clearDiv   = document.getElementById('msg-attach-clear');
var removeBtn  = document.getElementById('msg-attach-remove-btn');
if (!fileInput) return;
fileInput.addEventListener('change', function() {
    var f = fileInput.files && fileInput.files[0];
    if (f) {
        if (nameEl) nameEl.textContent = f.name;
        if (clearDiv) clearDiv.style.display = '';
    } else {
        if (nameEl) nameEl.textContent = 'Joindre un fichier';
        if (clearDiv) clearDiv.style.display = 'none';
    }
});
if (removeBtn) {
    removeBtn.addEventListener('click', function() {
        fileInput.value = '';
        if (nameEl) nameEl.textContent = 'Joindre un fichier';
        if (clearDiv) clearDiv.style.display = 'none';
    });
}

// Height Sync
if (window.parent && window.parent !== window) {
    var sendH = function() {
        // En mode embed, on mesure la hauteur réelle du contenu principal
        // body.scrollHeight peut être influencé par la hauteur actuelle de l'iframe (100vh)
        // On utilise main.offsetHeight pour la hauteur "réelle"
        var main = document.querySelector('main');
        var h = main ? main.offsetHeight : document.body.offsetHeight;
        window.parent.postMessage({ type: 'resize_iframe', id: 'msg-overlay-frame', height: h }, '*');
    };
    if (window.ResizeObserver) {
        new ResizeObserver(sendH).observe(document.body);
    }
    window.addEventListener('load', sendH);
    setInterval(sendH, 400);
}
})();

</script>
<?php if (!$embedMode): ?>
</div><!-- #spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
<?php else: ?>
</div>
<?php endif; ?>
</body>
</html>
