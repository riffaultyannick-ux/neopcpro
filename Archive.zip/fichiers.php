<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

if (!$isUserAuthenticated) {
    header('Location: /index.php?show_login=1');
    exit;
}

if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php');
    exit;
}

$flash = getFlash();

// Données du gestionnaire de fichiers (calculées ici pour que le volet
// soit rendu hors du .hero qui applique backdrop-filter)
function fmFormatSize(int $bytes): string {
    if ($bytes < 1024)         return $bytes . ' o';
    if ($bytes < 1048576)      return round($bytes/1024, 1) . ' Ko';
    if ($bytes < 1073741824)   return round($bytes/1048576, 1) . ' Mo';
    return round($bytes/1073741824, 1) . ' Go';
}
$fmUsage      = fmGetUserStorageUsage($db, $currentUserId);
$fmInitPct    = $fmStorageQuotaBytes > 0 ? min(100, round($fmUsage / $fmStorageQuotaBytes * 100)) : 0;
$fmQuotaColor = $fmInitPct >= 90 ? '#ef4444' : ($fmInitPct >= 70 ? '#f59e0b' : 'var(--primary)');
$fmActiveUsers = array_values(array_filter($users, fn($u) =>
    $u['status'] === 'active' && $u['id'] !== $currentUserId
));

$ogTitle = 'Fichiers – ' . ($siteSettings['site_name'] ?? 'NéoPcPro');
$ogDesc  = 'Gérez et partagez vos fichiers personnels.';
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/fichiers.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $ogDesc; ?>">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="<?php echo escape($ogTitle); ?>">
<meta property="og:description" content="<?php echo $ogDesc; ?>">
<meta property="og:site_name"   content="<?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?>">
<title>Fichiers – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/fichiers.css?v=12">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<link rel="stylesheet" href="assets/css/tv.css?v=9">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body class="has-fm-sidebar">
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<div id="spa-page">
<!-- Volet arborescence : rendu hors de .hero pour éviter que backdrop-filter
     n'intercepte position:fixed et empêche le volet d'occuper toute la hauteur -->
<div class="fm-sidebar-backdrop" id="fm-sidebar-backdrop"></div>
<aside class="fm-tree-sidebar" id="fm-tree-sidebar" aria-label="Arborescence des dossiers">
  <div class="fm-tree-panel-header">
    <span class="fm-tree-panel-title">Mes dossiers</span>
    <button class="fm-sidebar-close-btn" id="fm-sidebar-close" type="button" aria-label="Fermer">&#215;</button>
  </div>
  <div class="fm-sidebar-tree" id="fm-tree"></div>
<div class="fm-quota-block">
    <div class="fm-quota-labels">
      <span id="fm-quota-used"><?php echo fmFormatSize($fmUsage); ?></span>
      <span>/ <?php echo fmFormatSize($fmStorageQuotaBytes); ?></span>
    </div>
    <div class="fm-quota-bar">
      <div class="fm-quota-bar-fill" id="fm-quota-fill"
           style="width:<?php echo $fmInitPct; ?>%;background:<?php echo $fmQuotaColor; ?>;"></div>
    </div>
    <div class="fm-quota-pct" id="fm-quota-pct"><?php echo $fmInitPct; ?>%</div>
  </div>
  <div class="fm-resize-handle" aria-hidden="true"></div>
</aside>

<main class="page is-dashboard">


<section class="hero is-centered-v">
<div class="hero-content is-dashboard">
<?php require __DIR__ . '/includes/fichiers-panel.php'; ?>
</div>
</section>
</main>


</div><!-- #spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
</body>
</html>
