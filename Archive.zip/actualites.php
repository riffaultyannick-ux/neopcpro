<?php
define('NEOPCPRO_LOADED', true);
require __DIR__ . '/includes/config.php';
require __DIR__ . '/includes/handle-post.php';

// Réservé aux membres : rediriger les visiteurs non connectés
if (!$isUserAuthenticated && !$isAdminAuthenticated) {
    header('Location: /index.php?show_login=1');
    exit;
}

// Maintenance : bloquer les membres non-admin déjà connectés
if ($maintenanceEnabled && !$isAdminAuthenticated) {
    header('Location: /index.php');
    exit;
}

if ($isAdminAuthenticated && (string)($_GET['admin'] ?? '') === '1') {
    $shouldAutoOpenAdminModal = true;
}
$flash               = getFlash();
$autoOpenArticleId   = isset($_GET['open_article']) ? normalizeText($_GET['open_article']) : '';

// Tri : épinglés d'abord, puis par date décroissante
usort($newsArticles, function($a, $b) {
    $pa = (int)($a['pinned'] ?? 0);
    $pb = (int)($b['pinned'] ?? 0);
    if ($pa !== $pb) return $pb - $pa;
    return strcmp($b['date'] ?? '', $a['date'] ?? '');
});

$publicArticles = $isAdminAuthenticated
    ? $newsArticles
    : array_values(array_filter($newsArticles, fn($a) => (int)($a['visible'] ?? 0) === 1));

// Collecte des catégories et groupement par catégorie
$filterCategories = [];
foreach ($publicArticles as $article) {
    $cat = trim($article['category'] ?? '');
    if ($cat !== '' && !in_array($cat, $filterCategories, true)) {
        $filterCategories[] = $cat;
    }
}
sort($filterCategories);

// Groupement par catégorie (ordre préservé : épinglés d'abord dans chaque groupe)
$groupedArticles = [];
foreach ($publicArticles as $article) {
    $cat = trim($article['category'] ?? '') !== '' ? trim($article['category']) : 'Non classé';
    $groupedArticles[$cat][] = $article;
}

$ogTitle = 'Actualités – NéoPcPro';
$ogDesc  = escape('Les dernières nouvelles du serveur NéoPcPro.');
$proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$ogUrl   = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="<?php echo $ogDesc; ?>">
<meta name="robots" content="index, follow">
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?php echo escape($ogUrl); ?>">
<meta property="og:title"       content="<?php echo escape($ogTitle); ?>">
<meta property="og:description" content="<?php echo $ogDesc; ?>">
<meta property="og:site_name"   content="NéoPcPro">
<title>Actualités – <?php echo escape($siteSettings['site_name'] ?? 'NéoPcPro'); ?></title>
<?php if (!empty($siteSettings['favicon'])): ?><link rel="icon" href="<?php echo escapeAttribute($siteSettings['favicon']); ?>"><?php endif; ?>
<script>try{var _t=localStorage.getItem('site-theme');if(_t==='dark')document.documentElement.setAttribute('data-theme','dark');}catch(e){}</script>
<link rel="stylesheet" href="assets/css/style.css?v=43">
<link rel="stylesheet" href="assets/css/pages.css?v=35">
<link rel="stylesheet" href="assets/css/chat.css?v=39">
<link rel="stylesheet" href="assets/css/radio.css?v=3">
<link rel="stylesheet" href="assets/css/tv.css?v=9">
<?php if (!empty($siteSettings['bg_image'])): ?><style>:root{--background-image:url('<?php echo escapeAttribute($siteSettings['bg_image']); ?>')}</style><?php endif; ?>
<?php require __DIR__ . '/includes/head-bg.php'; ?>
</head>
<body>
<div class="background-layer" aria-hidden="true"></div>
<?php require __DIR__ . '/includes/nav.php'; ?>
<?php require __DIR__ . '/includes/chat-sidebar.php'; ?>

<div id="spa-page">
<main class="page is-dashboard"
      data-admin-authenticated="<?php echo $isAdminAuthenticated ? '1' : '0'; ?>"
      data-admin-auto-open="<?php echo $shouldAutoOpenAdminModal ? '1' : '0'; ?>">

<!-- ── En-tête de page ────────────────────────────────────────── -->
<section class="hero is-centered-v" aria-labelledby="news-page-title">
<div class="hero-content is-dashboard">

<?php if ($flash !== [] && $autoOpenArticleId === ''): ?>
<div class="site-flash site-flash-<?php echo escape($flash['type'] ?? 'success'); ?>" role="status">
    <?php echo escape($flash['message'] ?? ''); ?>
</div>
<?php endif; ?>

<?php if (isset($_GET['need_login']) && !$isUserAuthenticated && !$isAdminAuthenticated): ?>
<div class="site-flash site-flash-info" role="status">
    <?php echo escape($userConfig['login_message'] ?? 'Vous devez être connecté pour accéder à ce site.'); ?>
    <button type="button" data-user-login-open style="margin-left:1rem;padding:0.4rem 0.9rem;border-radius:8px;border:1px solid rgba(56,189,248,0.35);background:rgba(56,189,248,0.12);color:var(--primary);font-weight:600;cursor:pointer;">
        Se connecter
    </button>
</div>
<?php endif; ?>

<div class="dl-page-header">
    <div class="dl-page-header-text">
        <p class="dl-page-subtitle"><?php echo escape($siteSettings['news_page']['subtitle'] ?? 'Les dernières nouvelles du serveur NéoPcPro.'); ?></p>
    </div>
    <?php if ($isAdminAuthenticated): ?>
    <a href="news-admin.php?mode=add-only" class="card-admin-btn card-admin-btn-edit" style="align-self:flex-start">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Ajouter
    </a>
    <?php endif; ?>
</div>

<!-- ── Filtres par catégorie ──────────────────────────────────── -->
<?php if (!empty($publicArticles) && count($filterCategories) > 0): ?>
<div class="dl-filters" id="news-filter-bar" role="group" aria-label="Filtrer par catégorie">
    <button class="dl-filter-btn is-active" data-news-cat="" type="button">
        <span class="dl-filter-icon" aria-hidden="true">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
        </span>
        Toutes les catégories
    </button>
    <?php foreach ($filterCategories as $cat): ?>
    <button class="dl-filter-btn" data-news-cat="<?php echo escapeAttribute($cat); ?>" type="button">
        <?php echo escape($cat); ?>
    </button>
    <?php endforeach; ?>
    <?php if (isset($groupedArticles['Non classé'])): ?>
    <button class="dl-filter-btn" data-news-cat="Non classé" type="button">Non classé</button>
    <?php endif; ?>
    <input type="text" id="news-filter-search" class="news-filter-search news-filter-search--inline"
           placeholder="Rechercher un article…" aria-label="Rechercher par titre ou résumé">
</div>
<?php endif; ?>

<!-- ── Articles groupés par catégorie ───────────────────────── -->
<?php if (empty($publicArticles)): ?>
<div class="news-empty">
    <p>Aucune actualité pour le moment. Revenez bientôt !</p>
</div>
<?php else: ?>

<?php
// Fonction d'affichage d'une carte article (réutilisée dans chaque section)
function renderNewsCard(array $article): void {
    global $isAdminAuthenticated, $csrfToken;
    $isHidden   = (int)($article['visible'] ?? 0) === 0;
    $hasContent = !empty(trim($article['content'] ?? ''));
    $cat        = trim($article['category'] ?? '');
    $titleLower = mb_strtolower($article['title'] ?? '');
    $summLower  = mb_strtolower($article['summary'] ?? '');
    ?>
<article class="news-card<?php echo $isHidden ? ' is-hidden-article' : ''; ?><?php echo (int)($article['pinned'] ?? 0) ? ' is-pinned' : ''; ?>"
         data-news-card
         data-news-cat="<?php echo escapeAttribute($cat); ?>"
         data-news-title="<?php echo escapeAttribute($titleLower); ?>"
         data-news-summary="<?php echo escapeAttribute($summLower); ?>">
    <div class="news-card-thumb">
        <?php if (!empty($article['image'])): ?>
        <img class="news-card-img" src="<?php echo escape($article['image']); ?>" alt="" loading="lazy">
        <?php else: ?>
        <div class="news-card-no-img" aria-hidden="true">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
        </div>
        <?php endif; ?>
    </div>
    <div class="news-card-header">
        <div class="news-card-meta-row">
            <time class="news-card-date" datetime="<?php echo escape($article['date'] ?? ''); ?>">
                <?php $ts = strtotime($article['date'] ?? ''); echo $ts ? date('j F Y', $ts) : escape($article['date'] ?? ''); ?>
            </time>
            <?php if ($cat !== ''): ?>
            <span class="news-card-cat-badge"><?php echo escape($cat); ?></span>
            <?php endif; ?>
            <?php if ((int)($article['pinned'] ?? 0)): ?>
            <span class="news-pinned-badge">📌 Épinglé</span>
            <?php endif; ?>
            <?php if ($isHidden): ?>
            <span class="dl-admin-badge dl-admin-badge-hidden">🙈 Masqué</span>
            <?php endif; ?>
        </div>
        <h2 class="news-card-title"><?php echo escape($article['title'] ?? ''); ?></h2>
    </div>
    <?php if (!empty($article['summary'])): ?>
    <p class="news-card-summary"><?php echo escape($article['summary']); ?></p>
    <?php endif; ?>
    <?php if ($hasContent || !empty($article['summary'])): ?>
    <button class="news-card-toggle" type="button"
            data-open-article="<?php echo escapeAttribute($article['id']); ?>"
            aria-label="Lire l'article : <?php echo escapeAttribute($article['title'] ?? ''); ?>">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="5 12 12 5 19 12"/><polyline points="5 19 12 12 19 19"/></svg>
        Lire la suite
    </button>
    <?php endif; ?>
    <?php if ($isAdminAuthenticated): ?>
    <div class="card-admin-actions">
        <a class="card-admin-btn card-admin-btn-edit"
           href="news-admin.php?edit=<?php echo escapeAttribute($article['id']); ?>&mode=edit-only">
            ✏ Modifier
        </a>
        <form class="card-admin-delete-form" method="post" action="news-admin.php"
              data-confirm="Supprimer définitivement cet article ?">
            <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="delete_news_article">
            <input type="hidden" name="news_id"      value="<?php echo escapeAttribute($article['id']); ?>">
            <input type="hidden" name="return_url"   value="actualites.php">
            <button type="submit" class="card-admin-btn card-admin-btn-delete">🗑 Supprimer</button>
        </form>
    </div>
    <?php endif; ?>
</article>
    <?php
}
?>

<?php foreach ($groupedArticles as $catName => $catArticles): ?>
<div class="dl-section" data-news-section="<?php echo escapeAttribute($catName); ?>">
    <h2 class="dl-section-title"><?php echo escape($catName); ?></h2>
    <div class="news-flat-grid">
        <?php foreach ($catArticles as $article): renderNewsCard($article); endforeach; ?>
    </div>
</div>
<?php endforeach; ?>

<p class="news-empty news-no-results" id="news-no-results" style="display:none;">Aucun article ne correspond à votre recherche.</p>
<?php endif; ?>


<?php
// Données JSON pour le JS de la modale
$articlesJson = json_encode(array_map(function($a) use ($comments, $isAdminAuthenticated, $currentUserId) {
    $ts = @strtotime($a['date'] ?? '');
    
    // Récupérer les commentaires pour cet article
    $articleComments = getCommentsForArticle($a['id'], $comments, $isAdminAuthenticated, $currentUserId);
    $commentsData = array_map(function($c) {
        return [
            'id'         => $c['id'],
            'user_id'    => $c['user_id'],
            'username'   => $c['username'],
            'content'    => $c['content'],
            'status'     => $c['status'],
            'created_at' => $c['created_at'],
        ];
    }, $articleComments);
    
    return [
        'id'       => $a['id'],
        'title'    => $a['title'] ?? '',
        'category' => $a['category'] ?? '',
        'date'     => $ts ? date('j F Y', $ts) : ($a['date'] ?? ''),
        'summary'  => $a['summary'] ?? '',
        'content'  => $a['content'] ?? '',
        'image'    => $a['image'] ?? '',
        'video'    => $a['video'] ?? '',
        'pinned'   => (int)($a['pinned'] ?? 0),
        'comments' => $commentsData,
    ];
}, $publicArticles), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT);
?>
<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">var ARTICLES_DATA = <?php echo $articlesJson; ?>;
var AUTO_OPEN_ARTICLE  = <?php echo json_encode($autoOpenArticleId); ?>;
var COMMENT_FLASH      = <?php echo json_encode($autoOpenArticleId !== '' && $flash !== [] ? $flash : null); ?>;
var CURRENT_USER_ID    = <?php echo json_encode($currentUserId ?? ''); ?>;
var IS_ADMIN           = <?php echo $isAdminAuthenticated ? 'true' : 'false'; ?>;
</script>

</div>
</section>

</main>


<!-- ── Modale article ─────────────────────────────────────────── -->
<div class="article-modal" id="article-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="article-modal-title">
    <div class="article-modal-backdrop" id="article-modal-backdrop"></div>
    <div class="article-modal-dialog">
        <button class="article-modal-close" type="button" id="article-modal-close" aria-label="Fermer">&#215;</button>
        <div class="article-modal-header">
            <div class="article-modal-meta">
                <span class="article-modal-date" id="article-modal-date"></span>
                <span id="article-modal-pinned" style="display:none" class="news-pinned-badge">📌 Épinglé</span>
            </div>
            <div class="article-modal-title-row">
                <img class="article-modal-img" id="article-modal-img" src="" alt="" style="display:none">
                <h2 class="article-modal-title" id="article-modal-title"></h2>
            </div>
        </div>
        <div class="article-modal-body">
            <div class="article-modal-media-row">
                <div class="article-modal-video-wrap" id="article-modal-video-wrap" style="display:none">
                    <!-- iframe pour YouTube/Vimeo, injecté par JS -->
                </div>
                <div class="article-modal-text-col">
                    <p class="article-modal-summary" id="article-modal-summary" style="display:none"></p>
                    <div class="article-modal-content" id="article-modal-content"></div>
                </div>
            </div>

            <!-- Section Commentaires -->
            <div class="article-comments-section" id="article-modal-comments">
                <div id="modal-comment-flash"></div>
                <!-- Formulaire ajout commentaire -->
                <?php if ($isAdminAuthenticated): ?>
                <div class="comment-form-wrapper">
                    <h3 class="comments-title">Ajouter un commentaire <small style="font-weight:400;color:#94a3b8;">(Administrateur — publié immédiatement)</small></h3>
                    <form method="POST" class="comment-add-form" id="comment-add-form-admin">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="admin_add_comment">
                        <input type="hidden" name="article_id" id="comment-article-id-admin" value="">
                        <textarea
                            name="comment_content"
                            placeholder="Votre commentaire en tant qu'administrateur..."
                            maxlength="2000"
                            required
                            rows="4"
                        ></textarea>
                        <div class="comment-form-footer">
                            <small>Maximum 2000 caractères. Publié immédiatement, visible de tous.</small>
                            <button type="submit" class="comment-submit-btn">Publier</button>
                        </div>
                    </form>
                </div>
                <?php elseif ($isUserAuthenticated): ?>
                <div class="comment-form-wrapper">
                    <h3 class="comments-title">Ajouter un commentaire</h3>
                    <form method="POST" class="comment-add-form" id="comment-add-form">
                        <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
                        <input type="hidden" name="admin_action" value="add_comment">
                        <input type="hidden" name="article_id" id="comment-article-id" value="">

                        <textarea
                            name="comment_content"
                            placeholder="Votre commentaire..."
                            maxlength="2000"
                            required
                            rows="4"
                        ></textarea>
                        <div class="comment-form-footer">
                            <small>Maximum 2000 caractères. Votre commentaire sera modéré avant publication.</small>
                            <button type="submit" class="comment-submit-btn">Publier</button>
                        </div>
                    </form>
                </div>
                <?php else: ?>
                <div class="comment-login-prompt">
                    <p>Connectez-vous pour commenter.</p>
                    <button type="button" data-user-login-open class="comment-login-btn">Se connecter</button>
                </div>
                <?php endif; ?>

                <!-- Formulaires cachés : suppression / modification de commentaire (membres et admin) -->
                <?php if ($isUserAuthenticated || $isAdminAuthenticated): ?>
                <form method="POST" id="comment-delete-form" style="display:none">
                    <input type="hidden" name="csrf_token"    value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action"  value="delete_own_comment">
                    <input type="hidden" name="comment_id"    id="delete-comment-id"  value="">
                    <input type="hidden" name="open_article"  id="delete-article-id"  value="">
                </form>
                <form method="POST" id="comment-edit-form" style="display:none">
                    <input type="hidden" name="csrf_token"     value="<?php echo escapeAttribute($csrfToken); ?>">
                    <input type="hidden" name="admin_action"   value="edit_own_comment">
                    <input type="hidden" name="comment_id"     id="edit-comment-id"      value="">
                    <input type="hidden" name="comment_content" id="edit-comment-content" value="">
                    <input type="hidden" name="open_article"   id="edit-article-id"      value="">
                </form>
                <?php endif; ?>

                <!-- Liste des commentaires -->
                <div class="comments-list-wrapper">
                    <h3 class="comments-title">Commentaires <span id="comments-count">0</span></h3>
                    <div id="comments-list"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ── Modale admin ──────────────────────────────────────────────── -->
<div class="admin-modal<?php echo $shouldAutoOpenAdminModal ? ' is-open' : ''; ?>"
     data-admin-modal aria-hidden="<?php echo $shouldAutoOpenAdminModal ? 'false' : 'true'; ?>">
    <div class="admin-modal-backdrop" data-admin-close></div>
    <div class="admin-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="admin-modal-title2">
        <button class="admin-modal-close" type="button" aria-label="Fermer" data-admin-close>&#215;</button>
        <div class="admin-modal-content">
            <h2 class="admin-modal-title" id="admin-modal-title2"><?php echo escape($adminUi['modal_title'] ?? 'Espace administrateur'); ?></h2>
            <?php if ($isAdminAuthenticated): ?>
            <p class="admin-modal-text">Session admin active.</p>
            <nav class="admin-modal-links admin-links-grid" aria-label="Boutons administrateur">
                <?php foreach ($adminLinks as $al): ?>
                <?php if (!isItemVisible($al)) { continue; } ?>
                <a class="admin-link admin-link-block admin-link-manual" href="<?php echo escape($al['url'] ?? '#'); ?>" target="_blank" rel="noopener noreferrer"><?php echo escape($al['label'] ?? ''); ?></a>
                <?php endforeach; ?>
                <a class="admin-link admin-link-block" href="news-admin.php" id="news-admin-link">Gérer les actualités<?php if ($pendingCommentsCount > 0): ?><span class="notification-badge notification-badge--green" id="news-admin-badge" aria-label="<?php echo $pendingCommentsCount; ?> commentaire(s) en attente"><?php echo $pendingCommentsCount; ?></span><?php endif; ?></a>
            </nav>
            <?php else: ?>
            <p class="admin-modal-text"><?php echo escape($adminUi['help_text'] ?? ''); ?></p>
            <?php if ($isLoginLocked): ?>
            <p class="admin-auth-error" role="alert">Trop de tentatives. Réessayez dans <?php echo $loginLockSecondsRemaining; ?> seconde(s).</p>
            <?php elseif ($adminAuthError !== ''): ?>
            <p class="admin-auth-error" role="alert"><?php echo escape($adminAuthError); ?></p>
            <?php endif; ?>
            <form method="post" class="admin-password-form">
                <input type="hidden" name="csrf_token"   value="<?php echo escapeAttribute($csrfToken); ?>">
                <input type="hidden" name="admin_action" value="login">
                <label class="visually-hidden" for="admin-password2">Mot de passe administrateur</label>
                <input class="admin-password-input" id="admin-password2" name="admin_password"
                       type="password" autocomplete="current-password"
                       placeholder="<?php echo escapeAttribute($adminUi['password_placeholder'] ?? 'Mot de passe'); ?>"
                       <?php echo $isLoginLocked ? 'disabled' : 'required'; ?>>
                <button class="admin-password-submit" type="submit" <?php echo $isLoginLocked ? 'disabled' : ''; ?>>Ouvrir les boutons admin</button>
            </form>
            <?php endif; ?>
            <?php if ($isAdminAuthenticated): ?>
            <nav class="admin-modal-links" aria-label="Pilotage du site">
                <a class="admin-link admin-link-block" href="admin.php"><?php echo escape($adminUi['dashboard_label'] ?? 'Pilotage du site'); ?></a>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
(function(){
var modal=document.querySelector('[data-admin-modal]'),opens=document.querySelectorAll('[data-admin-open]'),closes=document.querySelectorAll('[data-admin-close]'),page=document.querySelector('.page'),pwd=document.getElementById('admin-password2');
if(!modal||!page||!opens.length)return;
function open(){modal.classList.add('is-open');modal.setAttribute('aria-hidden','false');document.body.classList.add('has-admin-modal-open'); document.documentElement.classList.add('has-admin-modal-open');if(pwd)setTimeout(function(){pwd.focus();},40);}
function close(){modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');document.body.classList.remove('has-admin-modal-open'); document.documentElement.classList.remove('has-admin-modal-open');}
opens.forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();open();});});
closes.forEach(function(b){b.addEventListener('click',close);});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&modal.classList.contains('is-open'))close();});
if(page.getAttribute('data-admin-auto-open')==='1')open();
})();


(function(){
/* ── Filtrage des articles ── */
var filterBtns  = document.querySelectorAll('.dl-filter-btn[data-news-cat]');
var sections    = document.querySelectorAll('.dl-section[data-news-section]');
var searchInput = document.getElementById('news-filter-search');
var noResults   = document.getElementById('news-no-results');
var activeCat   = '';

function applyNewsFilter() {
    var q = searchInput ? searchInput.value.toLowerCase().trim() : '';
    var total = 0, visible = 0;
    sections.forEach(function(sec) {
        var secCat = sec.getAttribute('data-news-section');
        var catMatch = !activeCat || secCat === activeCat;
        var cards = sec.querySelectorAll('[data-news-card]');
        var visibleCards = 0;
        cards.forEach(function(card) {
            total++;
            var matchSearch = !q
                || (card.getAttribute('data-news-title')   || '').indexOf(q) !== -1
                || (card.getAttribute('data-news-summary') || '').indexOf(q) !== -1;
            var show = catMatch && matchSearch;
            card.style.display = show ? '' : 'none';
            if (show) { visibleCards++; visible++; }
        });
        sec.style.display = (catMatch && (!q || visibleCards > 0)) ? '' : 'none';
    });
    if (noResults) noResults.style.display = visible === 0 ? '' : 'none';
}

filterBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
        filterBtns.forEach(function(b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        activeCat = btn.getAttribute('data-news-cat');
        applyNewsFilter();
    });
});
if (searchInput) searchInput.addEventListener('input', applyNewsFilter);
})();

(function(){
/* ── Modale article ── */
var modal     = document.getElementById('article-modal');
var backdrop  = document.getElementById('article-modal-backdrop');
var closeBtn  = document.getElementById('article-modal-close');
var imgEl     = document.getElementById('article-modal-img');
var dateEl    = document.getElementById('article-modal-date');
var pinnedEl  = document.getElementById('article-modal-pinned');
var titleEl   = document.getElementById('article-modal-title');
var summaryEl = document.getElementById('article-modal-summary');
var videoWrap = document.getElementById('article-modal-video-wrap');
var contentEl = document.getElementById('article-modal-content');
var modalBody = modal ? modal.querySelector('.article-modal-body') : null;
if (!modal) return;

// Fonction pour échapper le HTML
function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

var articlesMap = {};
if (typeof ARTICLES_DATA !== 'undefined') {
    ARTICLES_DATA.forEach(function(a){ articlesMap[a.id] = a; });
}

function buildVideoEmbed(url) {
    if (!url) return '';
    // YouTube — façade click-to-play pour éviter le blocage bot
    var yt = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([\w-]{11})/);
    if (yt) {
        var ytId = yt[1];
        return '<iframe src="https://www.youtube-nocookie.com/embed/' + ytId + '?rel=0" allowfullscreen title="Vidéo YouTube" class="article-modal-iframe" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin"></iframe>';
    }
    // Vimeo
    var vi = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    if (vi) return '<iframe src="https://player.vimeo.com/video/' + vi[1] + '" allowfullscreen title="Vidéo Vimeo" class="article-modal-iframe"></iframe>';
    // Fichier vidéo direct
    if (/\.mp4|webm|ogg/i.test(url)) {
        return '<video controls class="article-modal-video"><source src="' + url + '"><p>Votre navigateur ne supporte pas la lecture vidéo.</p></video>';
    }
    return '';
}

function openModal(id) {
    var a = articlesMap[id];
    if (!a) return;
    // Image
    if (a.image) { imgEl.src = a.image; imgEl.style.display = 'block'; }
    else         { imgEl.style.display = 'none'; imgEl.src = ''; }
    // Meta
    dateEl.textContent = a.date;
    titleEl.textContent = a.title;
    if (pinnedEl) pinnedEl.style.display = a.pinned ? 'inline-flex' : 'none';
    // Summary
    if (a.summary) { summaryEl.textContent = a.summary; summaryEl.style.display = 'block'; }
    else           { summaryEl.style.display = 'none'; }
    // Video
    if (videoWrap) {
        var embed = buildVideoEmbed(a.video || '');
        if (embed) { videoWrap.innerHTML = embed; videoWrap.style.display = 'block'; if (modalBody) modalBody.classList.add('has-video'); }
        else       { videoWrap.innerHTML = ''; videoWrap.style.display = 'none'; if (modalBody) modalBody.classList.remove('has-video'); }
    }
    // Content
    contentEl.innerHTML = a.content ? a.content.replace(/\n/g,'<br>') : '';
    
    // Commentaires
    var commentsListEl = document.getElementById('comments-list');
    var commentsCountEl = document.getElementById('comments-count');
    var commentArticleIdInput = document.getElementById('comment-article-id');
    
    // Mettre à jour l'ID de l'article dans le formulaire
    if (commentArticleIdInput) {
        commentArticleIdInput.value = a.id;
    }
    var commentArticleIdAdmin = document.getElementById('comment-article-id-admin');
    if (commentArticleIdAdmin) {
        commentArticleIdAdmin.value = a.id;
    }
    
    // Afficher les commentaires
    if (commentsListEl && commentsCountEl) {
        var comments = a.comments || [];
        commentsCountEl.textContent = '(' + comments.length + ')';
        
        if (comments.length === 0) {
            commentsListEl.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:2rem 0;">Aucun commentaire pour le moment. Soyez le premier à commenter !</p>';
        } else {
            var html = '';
            comments.forEach(function(c) {
                var statusBadge = '';
                var commentClass = 'comment-item';
                
                if (c.status === 'pending') {
                    statusBadge = '<span class="comment-status-badge status-pending">⏳ En attente de modération</span>';
                    commentClass += ' comment-pending';
                } else if (c.status === 'rejected') {
                    statusBadge = '<span class="comment-status-badge status-rejected">✕ Rejeté</span>';
                    commentClass += ' comment-rejected';
                }
                
                var date = new Date(c.created_at);
                var dateStr = date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                
                var memberActions = '';
                var canManageComment = (typeof IS_ADMIN !== 'undefined' && IS_ADMIN)
                    || (typeof CURRENT_USER_ID !== 'undefined' && CURRENT_USER_ID && c.user_id === CURRENT_USER_ID);
                if (canManageComment) {
                    memberActions = '<div class="comment-member-actions">'
                        + '<button type="button" class="comment-edit-btn" data-cid="' + escapeHtml(c.id) + '" data-aid="' + escapeHtml(a.id) + '">Modifier</button>'
                        + '<button type="button" class="comment-delete-btn" data-cid="' + escapeHtml(c.id) + '" data-aid="' + escapeHtml(a.id) + '">Supprimer</button>'
                        + '</div>';
                }
                html += '<div class="' + commentClass + '">';
                html += '  <div class="comment-header">';
                html += '    <strong class="comment-author">' + escapeHtml(c.username) + '</strong>';
                html += '    <span class="comment-date">' + dateStr + '</span>';
                html += '    ' + statusBadge;
                html += '  </div>';
                html += '  <div class="comment-content" data-raw="' + escapeHtml(c.content).replace(/"/g, '&quot;') + '">' + escapeHtml(c.content).replace(/\n/g, '<br>') + '</div>';
                html += memberActions;
                html += '</div>';
            });
            commentsListEl.innerHTML = html;

            // Supprimer son propre commentaire
            commentsListEl.querySelectorAll('.comment-delete-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    if (!confirm('Supprimer définitivement votre commentaire ?')) return;
                    var f = document.getElementById('comment-delete-form');
                    if (!f) return;
                    document.getElementById('delete-comment-id').value = btn.getAttribute('data-cid');
                    document.getElementById('delete-article-id').value = btn.getAttribute('data-aid');
                    f.submit();
                });
            });

            // Modifier son propre commentaire (inline)
            commentsListEl.querySelectorAll('.comment-edit-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var item = btn.closest('.comment-item');
                    if (!item || item.querySelector('.comment-inline-edit')) return;
                    var contentDiv = item.querySelector('.comment-content');
                    if (!contentDiv) return;
                    var original = contentDiv.getAttribute('data-raw') || '';
                    contentDiv.style.display = 'none';
                    var wrap = document.createElement('div');
                    wrap.className = 'comment-inline-edit';
                    var ta = document.createElement('textarea');
                    ta.className = 'comment-edit-textarea';
                    ta.maxLength = 2000; ta.rows = 4; ta.value = original;
                    var acts = document.createElement('div');
                    acts.className = 'comment-edit-actions';
                    var btnOk = document.createElement('button');
                    btnOk.type = 'button'; btnOk.className = 'comment-submit-btn';
                    btnOk.textContent = 'Soumettre la modification';
                    var btnCx = document.createElement('button');
                    btnCx.type = 'button'; btnCx.className = 'comment-cancel-edit-btn';
                    btnCx.textContent = 'Annuler';
                    acts.appendChild(btnOk); acts.appendChild(btnCx);
                    wrap.appendChild(ta); wrap.appendChild(acts);
                    item.insertBefore(wrap, contentDiv.nextSibling);
                    ta.focus();
                    btnCx.addEventListener('click', function() { wrap.remove(); contentDiv.style.display = ''; });
                    btnOk.addEventListener('click', function() {
                        var val = ta.value.trim();
                        if (!val) { alert('Le commentaire ne peut pas être vide.'); return; }
                        var f = document.getElementById('comment-edit-form');
                        if (!f) return;
                        document.getElementById('edit-comment-id').value      = btn.getAttribute('data-cid');
                        document.getElementById('edit-comment-content').value = val;
                        document.getElementById('edit-article-id').value      = btn.getAttribute('data-aid');
                        f.submit();
                    });
                });
            });
        }
    }

    // Flash dans la modale (retour après soumission de commentaire)
    var modalFlashEl = document.getElementById('modal-comment-flash');
    if (modalFlashEl) {
        if (typeof COMMENT_FLASH !== 'undefined' && COMMENT_FLASH && a.id === AUTO_OPEN_ARTICLE) {
            modalFlashEl.innerHTML = '<div class="site-flash site-flash-' + escapeHtml(COMMENT_FLASH.type || 'success') + '" style="margin:0 0 1rem">' + escapeHtml(COMMENT_FLASH.message || '') + '</div>';
            COMMENT_FLASH = null;
        } else {
            modalFlashEl.innerHTML = '';
        }
    }

    // Open
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden'; document.documentElement.style.overflow = 'hidden';
    modal.scrollTop = 0;
    closeBtn.focus();
}
function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden','true');
    document.body.style.overflow = ''; document.documentElement.style.overflow = '';
    // Stop video on close
    if (videoWrap) { videoWrap.innerHTML = ''; videoWrap.style.display = 'none'; }
    if (modalBody) modalBody.classList.remove('has-video');
}

document.querySelectorAll('[data-open-article]').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        openModal(btn.getAttribute('data-open-article'));
    });
});
closeBtn.addEventListener('click', closeModal);
modal.addEventListener('click', function(e){ if (e.target === modal) closeModal(); });
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeModal(); });
// Ré-ouvre automatiquement la modale après soumission d'un commentaire
if (typeof AUTO_OPEN_ARTICLE !== 'undefined' && AUTO_OPEN_ARTICLE && articlesMap[AUTO_OPEN_ARTICLE]) {
    openModal(AUTO_OPEN_ARTICLE);
}
})();
</script>

<!-- ══════════════════════════════════════════════════════════════
     MODALES UTILISATEURS
     ══════════════════════════════════════════════════════════════ -->

<!-- Modale Connexion -->
<div class="user-modal<?php echo isset($_GET['show_login']) ? ' is-open' : ''; ?>" id="login-modal" data-user-modal="login">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Connexion</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['login_message'] ?? 'Connectez-vous pour accéder au site.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="login_user">
            
            <div class="user-field">
                <label for="login_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="login_username" 
                    name="login_username" 
                    placeholder="Votre nom d'utilisateur"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="login_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="login_password" 
                    name="login_password" 
                    placeholder="Votre mot de passe"
                    required
                    autocomplete="current-password"
                >
            </div>
            
            <button type="submit" class="user-submit-btn">Se connecter</button>
        </form>
        
        <?php if ($allowRegistration): ?>
        <div class="user-modal-footer">
            Pas encore de compte ? <button type="button" data-switch-to-register>S'inscrire</button>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modale Inscription -->
<?php if ($allowRegistration): ?>
<div class="user-modal<?php echo isset($_GET['show_register']) ? ' is-open' : ''; ?>" id="register-modal" data-user-modal="register">
    <div class="user-modal-dialog">
        <button class="user-modal-close" type="button" data-user-modal-close aria-label="Fermer">×</button>
        
        <h2 class="user-modal-title">Inscription</h2>
        <p class="user-modal-subtitle"><?php echo escape($userConfig['registration_message'] ?? 'Créez un compte pour accéder au contenu.'); ?></p>
        
        <form method="POST" class="user-form">
            <input type="hidden" name="csrf_token" value="<?php echo escapeAttribute($csrfToken); ?>">
            <input type="hidden" name="admin_action" value="register_user">
            
            <div class="user-field">
                <label for="register_username">Nom d'utilisateur</label>
                <input 
                    type="text" 
                    id="register_username" 
                    name="register_username" 
                    placeholder="Minimum 3 caractères"
                    minlength="3"
                    required
                    autocomplete="username"
                >
            </div>
            
            <div class="user-field">
                <label for="register_email">Email</label>
                <input 
                    type="email" 
                    id="register_email" 
                    name="register_email" 
                    placeholder="votre@email.com"
                    required
                    autocomplete="email"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password">Mot de passe</label>
                <input 
                    type="password" 
                    id="register_password" 
                    name="register_password" 
                    placeholder="Minimum 6 caractères"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="register_password_confirm">Confirmer le mot de passe</label>
                <input 
                    type="password" 
                    id="register_password_confirm" 
                    name="register_password_confirm" 
                    placeholder="Retapez votre mot de passe"
                    minlength="6"
                    required
                    autocomplete="new-password"
                >
            </div>
            
            <div class="user-field">
                <label for="discovered_from">Comment avez-vous connu ce site ? (optionnel)</label>
                <input 
                    type="text" 
                    id="discovered_from" 
                    name="discovered_from" 
                    placeholder="Google, Discord, un ami..."
                >
            </div>
            
            <button type="submit" class="user-submit-btn">S'inscrire</button>
        </form>
        
        <div class="user-modal-footer">
            Déjà un compte ? <button type="button" data-switch-to-login>Se connecter</button>
        </div>
    </div>
</div>
<?php endif; ?>

<script nonce="<?php echo htmlspecialchars($cspNonce, ENT_QUOTES); ?>">
/* ══════════════════════════════════════════════════════════════
   GESTION DES MODALES UTILISATEURS
   ══════════════════════════════════════════════════════════════ */
(function() {
    var loginModal = document.getElementById('login-modal');
    var registerModal = document.getElementById('register-modal');
    
    // Boutons d'ouverture
    var loginOpenBtns = document.querySelectorAll('[data-user-login-open]');
    var registerOpenBtns = document.querySelectorAll('[data-user-register-open]');
    
    // Boutons de fermeture
    var closeBtns = document.querySelectorAll('[data-user-modal-close]');
    
    // Boutons de bascule
    var switchToRegisterBtns = document.querySelectorAll('[data-switch-to-register]');
    var switchToLoginBtns = document.querySelectorAll('[data-switch-to-login]');
    
    // Fonctions d'ouverture/fermeture
    function openModal(modal) {
        if (modal) {
            modal.classList.add('is-open');
            document.body.style.overflow = 'hidden'; document.documentElement.style.overflow = 'hidden';
        }
    }
    
    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('is-open');
            document.body.style.overflow = ''; document.documentElement.style.overflow = '';
        }
    }
    
    function closeAllModals() {
        closeModal(loginModal);
        closeModal(registerModal);
    }
    
    // Ouvrir connexion
    loginOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(loginModal);
        });
    });
    
    // Ouvrir inscription
    registerOpenBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeAllModals();
            openModal(registerModal);
        });
    });
    
    // Fermer
    closeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var modal = btn.closest('[data-user-modal]');
            closeModal(modal);
        });
    });
    
    // Basculer vers inscription
    switchToRegisterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(loginModal);
            openModal(registerModal);
        });
    });
    
    // Basculer vers connexion
    switchToLoginBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            closeModal(registerModal);
            openModal(loginModal);
        });
    });
    
    // Fermer au clic sur le backdrop
    [loginModal, registerModal].forEach(function(modal) {
        if (modal) {
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closeModal(modal);
                }
            });
        }
    });
    
    // Fermer avec Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
})();
</script>

</div><!-- #spa-page -->
<?php require __DIR__ . '/includes/admin-modal.php'; ?>
</body>
</html>
